from datetime import timezone

from flask import Flask
from flask_login import LoginManager
from flask_sqlalchemy import SQLAlchemy
from flask_wtf.csrf import CSRFProtect

from .config import Config

db = SQLAlchemy()
login_manager = LoginManager()
csrf = CSRFProtect()


def _enable_sqlite_foreign_keys(app: Flask) -> None:
    """SQLite ignores ON DELETE CASCADE unless foreign keys are switched on for each connection."""
    from sqlalchemy import event

    with app.app_context():
        @event.listens_for(db.engine, "connect")
        def _fk_on(dbapi_conn, _record):
            cur = dbapi_conn.cursor()
            cur.execute("PRAGMA foreign_keys=ON")
            cur.close()


def _upgrade_schema(app: Flask) -> None:
    """Add columns introduced after a database was first created (create_all never alters existing tables)."""
    from sqlalchemy import inspect, text

    try:
        with app.app_context():
            json_type = "JSONB" if db.engine.dialect.name == "postgresql" else "JSON"
            additions = {
                # Existing users become admins, so nobody is locked out when spaces arrive.
                "users": {"theme": "VARCHAR(30) NOT NULL DEFAULT 'indigo'",
                          "role": "VARCHAR(20) NOT NULL DEFAULT 'admin'",
                          "spaces": "VARCHAR(200) NOT NULL DEFAULT ''",
                          "session_version": "INTEGER NOT NULL DEFAULT 0",
                          "must_change_password": "BOOLEAN NOT NULL DEFAULT FALSE" if json_type == "JSONB" else "BOOLEAN NOT NULL DEFAULT 0",
                          # People who already use the studio don't get the first-login tour (they can take it from the sidebar).
                          "tour": "VARCHAR(200) NOT NULL DEFAULT 'done'"},
                # HR profile columns (all optional)
                "recipients": {
                    "employee_code": "VARCHAR(20)",
                    "gender": "VARCHAR(20)",
                    "designation": "VARCHAR(120)",
                    "grade": "VARCHAR(10)",
                    "business_unit": "VARCHAR(120)",
                    "location": "VARCHAR(120)",
                    "employment_type": "VARCHAR(30)",
                    "work_mode": "VARCHAR(20)",
                    "cost_center": "VARCHAR(30)",
                    "manager_id": "INTEGER REFERENCES recipients(id) ON DELETE SET NULL",
                    "hrbp_id": "INTEGER REFERENCES recipients(id) ON DELETE SET NULL",
                    "date_of_joining": "DATE",
                    "date_of_resignation": "DATE",
                    "date_of_exit": "DATE",
                    "exit_type": "VARCHAR(20)",
                    "exit_reason": "VARCHAR(120)",
                    "regrettable": "BOOLEAN",
                    "performance_rating": "INTEGER",
                    "date_of_birth": "DATE",
                    "phone": "VARCHAR(30)",
                },
                "campaigns": {
                    "repeat": "VARCHAR(10) NOT NULL DEFAULT ''",
                    "repeat_start": "TIMESTAMP WITH TIME ZONE" if json_type == "JSONB" else "DATETIME",
                    "repeat_count": "INTEGER NOT NULL DEFAULT 0",
                    "repeat_until": "DATE",
                    "repeat_refresh": "BOOLEAN NOT NULL DEFAULT FALSE" if json_type == "JSONB" else "BOOLEAN NOT NULL DEFAULT 0",
                    "repeat_parent_id": "INTEGER REFERENCES campaigns(id) ON DELETE SET NULL",
                    "data_source": json_type,
                    "cc": f"{json_type} NOT NULL DEFAULT '[]'",
                    "bcc": f"{json_type} NOT NULL DEFAULT '[]'",
                    "copy_status": "VARCHAR(20) NOT NULL DEFAULT ''",
                    "copy_error": "TEXT NOT NULL DEFAULT ''",
                    "copy_attempts": "INTEGER NOT NULL DEFAULT 0",
                },
            }
            insp = inspect(db.engine)
            for table, columns in additions.items():
                if not insp.has_table(table):
                    continue  # fresh database: `flask init-db` creates the full schema
                existing = {c["name"] for c in insp.get_columns(table)}
                for name, ddl in columns.items():
                    if name not in existing:
                        with db.engine.begin() as conn:
                            conn.execute(text(f"ALTER TABLE {table} ADD COLUMN {name} {ddl}"))
                            if (table, name) == ("users", "tour"):
                                # ...except people an admin added who haven't signed in yet: their first login is still ahead.
                                conn.execute(text("UPDATE users SET tour = '' WHERE must_change_password"))
                        app.logger.info("Added column %s.%s", table, name)
            if insp.has_table("recipients") and not insp.has_table("goals"):
                from .models import Goal

                Goal.__table__.create(db.engine)
                app.logger.info("Created table goals")
            if insp.has_table("recipients"):
                with db.engine.begin() as conn:
                    conn.execute(text("CREATE UNIQUE INDEX IF NOT EXISTS ix_recipients_employee_code ON recipients (employee_code)"))
                    conn.execute(text("CREATE INDEX IF NOT EXISTS ix_recipients_business_unit ON recipients (business_unit)"))
    except Exception as exc:  # noqa: BLE001 — never block startup (e.g. database not reachable yet)
        app.logger.warning("Schema check skipped: %s", exc)


def create_app(config_object=None) -> Flask:
    app = Flask(__name__)
    app.config.from_object(config_object or Config)
    if app.config.get("BEHIND_PROXY"):
        # Take the visitor's address, scheme and host from nginx's X-Forwarded-* headers (sign-in lockout per person,
        # https detection for secure cookies and CSRF checks).
        from werkzeug.middleware.proxy_fix import ProxyFix

        hops = int(app.config["BEHIND_PROXY"])
        app.wsgi_app = ProxyFix(app.wsgi_app, x_for=hops, x_proto=hops, x_host=hops)

    db.init_app(app)
    if app.config["SQLALCHEMY_DATABASE_URI"].startswith("sqlite"):
        _enable_sqlite_foreign_keys(app)
    csrf.init_app(app)
    login_manager.init_app(app)
    login_manager.login_view = "auth.login"
    login_manager.login_message_category = "info"

    from . import models  # noqa: F401  (register models)
    from .cli import register_cli
    from .routes.auth import bp as auth_bp
    from .routes.campaigns import bp as campaigns_bp
    from .routes.dashboard import bp as dashboard_bp
    from .routes.help import bp as help_bp
    from .routes.help import help_config
    from .routes.insights import bp as insights_bp
    from .routes.recipients import bp as recipients_bp
    from .routes.settings import bp as settings_bp
    from .routes.spaces import bp as spaces_bp
    from .routes.tour import bp as tour_bp
    from .routes.tour import tour_config
    from .routes.tracking import bp as tracking_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(dashboard_bp)
    app.register_blueprint(campaigns_bp)
    app.register_blueprint(insights_bp)
    app.register_blueprint(recipients_bp)
    app.register_blueprint(settings_bp)
    app.register_blueprint(tracking_bp)
    app.register_blueprint(spaces_bp)
    app.register_blueprint(tour_bp)
    app.jinja_env.globals["tour_config"] = tour_config
    app.register_blueprint(help_bp)
    app.jinja_env.globals["help_config"] = help_config
    register_cli(app)

    from .security import add_security_headers

    app.after_request(add_security_headers)
    if app.config.get("SECRET_KEY_NOTE"):
        app.logger.warning(app.config["SECRET_KEY_NOTE"])

    @app.before_request
    def _new_password_first():
        """People given a temporary password by an admin choose their own before anything else."""
        from flask import jsonify, redirect, request, url_for
        from flask_login import current_user

        if not (current_user.is_authenticated and getattr(current_user, "must_change_password", False)):
            return None
        if request.endpoint in ("settings.index", "settings.password", "auth.logout", "static"):
            return None
        if request.method == "GET" and request.accept_mimetypes.best != "application/json":
            return redirect(url_for("settings.index") + "#security")
        return jsonify(error="Choose your own password first (Settings → Password)."), 409

    @app.before_request
    def _choose_space_first():
        """Signed-in users work inside a space: send them to the chooser until they pick one."""
        from flask import jsonify, redirect, request, url_for
        from flask_login import current_user

        from .spaces import current_space, user_spaces

        if not current_user.is_authenticated:
            return None
        endpoint = request.endpoint or ""
        if endpoint == "static" or endpoint.split(".")[0] in ("auth", "spaces", "settings", "tracking", "tour", "help"):
            return None
        if current_space() or not user_spaces(current_user):
            return None  # without any space, people can still write newsletters from a prompt
        if request.method == "GET" and request.accept_mimetypes.best != "application/json":
            nxt = request.full_path if request.query_string else request.path
            return redirect(url_for("spaces.choose", next=nxt if nxt != "/" else None))
        return jsonify(error="Choose a space first."), 409
    _upgrade_schema(app)

    @app.template_filter("iso")
    def iso(value):
        """Render a datetime as ISO-8601 UTC; static/js/app.js converts it to the viewer's local time."""
        if value is None:
            return ""
        if value.tzinfo is None:
            value = value.replace(tzinfo=timezone.utc)
        return value.astimezone(timezone.utc).isoformat()

    @app.template_filter("pct")
    def pct(value):
        return f"{value * 100:.1f}%" if value is not None else "–"

    @app.template_filter("audience_label")
    def audience_label_filter(audience):
        from .services.audience import audience_label

        return audience_label(audience)

    @app.template_filter("initials")
    def initials(value):
        parts = [p for p in str(value or "").replace(".", " ").split() if p and p[0].isalnum()]
        return ("".join(p[0] for p in parts[:2]) or "?").upper()

    @app.template_filter("hue")
    def hue(value):
        """Stable 0-359 hue for avatars / department chips."""
        return sum(ord(c) * (i + 7) for i, c in enumerate(str(value or ""))) % 360

    from .icons import ICONS, icon

    from .themes import THEMES

    app.jinja_env.globals["icon"] = icon
    app.jinja_env.globals["ICONS"] = ICONS
    app.jinja_env.globals["THEMES"] = THEMES

    def nav_counts():
        from .models import Campaign, CampaignStatus, Recipient

        return {
            "campaigns": Campaign.query.count(),
            "recipients": Recipient.query.filter_by(active=True).count(),
            "scheduled": Campaign.query.filter_by(status=CampaignStatus.SCHEDULED).count(),
        }

    app.jinja_env.globals["nav_counts"] = nav_counts

    @app.context_processor
    def inject_globals():
        import os

        from flask import has_request_context
        from flask_login import current_user

        from .spaces import SPACES, current_space, user_spaces

        # Emails are rendered by the background sender too, outside any web request: no signed-in user there.
        signed_in = has_request_context() and current_user and current_user.is_authenticated
        key = current_space() if signed_in else None
        return {
            "SPACES": SPACES,
            "space_key": key,
            "space": SPACES.get(key) if key else None,
            "my_spaces": user_spaces(current_user) if signed_in else [],
            "is_admin": bool(signed_in and getattr(current_user, "role", "") == "admin"),
            "company_name": app.config["COMPANY_NAME"],
            "ai_enabled": bool(os.environ.get("ANTHROPIC_API_KEY") or os.environ.get("ANTHROPIC_AUTH_TOKEN")),
        }

    return app

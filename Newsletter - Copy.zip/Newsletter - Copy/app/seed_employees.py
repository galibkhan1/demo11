"""Demo HR data: a realistic organisation of employee profiles for testing (all addresses @example.com).

    flask --app run seed-employees            # about 600 profiles: ~500 employed, ~100 left in the last 2 years
    flask --app run seed-employees --total 800

What it builds: a CEO, business-unit heads, department heads, managers and individual contributors, each
with a manager and an HR business partner; joiners spread over the years (more recent ones); exits in the
last two years (voluntary and involuntary, some regrettable, some within the first months) and a few people
serving notice now. Existing demo employees (@example.com) keep their name, email and department and get a
profile; real employees are never touched. Exited employees stop receiving newsletters. The same seed always
gives the same data.
"""

import math
import random
from datetime import date, timedelta

from . import db
from .models import Recipient
from .services.addresses import is_demo_address

BUSINESS_UNITS = {  # BU -> {department: relative size}
    "Technology": {"Engineering": 150, "Product": 40, "Data Science": 35},
    "Revenue": {"Sales": 90, "Marketing": 40, "Customer Support": 85},
    "Operations": {"Operations": 70},
    "Corporate Functions": {"Finance": 25, "HR": 25, "Legal": 10, "IT & Security": 20},
}
BU_HEADS = {"Technology": ("Chief Technology Officer", "Engineering"), "Revenue": ("Chief Revenue Officer", "Sales"),
            "Operations": ("Chief Operating Officer", "Operations"), "Corporate Functions": ("Chief Financial Officer", "Finance")}
BU_CODES = {"Technology": "TEC", "Revenue": "REV", "Operations": "OPS", "Corporate Functions": "COR"}
# department -> (IC titles from junior to senior, manager title, head title)
ROLES = {
    "Engineering": (["Associate Software Engineer", "Software Engineer", "Senior Software Engineer", "Staff Engineer"], "Engineering Manager", "Director of Engineering"),
    "Product": (["Associate Product Manager", "Product Manager", "Senior Product Manager", "Principal Product Designer"], "Group Product Manager", "Director of Product"),
    "Data Science": (["Data Analyst", "Data Scientist", "Senior Data Scientist", "Machine Learning Engineer"], "Data Science Manager", "Head of Data Science"),
    "Sales": (["Sales Associate", "Account Executive", "Senior Account Executive", "Key Account Manager"], "Regional Sales Manager", "Head of Sales"),
    "Marketing": (["Marketing Associate", "Content Specialist", "Performance Marketing Manager", "Brand Manager"], "Marketing Manager", "Head of Marketing"),
    "Customer Support": (["Support Associate", "Senior Support Associate", "Support Specialist", "Quality Analyst"], "Support Team Lead", "Head of Customer Support"),
    "Operations": (["Operations Associate", "Operations Executive", "Senior Operations Executive", "Process Analyst"], "Operations Manager", "Head of Operations"),
    "Finance": (["Accounts Executive", "Financial Analyst", "Senior Financial Analyst", "Payroll Specialist"], "Finance Manager", "Head of Finance"),
    "HR": (["HR Associate", "Talent Acquisition Specialist", "HR Generalist", "Learning & Development Specialist"], "Senior HR Business Partner", "Head of HR"),
    "Legal": (["Legal Associate", "Legal Counsel", "Senior Legal Counsel", "Compliance Analyst"], "Legal Manager", "General Counsel"),
    "IT & Security": (["IT Support Engineer", "System Administrator", "Security Analyst", "Network Engineer"], "IT Manager", "Head of IT & Security"),
}
IC_GRADES = ["G3", "G4", "G5", "G6"]
AGE_BY_GRADE = {"G3": (21, 27), "G4": (23, 31), "G5": (25, 35), "G6": (28, 40), "G7": (29, 42), "G8": (30, 46),
                "G10": (35, 50), "G12": (40, 55), "G14": (45, 58)}
LOCATIONS = [("Bengaluru", 30), ("Mumbai", 20), ("Gurugram", 15), ("Hyderabad", 12), ("Pune", 12), ("Chennai", 8), ("Kolkata", 3)]
WORK_MODES = [("Hybrid", 48), ("Office", 40), ("Remote", 12)]
VOLUNTARY = ["Better opportunity", "Compensation", "Career change", "Higher studies", "Relocation", "Personal reasons",
             "Work-life balance", "Manager relationship", "Health"]
INVOLUNTARY = ["Performance", "Restructuring", "End of contract", "Policy violation", "Absconding"]

FEMALE = ["Aditi", "Ananya", "Diya", "Fatima", "Isha", "Kavya", "Meera", "Neha", "Pooja", "Priya", "Riya", "Sana", "Sara",
          "Shreya", "Sneha", "Tanvi", "Zoya", "Maria", "Emily", "Leah", "Aisha", "Anjali", "Kiran", "Lakshmi", "Nisha", "Ritu",
          "Aarohi", "Bhavna", "Charu", "Deepika", "Esha", "Gauri", "Harini", "Ira", "Jhanvi", "Kriti", "Mansi", "Naina",
          "Pallavi", "Radhika", "Sakshi", "Trisha", "Urvi", "Vaishnavi", "Yamini", "Swati", "Divya", "Komal", "Nandini",
          "Preeti", "Rashmi", "Shalini", "Tara", "Avni", "Ishita", "Mehak", "Rhea", "Simran"]
MALE = ["Aarav", "Akash", "Arjun", "Farhan", "Gaurav", "Kabir", "Mohammed", "Nikhil", "Rahul", "Rohan", "Sahil", "Siddharth",
        "Varun", "Vikram", "Daniel", "John", "Omar", "Chen", "Ravi", "Imran", "Manish", "Pranav", "Abhishek", "Ajay", "Amit",
        "Ankit", "Deepak", "Harsh", "Ishaan", "Karan", "Kunal", "Mayank", "Naveen", "Parth", "Rajesh", "Sameer", "Tarun",
        "Uday", "Vivek", "Yash", "Zaid", "Aditya", "Dev", "Hitesh", "Jatin", "Lokesh", "Mihir", "Nitin", "Prateek",
        "Rakesh", "Suresh", "Tushar", "Arnav", "Reyansh"]
LAST = ["Sharma", "Verma", "Khan", "Patel", "Iyer", "Nair", "Reddy", "Gupta", "Singh", "Mehta", "Joshi", "Kapoor",
        "D'Souza", "Fernandes", "Ali", "Das", "Bose", "Chopra", "Malhotra", "Rao", "Menon", "Pillai", "Sheikh", "Thomas",
        "Agarwal", "Bhatt", "Chatterjee", "Dutta", "Ghosh", "Hegde", "Jain", "Kulkarni", "Mishra", "Mukherjee", "Naidu",
        "Pandey", "Qureshi", "Saxena", "Shetty", "Srinivasan", "Tiwari", "Varma", "Yadav", "Banerjee", "Chauhan",
        "Deshpande", "Gill", "Lobo", "Mathew", "Nambiar", "Pinto", "Sinha", "Trivedi"]


def _pick(rng, weighted):
    return rng.choices([v for v, _ in weighted], weights=[w for _, w in weighted])[0]


def _gender_of(name: str) -> str:
    first = (name or "").split(" ")[0]
    return "Female" if first in FEMALE else "Male" if first in MALE else "Female"


def _slots(total: int, rng: random.Random) -> list[dict]:
    """Role slots for the whole organisation, scaled to about ``total`` people."""
    weight = sum(sum(d.values()) for d in BUSINESS_UNITS.values())
    slots = [{"kind": "ceo", "bu": "Corporate Functions", "dept": "Leadership", "title": "Chief Executive Officer", "grade": "G14"}]
    for bu, depts in BUSINESS_UNITS.items():
        for dept, w in depts.items():
            n = max(4, round(w * (total - 1) / weight))
            ics, manager_title, head_title = ROLES[dept]
            bu_title, bu_dept = BU_HEADS[bu]
            if dept == bu_dept:
                slots.append({"kind": "bu_head", "bu": bu, "dept": dept, "title": bu_title, "grade": "G12"})
                n -= 1
            slots.append({"kind": "head", "bu": bu, "dept": dept, "title": head_title, "grade": "G10"})
            n -= 1
            managers = max(1, math.ceil(n / 10))
            for _ in range(managers):
                slots.append({"kind": "manager", "bu": bu, "dept": dept, "title": manager_title, "grade": "G8"})
            n -= managers
            if dept == "HR":  # one HR business partner per business unit
                for _ in BUSINESS_UNITS:
                    slots.append({"kind": "hrbp", "bu": bu, "dept": dept, "title": "HR Business Partner", "grade": "G7"})
                n -= len(BUSINESS_UNITS)
            for i in range(max(0, n)):
                level = min(3, int(rng.triangular(0, 4, 0.6)))  # more juniors than seniors
                slots.append({"kind": "ic", "bu": bu, "dept": dept, "title": ics[level], "grade": IC_GRADES[level]})
    # Rounding leaves us a few people off: top up (or trim) junior engineers so the total is exact.
    while len(slots) < total:
        slots.append({"kind": "ic", "bu": "Technology", "dept": "Engineering", "title": ROLES["Engineering"][0][1], "grade": "G4"})
    while len(slots) > total:
        slots.remove(next(x for x in reversed(slots) if x["kind"] == "ic"))
    return slots


def seed_employees(total: int = 600, seed: int = 11, today: date | None = None) -> dict:
    today = today or date.today()
    rng = random.Random(seed)
    if Recipient.query.filter(Recipient.employee_code.isnot(None)).count() >= total:
        return {"skipped": True}

    slots = _slots(total, rng)
    rng.shuffle(slots)
    by_dept = {}
    for s in slots:
        by_dept.setdefault(s["dept"], []).append(s)

    # Existing demo employees (no profile yet) keep their name, email and department.
    existing = [r for r in Recipient.query.order_by(Recipient.id).all() if is_demo_address(r.email) and not r.employee_code]
    used_emails = {r.email for r in Recipient.query.with_entities(Recipient.email)}
    people = []  # (recipient, slot)
    for r in existing:
        pool = [s for s in by_dept.get(r.department, []) if s["kind"] == "ic" and not s.get("taken")]
        if not pool:  # unknown department or a full one: give them an IC role in their own department
            pool = [{"kind": "ic", "bu": "Corporate Functions", "dept": r.department or "Operations",
                     "title": "Specialist", "grade": "G5"}]
            slots.append(pool[0])
        slot = pool[0]
        slot["taken"] = True
        slot["existing"] = True
        people.append((r, slot))
    for slot in slots:
        if slot.get("taken"):
            continue
        gender = _pick(rng, [("Female", 38), ("Male", 60), ("Non-binary", 2)])
        first = rng.choice(FEMALE if gender == "Female" else MALE if gender == "Male" else FEMALE + MALE)
        last = rng.choice(LAST)
        base = f"{first}.{last}".lower().replace("'", "")
        email, n = f"{base}@example.com", 2
        while email in used_emails:
            email, n = f"{base}{n}@example.com", n + 1
        used_emails.add(email)
        r = Recipient(email=email, name=f"{first} {last}", department=slot["dept"], active=True)
        r.gender = gender
        db.session.add(r)
        slot["taken"] = True
        people.append((r, slot))

    # Who leaves: only individual contributors who are new to the studio (existing demo staff stay employed).
    leavers = [p for p in people if p[1]["kind"] == "ic" and not p[1].get("existing")]
    rng.shuffle(leavers)
    n_exit = round(len(people) * 0.17)
    n_notice = max(3, round(len(people) * 0.025))
    exiting = {id(p[0]) for p in leavers[:n_exit]}
    notice = {id(p[0]) for p in leavers[n_exit:n_exit + n_notice]}

    for r, slot in people:
        kind, grade = slot["kind"], slot["grade"]
        r.department = slot["dept"]
        r.business_unit = slot["bu"]
        r.designation = slot["title"]
        r.grade = grade
        r.gender = r.gender or _gender_of(r.name)
        r.location = _pick(rng, LOCATIONS)
        r.work_mode = _pick(rng, WORK_MODES)
        r.cost_center = f"CC-{BU_CODES[slot['bu']]}-{slot['dept'][:3].upper()}"
        r.employment_type = "Permanent"
        if kind == "ic" and rng.random() < 0.07:
            r.employment_type = "Contract"
        if kind == "ic" and grade == "G3" and rng.random() < 0.18:
            r.employment_type, r.designation = "Intern", f"{slot['dept']} Intern"
        r.performance_rating = rng.choices([1, 2, 3, 4, 5], weights=[5, 12, 45, 28, 10])[0]
        phone = "".join(rng.choice("0123456789") for _ in range(9))
        r.phone = f"+91 {rng.choice('6789')}{phone[:4]} {phone[4:]}"
        age_lo, age_hi = AGE_BY_GRADE[grade]
        r.date_of_birth = today - timedelta(days=rng.randint(age_lo * 365, age_hi * 365))

        if id(r) in exiting:
            r.date_of_exit = today - timedelta(days=rng.randint(1, 730))
            stay = rng.randint(20, 179) if rng.random() < 0.3 else rng.randint(180, 2600)  # 30% leave in the first months
            r.date_of_joining = max(date(2012, 1, 1), r.date_of_exit - timedelta(days=stay))
            if rng.random() < 0.8:
                r.exit_type = "Voluntary"
                r.exit_reason = rng.choice(VOLUNTARY)
                notice_days = rng.choice([15, 30]) if r.employment_type != "Permanent" else rng.choice([30, 45, 60, 90])
                r.date_of_resignation = max(r.date_of_joining, r.date_of_exit - timedelta(days=notice_days))
                r.regrettable = r.performance_rating >= 4 and rng.random() < 0.85
            else:
                r.exit_type = "Involuntary"
                r.exit_reason = rng.choice(INVOLUNTARY)
                r.performance_rating = rng.choices([1, 2, 3], weights=[45, 40, 15])[0]
                r.date_of_resignation = None
                r.regrettable = False
            r.active = False  # left the company: no more newsletters
        else:
            if kind in ("ceo", "bu_head", "head"):
                r.date_of_joining = today - timedelta(days=rng.randint(6 * 365, 12 * 365))
            elif kind in ("manager", "hrbp"):
                r.date_of_joining = today - timedelta(days=rng.randint(2 * 365, 9 * 365))
            elif r.employment_type == "Intern":
                r.date_of_joining = today - timedelta(days=rng.randint(5, 270))
            else:
                r.date_of_joining = today - timedelta(days=int(rng.triangular(3, 3650, 120)))
            if id(r) in notice:
                r.date_of_resignation = today - timedelta(days=rng.randint(1, 40))
                r.date_of_exit = r.date_of_resignation + timedelta(days=rng.choice([30, 45, 60, 90]))
                if r.date_of_exit <= today:
                    r.date_of_exit = today + timedelta(days=rng.randint(5, 30))
                r.exit_type = "Voluntary"
                r.exit_reason = rng.choice(VOLUNTARY)
                r.regrettable = r.performance_rating >= 4

    db.session.flush()  # ids for manager / HRBP links

    # Reporting lines: IC -> manager -> department head -> BU head -> CEO. Leavers keep their last manager.
    ceo = next(r for r, s in people if s["kind"] == "ceo")
    bu_heads = {s["bu"]: r for r, s in people if s["kind"] == "bu_head"}
    heads = {s["dept"]: r for r, s in people if s["kind"] == "head"}
    managers = {}
    for r, s in people:
        if s["kind"] == "manager":
            managers.setdefault(s["dept"], []).append(r)
    hrbps = [r for r, s in people if s["kind"] == "hrbp"]
    hrbp_for_bu = {bu: hrbps[i % len(hrbps)] for i, bu in enumerate(BUSINESS_UNITS)} if hrbps else {}
    head_of_hr = heads.get("HR")
    for r, s in people:
        kind, dept, bu = s["kind"], s["dept"], s["bu"]
        if kind == "ceo":
            r.manager = None
        elif kind == "bu_head":
            r.manager = ceo
        elif kind == "head":
            r.manager = bu_heads.get(bu) if bu_heads.get(bu) is not r else ceo
        elif kind in ("manager", "hrbp"):
            r.manager = heads.get(dept) or bu_heads.get(bu) or ceo
        else:
            team = managers.get(dept)
            r.manager = rng.choice(team) if team else (heads.get(dept) or bu_heads.get(bu) or ceo)
        if dept == "HR" or kind in ("ceo", "bu_head"):
            r.hrbp = head_of_hr if r is not head_of_hr else None
        else:
            r.hrbp = hrbp_for_bu.get(bu)

    # Employee IDs in joining order, so long-serving people have lower numbers.
    taken = {c for (c,) in Recipient.query.with_entities(Recipient.employee_code).filter(Recipient.employee_code.isnot(None))}
    next_no = 10001
    for r, _s in sorted(people, key=lambda p: (p[0].date_of_joining, p[0].email)):
        while f"E{next_no}" in taken:
            next_no += 1
        r.employee_code = f"E{next_no}"
        taken.add(r.employee_code)
        next_no += 1
    db.session.commit()

    statuses = [r.employment_status for r, _ in people]
    return {
        "skipped": False,
        "profiles": len(people),
        "updated_existing": len(existing),
        "added": len(people) - len(existing),
        "employed": statuses.count("Active") + statuses.count("Serving notice"),
        "serving_notice": statuses.count("Serving notice"),
        "exited": statuses.count("Exited"),
        "business_units": len(BUSINESS_UNITS),
        "departments": len({s["dept"] for _, s in people}),
    }

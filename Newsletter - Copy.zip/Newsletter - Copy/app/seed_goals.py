"""Demo goals for the current performance cycle (financial year, April to March).

Every employed demo employee (@example.com addresses) without goals in the cycle gets 2 to 4 goals that fit their
department, with quarterly due dates. Progress follows how far the cycle has run, nudged by the person's performance
rating, so the Goals space has a realistic mix of completed, on-track, at-risk, behind and overdue goals. Real
employees are never touched, and running it again adds nothing.
"""

import random
from datetime import date, timedelta

from . import db
from .models import Goal, Recipient
from .services.addresses import is_demo_address
from .services.workforce import _employed, _fy_label, _fy_start

CATEGORIES = ("Business", "Customer", "Process", "People", "Learning")

TEMPLATES = {
    "Engineering": [("Cut p95 API latency to under 300 ms", "Customer"), ("Ship the new mobile checkout", "Business"),
                    ("Raise unit-test coverage to 80%", "Process"), ("Close 90% of P1 bugs within 48 hours", "Customer"),
                    ("Move the order service to the new cloud platform", "Process")],
    "Product": [("Launch the loyalty programme MVP", "Business"), ("Run 12 customer discovery interviews a quarter", "Customer"),
                ("Lift feature adoption to 40%", "Business"), ("Publish the FY roadmap and review it quarterly", "Process")],
    "Data Science": [("Deploy the demand-forecast model", "Business"), ("Improve forecast accuracy to 92%", "Process"),
                     ("Automate the weekly KPI pack", "Process"), ("Build the churn-risk score for Support", "Customer")],
    "Sales": [("Hit 100% of the quarterly sales target", "Business"), ("Add 25 new enterprise accounts", "Business"),
              ("Keep pipeline coverage at 3x", "Process"), ("Renew 95% of key accounts", "Customer")],
    "Marketing": [("Grow qualified leads by 30%", "Business"), ("Launch the brand refresh campaign", "Business"),
                  ("Cut cost per lead by 15%", "Process"), ("Grow newsletter subscribers to 50,000", "Customer")],
    "Customer Support": [("Raise CSAT to 92%", "Customer"), ("Bring first response under 2 hours", "Customer"),
                         ("Publish 40 help-centre articles", "Process"), ("Resolve 80% of tickets in one contact", "Customer")],
    "Operations": [("Cut order fulfilment time to 24 hours", "Customer"), ("Reduce logistics cost per order by 8%", "Process"),
                   ("Roll out the new warehouse system in two sites", "Process"), ("Zero safety incidents this year", "People")],
    "Finance": [("Close the books within 5 working days", "Process"), ("Automate vendor reconciliation", "Process"),
                ("Deliver the FY budget on time", "Business"), ("Cut overdue receivables by 20%", "Business")],
    "HR": [("Cut time-to-hire to 30 days", "Process"), ("Launch the new onboarding programme", "People"),
           ("Raise engagement survey participation to 85%", "People"), ("Train every manager on hiring interviews", "People")],
    "IT & Security": [("Patch critical vulnerabilities within 7 days", "Process"), ("Roll out single sign-on to all apps", "Process"),
                      ("Run a phishing drill every quarter", "People"), ("Keep core systems at 99.9% uptime", "Customer")],
    "Legal": [("Standardise customer contract templates", "Process"), ("Turn contract reviews around in 5 days", "Customer"),
              ("Complete the data-protection compliance review", "Process")],
    "Leadership": [("Grow revenue 25% year on year", "Business"), ("Lift employee engagement to 80%", "People"),
                   ("Launch in two new cities", "Business")],
}
COMMON = [("Complete one professional certification", "Learning"), ("Mentor a new joiner for their first 90 days", "People"),
          ("Lead one cross-team improvement project", "Process"), ("Finish the leadership essentials course", "Learning")]
RATING_PACE = {5: 1.18, 4: 1.06, 3: 0.95, 2: 0.74, 1: 0.55}


def _quarter_ends(fy_start: date) -> list[date]:
    y = fy_start.year
    return [date(y, 6, 30), date(y, 9, 30), date(y, 12, 31), date(y + 1, 3, 31)]


def status_for(progress: int, expected: float, due: date | None, today: date) -> str:
    """Status the way a manager would set it: completed, on track, at risk, behind (overdue counts as behind)."""
    if progress >= 100:
        return "Completed"
    if due and due < today:
        return "Behind"
    if progress == 0:
        return "Not started" if expected < 35 else "Behind"
    gap = expected - progress
    return "On track" if gap <= 10 else ("At risk" if gap <= 25 else "Behind")


def seed_goals(seed: int = 7, today: date | None = None) -> dict:
    today = today or date.today()
    fy_start = _fy_start(today)
    cycle = _fy_label(fy_start)
    ends = _quarter_ends(fy_start)
    rng = random.Random(seed)
    have = {rid for (rid,) in db.session.query(Goal.recipient_id).filter(Goal.cycle == cycle).distinct()}
    people = (Recipient.query.filter(Recipient.date_of_joining.isnot(None))
              .order_by(Recipient.id).all())
    added = people_with_new = 0
    for r in people:
        if r.id in have or not is_demo_address(r.email) or not _employed(r, today):
            continue
        start = max(fy_start, r.date_of_joining)
        pool = list(TEMPLATES.get(r.department, [])) or list(COMMON)
        n = rng.choice((2, 3, 3, 4)) if r.grade not in ("G3",) else rng.choice((2, 3))
        picks = rng.sample(pool, min(len(pool), n - 1)) + [rng.choice(COMMON)]
        weights = {2: [60, 40], 3: [40, 30, 30], 4: [40, 25, 20, 15]}[len(picks)]
        pace = RATING_PACE.get(r.performance_rating or 3, 0.95)
        for (title, category), weight in zip(picks, weights):
            due = rng.choice([d for d in ends if d > start] or ends[-1:])
            begin = max(start, date(due.year, due.month, 1) - timedelta(days=152))  # work starts about 6 months before it's due
            span = max(1, (due - begin).days)
            expected = max(0.0, min(1.0, (today - begin).days / span)) * 100
            progress = expected * pace * rng.uniform(0.75, 1.2)
            if due > today and expected < 35 and rng.random() < 0.22:
                progress = 0  # some later goals haven't been started yet
            if due < today and rng.random() < 0.55 + (pace - 0.95):  # most past-due goals did get finished
                progress = 100
            progress = int(max(0, min(100, round(progress / 5) * 5)))
            status = status_for(progress, expected, due, today)
            completed_on = None
            if status == "Completed":
                completed_on = min(today, due - timedelta(days=rng.randint(0, 20)))
                completed_on = max(start, completed_on)
            db.session.add(Goal(recipient_id=r.id, cycle=cycle, title=title, category=category, weight=weight,
                                progress=progress, status=status, due_date=due, completed_on=completed_on))
            added += 1
        people_with_new += 1
    db.session.commit()
    return {"cycle": cycle, "goals": added, "people": people_with_new,
            "total": Goal.query.filter(Goal.cycle == cycle).count()}

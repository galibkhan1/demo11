"""Repeating schedules: daily, weekly or monthly, from a first send date, optionally until an end date.

The scheduled newsletter is the *template*. Each time it's due, the worker sends a dated copy of it (its own
newsletter with its own stats, e.g. "Monthly HR update · 01 Dec 2026") and moves the template on to the next date.
Edits to the template apply to future sends. For newsletters built with "Use your data", the copy can be rebuilt
from the latest numbers first.

Dates are worked out in the computer's local time, so "every month on the 1st at 9:00" stays on the 1st at 9:00.
"""

import calendar
import logging
from datetime import date, datetime, timedelta, timezone

from .. import db
from ..models import Campaign, CampaignStatus, utcnow

log = logging.getLogger(__name__)

REPEATS = {"daily": "Every day", "weekly": "Every week", "monthly": "Every month"}


def _local(dt: datetime) -> datetime:
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone()


def occurrence(start: datetime, repeat: str, n: int) -> datetime:
    """The n-th send (0 = the first one) of a series that starts at ``start``. Returns UTC."""
    local = _local(start)
    if repeat == "daily":
        nxt = local + timedelta(days=n)
    elif repeat == "weekly":
        nxt = local + timedelta(weeks=n)
    elif repeat == "monthly":
        y, m = divmod(local.month - 1 + n, 12)
        year, month = local.year + y, m + 1
        nxt = local.replace(year=year, month=month, day=min(local.day, calendar.monthrange(year, month)[1]))
    else:
        raise ValueError(f"Unknown repeat: {repeat}")
    return nxt.astimezone(timezone.utc)


def _ordinal(n: int) -> str:
    return f"{n}{'th' if 11 <= n % 100 <= 13 else {1: 'st', 2: 'nd', 3: 'rd'}.get(n % 10, 'th')}"


def describe(repeat: str, start: datetime | None, until: date | None = None) -> str:
    """'Every Thursday at 10:00, until 31 Mar 2027' (in local time)."""
    if repeat not in REPEATS or not start:
        return ""
    local = _local(start)
    at = local.strftime("%H:%M")
    if repeat == "daily":
        text = f"Every day at {at}"
    elif repeat == "weekly":
        text = f"Every {local:%A} at {at}"
    else:
        text = f"Every month on the {_ordinal(local.day)} at {at}" + (" (or the month's last day)" if local.day > 28 else "")
    return text + (f", until {until:%d %b %Y}" if until else "")


def _refreshed(template: Campaign) -> dict:
    """Rebuild a newsletter from the data it was built from (same kind, team and focus), with today's numbers."""
    src = template.data_source or {}
    kind = src.get("kind")
    theme = (template.content or {}).get("theme") or {}
    if kind == "hr":
        from .hr_storyboard import build_hr_storyboard

        return build_hr_storyboard(period=src.get("period") or "fytd", filters=src.get("filters") or {},
                                   focus=src.get("focus") or "", theme=theme)
    if kind in ("dei", "performance", "goals"):
        from .space_newsletter import build_space_newsletter

        return build_space_newsletter(kind, filters=src.get("filters") or {}, focus=src.get("focus") or "", theme=theme)
    if kind == "engagement":
        from .storyboard import build_storyboard

        return build_storyboard(period=src.get("period") or "30", department=src.get("department") or "",
                                focus=src.get("focus") or "", theme=theme)
    raise ValueError("This newsletter wasn't built from data.")


def spawn_copy(template: Campaign, now: datetime | None = None) -> Campaign:
    """Send this occurrence as a dated copy and move the template on to its next date (or end the series)."""
    now = now or utcnow()
    when = _local(template.scheduled_at or now)
    copy = Campaign(
        name=f"{template.name} · {when:%d %b %Y}"[:255],
        subject=template.subject,
        preheader=template.preheader,
        content=template.content,
        audience=template.audience,
        cc=list(template.cc or []),
        bcc=list(template.bcc or []),
        ai_prompt=template.ai_prompt,
        created_by_id=template.created_by_id,
        repeat_parent_id=template.id,
        data_source=template.data_source,
        status=CampaignStatus.SCHEDULED,
        scheduled_at=now,  # the worker queues it on its next cycle, like any due newsletter
    )
    notes = []
    if template.repeat_refresh and template.data_source:
        try:
            fresh = _refreshed(template)
            copy.subject, copy.preheader, copy.content = fresh["subject"], fresh["preheader"], fresh["content"]
            if fresh.get("notice"):
                notes.append(fresh["notice"])
        except Exception as exc:  # noqa: BLE001 — never skip a send because the refresh failed
            log.warning("Refresh of campaign %s failed: %s", template.id, exc)
            notes.append(f"Couldn't refresh the numbers ({exc}), so the saved version was sent.")
    db.session.add(copy)

    # next date: skip any that were missed while the app wasn't running
    count = (template.repeat_count or 0) + 1
    nxt = occurrence(template.repeat_start or template.scheduled_at, template.repeat, count)
    while nxt <= now:
        count += 1
        nxt = occurrence(template.repeat_start or template.scheduled_at, template.repeat, count)
    template.repeat_count = count
    if template.repeat_until and _local(nxt).date() > template.repeat_until:
        template.status = CampaignStatus.DRAFT
        template.scheduled_at = None
        notes.append(f"The repeating schedule ended on {template.repeat_until:%d %b %Y}.")
    else:
        template.scheduled_at = nxt
    template.last_error = " ".join(notes)
    log.info("Repeating campaign %s: sent a copy, next %s", template.id, template.scheduled_at)
    return copy

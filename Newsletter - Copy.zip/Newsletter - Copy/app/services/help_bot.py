"""Help assistant: answers how-to questions about the studio and writes prompts for the AI writer.

It knows the studio from GUIDE below (keep it in step with the UI when features change) and sees only who is
asking and where they are: role, spaces, current space and page. It never receives employee data or newsletters.
Answers stream back to the chat in the corner (static/js/help.js) as they are written.
"""

import logging
import os
from datetime import datetime

from .ai import AIError, _client

log = logging.getLogger(__name__)

MAX_TURNS = 12            # latest messages kept from a conversation
MAX_QUESTION = 2000       # characters in one question
MAX_ANSWER = 6000         # characters of an earlier answer sent back as context

GUIDE = """You are the help assistant inside Newsletter Studio, {company}'s internal tool for writing employee \
newsletters and reading people data. You answer questions about how to use the studio, and you write prompts for \
its AI writer.

How to answer:
- Lead with the answer, then the exact steps (where to click) as a short numbered list when there are steps. \
Most answers fit in 60 to 180 words. Be friendly and plain-spoken.
- Name buttons, tabs and fields exactly as they appear in the studio (see the guide below), in **bold**.
- When someone wants a prompt for the AI writer, write one complete, ready-to-use prompt in a fenced block. Open the \
block with ```prompt on its own line, or ```prompt data when the prompt relies on the studio's real numbers (the \
person should tick Include studio data), and close it with ```. Give one prompt unless they ask for options. A good \
prompt says who it's for, what to cover, the facts and numbers to use, the tone, the length and the call to action. \
Put facts only the person knows (dates, names, links, figures you don't have) in [square brackets]. After the block, \
say in one line where to paste it and whether to tick Include studio data.
- For a newsletter that is mainly numbers and charts (attrition, headcount, DEI, performance, goals), also mention \
Use your data, which builds it from the real figures with no prompt; offer a prompt too when they asked for one.
- You can't see the person's data, dashboards or newsletters, and you can't click or change anything. Never make up \
numbers, names, results or features. If something isn't possible in the studio, say so plainly.
- Remind people not to name individuals who are leaving or have left, and to keep people data at team level, when it \
matters for what they are writing.
- Questions that aren't about the studio: help briefly with general newsletter writing; otherwise say that you help \
with Newsletter Studio and internal newsletters.
- Formatting: short paragraphs, **bold** for names in the studio, short bulleted or numbered lists, and links to studio \
pages written as [text](/path) using only the paths listed in the guide. No headings, tables or HTML.
- Respect what this person can do (their role and spaces are given below). For admin-only actions, tell members to ask \
an admin.

<guide>
Pages (link paths in brackets):
- Choose your space [/spaces/]: everyone lands here after signing in. Spaces: Headcount & Attrition (headcount, \
joiners, exits, attrition), DEI (gender balance, women in leadership, hiring and attrition by gender, age groups), \
Performance (ratings, high and low performers, performance vs attrition) and Goals (goal progress, completion, goals at \
risk or overdue). Admins open every space; members open only the spaces an admin gave them. Switch any time with the \
space box at the top of the sidebar.
- Dashboard [/]: the numbers of the current space. Filters at the top (period, leader, business unit, department, \
location, gender, grade, type; Reset clears them) change every card, chart and table. KPI cards show the change against \
the previous period (green is better, red is worse; hover a number for its definition; click it to see the people). \
Charts and tables follow, then an Employees table with the first 10 matching people and Download CSV for all of them.
- Newsletters [/campaigns/]: every newsletter with tabs All, Drafts, Scheduled and Sent, plus search. New newsletter \
(here or at the top of the sidebar) creates a draft and opens the editor. A sent newsletter opens its results.
- Results of a sent newsletter: Engagement funnel, Activity over time, Top links, By department and Recipients. Opens \
are counted when images load, so they read low in Outlook; clicks are reliable.
- Newsletter insights [/insights/]: Recommendations, Best time to send, When employees read, Engagement by newsletter, \
Most engaged departments, AI topic ideas, Suggested prompts and Studio numbers.
- Employees [/recipients/] (or the search box at the top, Ctrl K): everyone who can receive newsletters, with profiles. \
Admins can add, import a CSV, pause or delete employees.
- Settings [/settings/]: Profile, Password, Application theme, and for admins Users & access (add users, admin or \
member role, which spaces each member can open). New users choose their own password at first sign-in.
- Take the tour (sidebar) replays the guided tour.

The editor (opens when you create or open a newsletter):
- Top bar: newsletter name, Undo, Preview (how employees will see it, desktop or mobile), Send test (to you or others, \
with Cc and Bcc), Save (Ctrl S; changes also save automatically) and Send / schedule.
- Left panel tabs: AI writer, Blocks, Style, Tips.
- AI writer has two modes at the top:
  1. Write a prompt: type in the Describe your newsletter box, choose New draft (start over) or Revise (change the \
current draft), then Generate. Ctrl Enter also generates. Recommended prompts below the box are built from the data \
(for example attrition by team, or a welcome for the people who joined recently, with their names filled in); click \
one, then fill in the [brackets]. Ready-made starters: All-hands recap, Policy change, Event invitation, Results with \
numbers, Security reminder. Tick Include studio data to let the AI use the studio's real figures (totals such as active \
employees and department sizes, newsletter engagement, and the current space's numbers, for example headcount, \
joiners, exits and attrition in Headcount & Attrition); What's included? lists them. No names or emails are sent to the \
AI. Refine the current draft offers one-click changes: Shorter, Warmer, Key dates, Highlight numbers, More formal.
  2. Use your data: no prompt needed. Under Numbers choose the current space's employee data or Newsletter engagement \
(opens and clicks). For employee data pick the Period, Gender and Organisation (whole company, a leader's org, a \
business unit or a department); for engagement pick the Period and Audience. Optionally type a Focus or click a \
Suggested focus, then Build newsletter. It creates KPI cards with the change, charts, tables and a short AI summary.
- Below the AI writer: To (who receives it), Cc, Bcc, Subject (what people see in their inbox) and Preview (the short \
line shown after the subject).
- To / audience: All active employees (admins only), Specific departments, or Specific employees (search and pick \
people; admins can type a new email address to add that person). Members who want to reach everyone ask an admin or \
choose departments.
- Blocks tab: drag or click to add Header, Heading, Text, Image, Button, Columns, Stats, Callout, Divider, Spacer, \
Footer. Insert studio numbers adds a Stats block with real figures. Click a block on the page to edit it; drag to \
reorder. Select text in a text block for the formatting bar (bold, italic, underline, link, lists, clear formatting).
- Style tab: Theme presets, Accent color, Page background, Email background, Text color and Font.
- Tips tab: Draft check compares the draft with your past newsletters and lists what to fix.
- Personalising: type {{{{first_name}}}} to insert each employee's first name. [Square brackets] mark placeholders the \
AI couldn't fill; the send check blocks sending while a button has no link or an image has no URL.
- Send / schedule: check the recipients (Change audience to edit), then When: Send now, Schedule for later (pick a \
date and time), or Repeat (Every day, Every week or Every month from the Send on date, with an optional Ends on date). \
A newsletter built with Use your data can Rebuild with the latest numbers before each send. Each repeat send is saved as \
its own newsletter. Best time from your data suggests a send time (Use applies it). Scheduled newsletters send while the \
app is running; Stop repeating or Cancel sending appears at the top of the editor.

Headcount & Attrition definitions (dashboard cards):
- Headcount: people employed at the end of the period. Joiners: date of joining in the period. Exits: last working \
day in the period.
- Retention rate: people employed at the start of the period who are still employed at the end of it.
- Attrition rate: exits ÷ average headcount, annualised (× 365 ÷ days in the period). Voluntary, involuntary \
(performance, restructuring, end of contract) and regrettable (usually strong performers) attrition use the same method.
- Early exits: share of the period's leavers who left within 180 days of joining.
- Women in workforce: women as a share of headcount at the end of the period. Average tenure: average time since \
joining for people employed at the end. Serving notice: people who have resigned and haven't reached their last day.
</guide>"""

PAGES = {
    "spaces": "the space chooser",
    "dashboard": "the dashboard",
    "newsletters": "the newsletters list",
    "editor": "the newsletter editor, with a newsletter open",
    "stats": "the results page of a sent newsletter",
    "insights": "Newsletter insights",
    "employees": "the Employees page",
    "settings": "Settings",
}


def ai_enabled() -> bool:
    return bool(os.environ.get("ANTHROPIC_API_KEY") or os.environ.get("ANTHROPIC_AUTH_TOKEN"))


def clean_messages(raw) -> list[dict]:
    """The conversation from the browser, checked: user/assistant text only, latest turns, ending with a question."""
    if not isinstance(raw, list) or not raw:
        raise ValueError("Type a question first.")
    out: list[dict] = []
    for m in raw[-MAX_TURNS:]:
        if not isinstance(m, dict) or m.get("role") not in ("user", "assistant") or not isinstance(m.get("content"), str):
            raise ValueError("That conversation couldn't be read. Start a new chat.")
        role, text = m["role"], m["content"].strip()
        if not text:
            continue
        if role == "user" and len(text) > MAX_QUESTION:
            raise ValueError(f"Please keep a question under {MAX_QUESTION:,} characters.")
        text = text[:MAX_ANSWER]
        if out and out[-1]["role"] == role:  # e.g. a question whose answer failed, then another question
            out[-1]["content"] += "\n\n" + text
        else:
            out.append({"role": role, "content": text})
    while out and out[0]["role"] != "user":
        out.pop(0)
    if not out or out[-1]["role"] != "user":
        raise ValueError("Type a question first.")
    return out


def system_blocks(*, company: str, role: str, spaces: list[str], space: str, page: str) -> list[dict]:
    """The guide (the same for everyone, so it can be cached) and a short note on who is asking and where."""
    who = (
        "an admin: they can open every space, manage employees and users, and send to all employees"
        if role == "admin" else
        "a member: they can't add or change employees, manage users or send to all employees (they ask an admin)"
    )
    context = "\n".join([
        "About the person asking:",
        f"- They are {who}.",
        f"- Spaces they can open: {', '.join(spaces) if spaces else 'none yet (an admin can give them access)'}.",
        f"- Current space: {space or 'none chosen yet'}.",
        f"- They are on {PAGES.get(page, 'a page of the studio')}.",
        f"- Today is {datetime.now().astimezone().strftime('%d %B %Y')}.",
    ])
    return [
        {"type": "text", "text": GUIDE.format(company=company), "cache_control": {"type": "ephemeral"}},
        {"type": "text", "text": context},
    ]


def stream_answer(messages: list[dict], system: list[dict], *, model: str, effort: str, max_tokens: int = 3000):
    """Yield {"t": text} pieces as the answer is written, then {"done": True, "cut": bool}, or {"error": message}."""
    import anthropic

    try:
        with _client().beta.messages.stream(
            model=model,
            max_tokens=max_tokens,
            betas=["server-side-fallback-2026-07-01"],
            fallbacks="default",  # if the model declines, the API retries on Anthropic's recommended fallback
            system=system,
            messages=messages,
            thinking={"type": "adaptive"},
            output_config={"effort": effort},
        ) as stream:
            wrote = False
            for text in stream.text_stream:
                if text:
                    wrote = True
                    yield {"t": text}
            final = stream.get_final_message()
    except AIError as exc:
        yield {"error": str(exc)}
        return
    except anthropic.AuthenticationError:
        yield {"error": "The Anthropic API key was rejected. Ask an admin to check ANTHROPIC_API_KEY in .env."}
        return
    except anthropic.PermissionDeniedError:
        yield {"error": "The Anthropic API key doesn't have access to this model."}
        return
    except anthropic.RateLimitError:
        yield {"error": "The assistant is busy right now. Try again in a minute."}
        return
    except anthropic.APIConnectionError:
        yield {"error": "Couldn't reach the AI service. Check the internet connection."}
        return
    except anthropic.APIStatusError as exc:
        log.exception("Help assistant API error")
        yield {"error": f"The AI service returned an error ({exc.status_code}). Try again shortly."}
        return
    except anthropic.APIError:
        log.exception("Help assistant API error")
        yield {"error": "The answer was interrupted. Try again."}
        return
    except TypeError as exc:  # raised by the SDK when no credentials are configured at all
        if "authentication" not in str(exc).lower():
            raise
        yield {"error": "The help assistant needs the AI key. Ask an admin to add ANTHROPIC_API_KEY to .env."}
        return

    if final.stop_reason == "refusal" and not wrote:
        yield {"error": "The assistant couldn't answer that. Try asking another way."}
        return
    yield {"done": True, "cut": final.stop_reason == "max_tokens"}


def suggestions(page: str, space: str | None) -> list[str]:
    """Starter questions shown in an empty chat, picked for the page."""
    if page == "editor":
        return ["How do I write a prompt for an attrition newsletter?",
                "What's the difference between Write a prompt and Use your data?",
                "How do I send this to just one department?",
                "How do I make it repeat every month?"]
    if page == "dashboard" and space == "hr":
        return ["How do I turn these numbers into a newsletter?",
                "How do I write a prompt for an attrition newsletter?",
                "How is the attrition rate calculated?",
                "Write a prompt to welcome this month's new joiners"]
    if page == "dashboard" and space:
        return ["How do I turn these numbers into a newsletter?",
                "Write a prompt for a newsletter about this space's numbers",
                "How do I share this data as a CSV?",
                "How do I schedule a monthly update?"]
    return ["How do I create my first newsletter?",
            "How do I write a prompt for an attrition newsletter?",
            "How do I schedule a weekly newsletter?",
            "Who can see which data?"]

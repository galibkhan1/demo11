"""Aggregate engagement numbers shared by the dashboard and newsletter list."""

from sqlalchemy import func

from .. import db
from ..models import Delivery, DeliveryStatus, Recipient


def campaign_metrics(campaign_ids=None) -> dict:
    """{campaign_id: {"sent", "opened", "clicked", "open_rate", "click_rate"}} for delivered emails."""
    q = db.session.query(
        Delivery.campaign_id,
        func.count(Delivery.id),
        func.count(Delivery.opened_at),
        func.count(Delivery.clicked_at),
    ).filter(Delivery.status == DeliveryStatus.SENT)
    if campaign_ids is not None:
        if not campaign_ids:
            return {}
        q = q.filter(Delivery.campaign_id.in_(campaign_ids))
    out = {}
    for cid, sent, opened, clicked in q.group_by(Delivery.campaign_id).all():
        out[cid] = {
            "sent": sent,
            "opened": opened,
            "clicked": clicked,
            "open_rate": opened / sent if sent else None,
            "click_rate": clicked / sent if sent else None,
        }
    return out


def department_engagement(campaign_ids) -> list[dict]:
    if not campaign_ids:
        return []
    rows = (
        db.session.query(
            Recipient.department, func.count(Delivery.id), func.count(Delivery.opened_at), func.count(Delivery.clicked_at)
        )
        .join(Recipient, Recipient.id == Delivery.recipient_id)
        .filter(Delivery.campaign_id.in_(campaign_ids), Delivery.status == DeliveryStatus.SENT)
        .group_by(Recipient.department)
        .all()
    )
    data = [
        {"name": d or "(none)", "sent": s, "open_rate": o / s if s else 0, "click_rate": c / s if s else 0}
        for d, s, o, c in rows
    ]
    return sorted(data, key=lambda r: r["open_rate"], reverse=True)

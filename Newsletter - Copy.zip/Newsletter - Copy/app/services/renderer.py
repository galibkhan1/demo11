"""Turns newsletter content into email HTML + plain text, with optional open/click tracking."""

import html as html_lib
import re
from dataclasses import dataclass

from flask import current_app, render_template
from itsdangerous import BadSignature, URLSafeSerializer

from .blocks import FONTS, apply_merge_tags, mix_colors, to_plain_text

TOKEN_PLACEHOLDER = "__DELIVERY_TOKEN__"
_HREF = re.compile(r'href="(https?://[^"]+)"', re.I)


@dataclass
class RenderedEmail:
    subject: str
    html: str
    text: str


def _click_serializer() -> URLSafeSerializer:
    return URLSafeSerializer(current_app.config["SECRET_KEY"], salt="newsletter-click")


def sign_url(url: str) -> str:
    return _click_serializer().dumps(url)


def unsign_url_legacy(value: str) -> str | None:
    """A click link signed with a key used before (see Config.LEGACY_LINK_KEYS). Callers must check the target."""
    for key in current_app.config.get("LEGACY_LINK_KEYS") or []:
        try:
            url = URLSafeSerializer(key, salt="newsletter-click").loads(value)
        except BadSignature:
            continue
        if isinstance(url, str) and url.startswith(("http://", "https://", "mailto:")):
            return url
    return None


def unsign_url(value: str) -> str | None:
    try:
        url = _click_serializer().loads(value)
    except BadSignature:
        return None
    return url if isinstance(url, str) and re.match(r"^https?://", url, re.I) else None


def render_html(*, subject: str, preheader: str, content: dict, preview: bool = False, pixel_url: str = "") -> str:
    theme = content["theme"]
    brand, bg = theme["brand_color"], theme["content_bg"]
    return render_template(
        "email/newsletter.html",
        subject=subject,
        preheader=preheader,
        theme=theme,
        font=FONTS[theme["font"]],
        blocks=content["blocks"],
        preview=preview,
        pixel_url=pixel_url,
        # Colors for data blocks, derived from the theme so they suit any brand color.
        tint=mix_colors(brand, bg, 0.92),  # card and insight backgrounds
        track=mix_colors(theme["text_color"], bg, 0.9),  # empty part of a bar
        shades=[brand, mix_colors(brand, bg, 0.5), mix_colors(theme["text_color"], bg, 0.82)],  # share segments, darkest first
    )


def _add_tracking(html: str) -> str:
    """Rewrite every http(s) link through the click tracker for the placeholder delivery token."""
    base = current_app.config["PUBLIC_BASE_URL"]

    def repl(match):
        target = html_lib.unescape(match.group(1))
        return f'href="{base}/t/c/{TOKEN_PLACEHOLDER}?u={sign_url(target)}"'

    return _HREF.sub(repl, html)


def render_campaign_template(campaign, *, track: bool) -> RenderedEmail:
    """Render once per campaign; per-recipient values are filled in by ``personalize``."""
    base = current_app.config["PUBLIC_BASE_URL"]
    pixel = f"{base}/t/o/{TOKEN_PLACEHOLDER}.gif" if track else ""
    html = render_html(
        subject=campaign.subject, preheader=campaign.preheader, content=campaign.content, pixel_url=pixel
    )
    if track:
        html = _add_tracking(html)
    return RenderedEmail(campaign.subject, html, to_plain_text(campaign.subject, campaign.content))


def personalize(template: RenderedEmail, *, name: str, email: str, token: str = "") -> RenderedEmail:
    return RenderedEmail(
        subject=apply_merge_tags(template.subject, name=name, email=email, escape=False),
        html=apply_merge_tags(template.html, name=name, email=email, escape=True).replace(TOKEN_PLACEHOLDER, token),
        text=apply_merge_tags(template.text, name=name, email=email, escape=False),
    )

"""Pluggable email delivery. Pick a backend with MAIL_BACKEND in .env.

* ``file`` (default): writes each message as a .eml file into OUTBOX_DIR. Open them in
  Outlook/Thunderbird or any browser-based .eml viewer to check the result. Nothing leaves the machine.
* ``smtp``: real delivery through any SMTP server — Microsoft 365, Google Workspace,
  Amazon SES (SMTP interface), Postmark, SendGrid, or your own relay.

To add another provider (e.g. an HTTP API), implement ``send`` plus ``__enter__``/``__exit__``
and register it in ``get_backend``.

Every ``send(msg, envelope)`` call passes the envelope explicitly: the exact addresses that should
receive this message. Headers (To / Cc) are only what readers see. This is how one employee's email
can show "Cc: ceo@…" without the CEO receiving a copy of every employee's email.
"""

import os
import smtplib
import ssl
import uuid
from datetime import datetime
from email.message import EmailMessage
from email.utils import formataddr, formatdate, make_msgid

from flask import current_app


def build_message(
    *,
    to_email: str = "",
    to_name: str = "",
    subject: str,
    html: str,
    text: str,
    cc: list[str] | None = None,
    to_header: str | None = None,
) -> EmailMessage:
    """Build a message. ``to_header`` overrides the To line (e.g. "undisclosed-recipients:;")."""
    cfg = current_app.config
    msg = EmailMessage()
    msg["From"] = formataddr((cfg["MAIL_FROM_NAME"], cfg["MAIL_FROM"]))
    if to_header:
        msg["To"] = to_header
    else:
        msg["To"] = formataddr((to_name, to_email)) if to_name else to_email
    if cc:
        msg["Cc"] = ", ".join(cc)
    msg["Subject"] = subject
    msg["Date"] = formatdate(localtime=True)
    msg["Message-ID"] = make_msgid(domain=cfg["MAIL_FROM"].split("@")[-1] or None)
    if cfg["MAIL_REPLY_TO"]:
        msg["Reply-To"] = cfg["MAIL_REPLY_TO"]
    msg.set_content(text)
    msg.add_alternative(html, subtype="html")
    return msg


class FileBackend:
    def __init__(self, directory: str):
        self.directory = directory

    def __enter__(self):
        os.makedirs(self.directory, exist_ok=True)
        return self

    def __exit__(self, *exc):
        return False

    def send(self, msg: EmailMessage, envelope: list[str]) -> None:
        if not envelope:
            raise ValueError("No recipients for this message.")
        # Record who would actually receive it (Bcc addresses never appear in headers).
        msg["X-Envelope-To"] = ", ".join(envelope)
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        safe_to = "".join(c if c.isalnum() or c in "@._-" else "_" for c in envelope[0])[:80]
        if len(envelope) > 1:
            safe_to += f"-and-{len(envelope) - 1}-more"
        path = os.path.join(self.directory, f"{stamp}-{safe_to}-{uuid.uuid4().hex[:6]}.eml")
        with open(path, "wb") as fh:
            fh.write(bytes(msg))


class SMTPBackend:
    """Reuses one SMTP connection for a whole batch."""

    def __init__(self, cfg):
        self.cfg = cfg
        self.conn = None

    def __enter__(self):
        cfg = self.cfg
        if cfg["SMTP_USE_SSL"]:
            self.conn = smtplib.SMTP_SSL(
                cfg["SMTP_HOST"], cfg["SMTP_PORT"], timeout=cfg["SMTP_TIMEOUT"], context=ssl.create_default_context()
            )
        else:
            self.conn = smtplib.SMTP(cfg["SMTP_HOST"], cfg["SMTP_PORT"], timeout=cfg["SMTP_TIMEOUT"])
            if cfg["SMTP_USE_TLS"]:
                self.conn.starttls(context=ssl.create_default_context())
        if cfg["SMTP_USERNAME"]:
            self.conn.login(cfg["SMTP_USERNAME"], cfg["SMTP_PASSWORD"])
        return self

    def __exit__(self, *exc):
        if self.conn is not None:
            try:
                self.conn.quit()
            except smtplib.SMTPException:
                pass
        return False

    def send(self, msg: EmailMessage, envelope: list[str]) -> None:
        if not envelope:
            raise ValueError("No recipients for this message.")
        # Explicit envelope: never derive recipients from the To/Cc headers.
        self.conn.send_message(msg, to_addrs=envelope)


def get_backend():
    cfg = current_app.config
    backend = cfg["MAIL_BACKEND"]
    if backend == "smtp":
        return SMTPBackend(cfg)
    if backend == "file":
        directory = cfg["OUTBOX_DIR"]
        if not os.path.isabs(directory):
            directory = os.path.join(os.path.dirname(current_app.root_path), directory)
        return FileBackend(directory)
    raise RuntimeError(f"Unknown MAIL_BACKEND '{backend}' (use 'file' or 'smtp').")

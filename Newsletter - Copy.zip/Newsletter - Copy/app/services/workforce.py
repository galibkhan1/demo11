"""Workforce KPIs for the dashboard: headcount, joiners, exits and attrition from employee profiles.

Definitions (shown in the UI):
- Headcount: people employed at the end of the period (joined on or before it, not yet left).
- Attrition rate: exits in the period / average headcount, annualised (x 365 / days), so periods of different
  length compare fairly. Average headcount is the mean of the headcount on 13 evenly spaced days.
- Voluntary / involuntary / regrettable attrition: the same, counting only those exits.
- Early exits: share of the period's leavers who left within 180 days of joining.
- Every card compares with the same period one year earlier.
Filters use each person's current department, business unit, location, grade and type (no transfer history).
"""

from datetime import date, timedelta

from flask import g, has_request_context

from ..models import Recipient


def _cached(key, compute):
    """Reuse a result within one web request (pages ask for the same numbers several times)."""
    if not has_request_context():
        return compute()
    store = g.setdefault("_workforce_cache", {})
    if key not in store:
        store[key] = compute()
    return store[key]


def _profiles():
    return _cached(("profiles",), lambda: Recipient.query.filter(Recipient.date_of_joining.isnot(None)).all())

PERIODS = {
    "fytd": "Financial year to date",
    "l12m": "Last 12 months",
    "l6m": "Last 6 months",
    "l90": "Last 90 days",
    "l30": "Last 30 days",
}
GRADE_BANDS = {
    "junior": ("Junior (G3–G5)", {"G3", "G4", "G5"}),
    "mid": ("Mid (G6–G7)", {"G6", "G7"}),
    "manager": ("Managers (G8)", {"G8"}),
    "leader": ("Leadership (G10+)", {"G10", "G12", "G14"}),
}
FILTER_KEYS = ("leader", "bu", "department", "location", "gender", "grade", "type")


def _fy_start(d: date) -> date:
    return date(d.year if d.month >= 4 else d.year - 1, 4, 1)  # Indian financial year: 1 April to 31 March


def _fy_label(start: date) -> str:
    return f"FY{start.year}/{str(start.year + 1)[-2:]}"


def _minus_year(d: date) -> date:
    try:
        return d.replace(year=d.year - 1)
    except ValueError:  # 29 Feb
        return d.replace(year=d.year - 1, day=28)


def window(period: str, today: date):
    if period == "fytd":
        start = _fy_start(today)
        return start, today, f"{_fy_label(start)} to date"
    days = {"l12m": 365, "l6m": 182, "l90": 90, "l30": 30}.get(period, 365)
    return today - timedelta(days=days - 1), today, PERIODS.get(period, PERIODS["l12m"])


def _employed(r, d: date) -> bool:
    return r.date_of_joining <= d and (r.date_of_exit is None or r.date_of_exit > d)


def _rate(n: int, avg_hc: float, days: int):
    return (n / avg_hc) * (365 / days) if avg_hc else None


def _measure(people, start: date, end: date) -> dict:
    days = (end - start).days + 1
    samples = [start + timedelta(days=round(i * (days - 1) / 12)) for i in range(13)]
    avg_hc = sum(sum(1 for r in people if _employed(r, d)) for d in samples) / len(samples)
    closing = [r for r in people if _employed(r, end)]
    exits = [r for r in people if r.date_of_exit and start <= r.date_of_exit <= end]
    joiners = [r for r in people if start <= r.date_of_joining <= end]
    vol = [r for r in exits if r.exit_type == "Voluntary"]
    inv = [r for r in exits if r.exit_type == "Involuntary"]
    regret = [r for r in exits if r.regrettable]
    early = [r for r in exits if (r.date_of_exit - r.date_of_joining).days < 180]
    female = [r for r in closing if r.gender == "Female"]
    opening_staff = [r for r in people if _employed(r, start - timedelta(days=1))]
    stayed = [r for r in opening_staff if _employed(r, end)]
    notice = [r for r in closing if r.date_of_resignation and r.date_of_resignation <= end]
    tenure = [(end - r.date_of_joining).days / 365.25 for r in closing]
    return {
        "headcount": len(closing),
        "opening": sum(1 for r in people if _employed(r, start - timedelta(days=1))),
        "joiners": len(joiners),
        "exits": len(exits),
        "net": len(joiners) - len(exits),
        "retention": len(stayed) / len(opening_staff) if opening_staff else None,
        "attrition": _rate(len(exits), avg_hc, days),
        "voluntary": _rate(len(vol), avg_hc, days),
        "involuntary": _rate(len(inv), avg_hc, days),
        "regrettable": _rate(len(regret), avg_hc, days),
        "early": len(early) / len(exits) if exits else None,
        "female": len(female) / len(closing) if closing else None,
        "tenure": sum(tenure) / len(tenure) if tenure else None,
        "notice": len(notice),
        "avg_headcount": avg_hc,
        "counts": {"voluntary": len(vol), "involuntary": len(inv), "regrettable": len(regret), "early": len(early),
                   "female": len(female), "stayed": len(stayed), "opening": len(opening_staff)},
    }


def _card(key, label, value, display, prev, kind, better, note, definition, link=None):
    """kind: 'pct' (delta in points), 'count', 'years'. better: 'up', 'down' or None (neutral)."""
    card = {"key": key, "label": label, "display": display, "note": note, "definition": definition,
            "delta": "", "trend": "", "good": None, "link": link}
    if value is None or prev is None:
        return card
    diff = (value - prev) * (100 if kind == "pct" else 1)
    if abs(diff) < (0.05 if kind in ("pct", "years") else 0.5):
        card.update(delta="no change", trend="flat")
        return card
    text = f"{diff:+.1f}pp" if kind == "pct" else (f"{diff:+.1f} yrs" if kind == "years" else f"{diff:+,.0f}")
    card.update(delta=text, trend="up" if diff > 0 else "down",
                good=None if better is None else ((diff > 0) == (better == "up")))
    return card


def _month_starts(end: date, n: int = 12) -> list[date]:
    y, m = end.year, end.month
    out = []
    for _ in range(n):
        out.append(date(y, m, 1))
        y, m = (y - 1, 12) if m == 1 else (y, m - 1)
    return out[::-1]


def _counts(items, order=None, limit=None):
    tally = {}
    for v in items:
        tally[v or "Not set"] = tally.get(v or "Not set", 0) + 1
    rows = sorted(tally.items(), key=lambda kv: (order.index(kv[0]) if order and kv[0] in order else 99, -kv[1], kv[0]))
    if limit and len(rows) > limit:  # fold the long tail into "Other"
        rows = rows[: limit - 1] + [("Other", sum(v for _, v in rows[limit - 1:]))]
    return [{"label": k, "value": v} for k, v in rows]


def charts(people, start: date, end: date) -> dict:
    """Breakdowns for the dashboard charts and tables (same filters as the KPI cards)."""
    closing = [r for r in people if _employed(r, end)]
    exits = [r for r in people if r.date_of_exit and start <= r.date_of_exit <= end]

    trend = []
    for first in _month_starts(end):
        nxt = date(first.year + (first.month == 12), first.month % 12 + 1, 1)
        last = min(end, nxt - timedelta(days=1))
        trend.append({
            "t": first.isoformat(), "label": f"{first:%b %y}",
            "headcount": sum(1 for r in people if _employed(r, last)),
            "joiners": sum(1 for r in people if first <= r.date_of_joining <= last),
            "exits": sum(1 for r in people if r.date_of_exit and first <= r.date_of_exit <= last),
        })

    def group_rows(attr):
        groups = {}
        for r in people:
            groups.setdefault(getattr(r, attr) or "Not set", []).append(r)
        rows = []
        for name, members in groups.items():
            m = _measure(members, start, end)
            if not m["headcount"] and not m["exits"]:
                continue
            rows.append({"name": name, "bu": members[0].business_unit or "", "headcount": m["headcount"],
                         "joiners": m["joiners"], "exits": m["exits"], "attrition": m["attrition"],
                         "voluntary": m["voluntary"], "regrettable": m["regrettable"], "female": m["female"]})
        return sorted(rows, key=lambda x: (-x["headcount"], x["name"]))

    def band(r):
        years = (end - r.date_of_joining).days / 365.25
        return ("Under 1 year" if years < 1 else "1–2 years" if years < 2 else "2–3 years" if years < 3
                else "3–5 years" if years < 5 else "5+ years")

    def person(r, when):
        return {"id": r.id, "name": r.name or r.email, "designation": r.designation or "", "department": r.department or "",
                "date": when.isoformat() if when else "", "type": r.exit_type or "", "reason": r.exit_reason or "",
                "regrettable": r.regrettable}

    notice = sorted((r for r in closing if r.date_of_resignation and r.date_of_resignation <= end),
                    key=lambda r: r.date_of_exit or date.max)
    recent = sorted(exits, key=lambda r: r.date_of_exit, reverse=True)
    tenure_order = ["Under 1 year", "1–2 years", "2–3 years", "3–5 years", "5+ years"]
    return {
        "trend": trend,
        "by_bu": group_rows("business_unit"),
        "by_department": group_rows("department"),
        "gender": _counts([r.gender for r in closing], ["Female", "Male", "Non-binary"]),
        "employment_type": _counts([r.employment_type for r in closing], ["Permanent", "Contract", "Intern"]),
        "exit_type": _counts([r.exit_type for r in exits], ["Voluntary", "Involuntary"]),
        "exit_reasons": _counts([r.exit_reason for r in exits], limit=8),
        "tenure": [x for x in _counts([band(r) for r in closing], tenure_order)],
        "location": _counts([r.location for r in closing], limit=8),
        "notice": [person(r, r.date_of_exit) for r in notice[:12]],
        "notice_total": len(notice),
        "recent_exits": [person(r, r.date_of_exit) for r in recent[:12]],
        "exits_total": len(exits),
    }


def org_ids(everyone, leader_id) -> set:
    """The leader plus everyone who reports up to them (directly or through managers)."""
    children = {}
    for r in everyone:
        if r.manager_id:
            children.setdefault(r.manager_id, []).append(r.id)
    seen, stack = set(), [leader_id]
    while stack:
        x = stack.pop()
        if x not in seen:
            seen.add(x)
            stack.extend(children.get(x, []))
    return seen


def leader_options(everyone) -> list[dict]:
    """People who lead a team (have direct reports), most senior first, with the size of their org."""
    return _cached(("leaders", len(everyone)), lambda: _leader_options(everyone))


def _leader_options(everyone) -> list[dict]:
    today = date.today()
    children = {}
    for r in everyone:
        if r.manager_id:
            children.setdefault(r.manager_id, []).append(r.id)
    sizes = {}

    def org_size(x, depth=0):  # everyone below x, counted once per person (memoised)
        if x not in sizes:
            sizes[x] = 0 if depth > 50 else sum(1 + org_size(c, depth + 1) for c in children.get(x, []))
        return sizes[x]

    grade_rank = {"G14": 0, "G12": 1, "G10": 2, "G8": 3, "G7": 4}
    out = []
    for r in everyone:
        if r.id in children and _employed(r, today):
            size = org_size(r.id)
            out.append({"value": str(r.id), "label": f"{r.name} · {r.designation or r.department} ({size})",
                        "name": r.name, "designation": r.designation or "", "size": size,
                        "rank": grade_rank.get(r.grade, 9)})
    out.sort(key=lambda x: (x["rank"], -x["size"], x["name"]))
    return out


def select_people(filters: dict, everyone):
    """Apply the dashboard filters. Returns (people, scope label)."""
    leader = None
    if filters.get("leader"):
        try:
            leader_id = int(filters["leader"])
        except ValueError:
            leader_id = None
        leader = next((r for r in everyone if r.id == leader_id), None)
    org = org_ids(everyone, leader.id) if leader else None

    def keep(r):
        if org is not None and r.id not in org:
            return False
        if filters.get("bu") and r.business_unit != filters["bu"]:
            return False
        if filters.get("department") and r.department != filters["department"]:
            return False
        if filters.get("location") and r.location != filters["location"]:
            return False
        if filters.get("gender") and r.gender != filters["gender"]:
            return False
        if filters.get("type") and r.employment_type != filters["type"]:
            return False
        if filters.get("grade") and r.grade not in GRADE_BANDS.get(filters["grade"], ("", set()))[1]:
            return False
        return True

    parts = []
    if leader:
        parts.append(f"{leader.name}'s org")
    for key in ("bu", "department", "location"):
        if filters.get(key):
            parts.append(filters[key])
    if filters.get("gender"):
        parts.append(filters["gender"])
    if filters.get("grade"):
        parts.append(GRADE_BANDS.get(filters["grade"], (filters["grade"],))[0])
    if filters.get("type"):
        parts.append(filters["type"])
    return [r for r in everyone if keep(r)], (" · ".join(parts) or "All employees"), leader


def options(people) -> dict:
    def distinct(attr):
        return sorted({getattr(r, attr) for r in people if getattr(r, attr)})

    dept_by_bu = {}
    for r in people:
        if r.business_unit and r.department:
            dept_by_bu.setdefault(r.business_unit, set()).add(r.department)
    return {
        "periods": [{"value": k, "label": v} for k, v in PERIODS.items()],
        "bu": distinct("business_unit"),
        "department": distinct("department"),
        "dept_by_bu": {k: sorted(v) for k, v in dept_by_bu.items()},
        "location": distinct("location"),
        "gender": distinct("gender"),
        "grade": [{"value": k, "label": v[0]} for k, v in GRADE_BANDS.items()],
        "type": distinct("employment_type"),
        "leader": [{"value": x["value"], "label": x["label"]} for x in leader_options(people)],
    }


def workforce_kpis(period: str = "fytd", filters: dict | None = None, today: date | None = None) -> dict:
    today = today or date.today()
    filters = {k: (filters or {}).get(k) or "" for k in FILTER_KEYS}
    return _cached(("kpis", period, tuple(sorted(filters.items())), today),
                   lambda: _workforce_kpis(period, filters, today))


def _workforce_kpis(period: str, filters: dict, today: date) -> dict:
    everyone = _profiles()
    if not everyone:
        return {"empty": True}

    people, scope_label, _leader = select_people(filters, everyone)
    period = period if period in PERIODS else "fytd"
    start, end, label = window(period, today)
    prev_start, prev_end = _minus_year(start), _minus_year(end)
    prev_label = f"{_fy_label(prev_start)} same period" if period == "fytd" else "same period last year"
    cur, prev = _measure(people, start, end), _measure(people, prev_start, prev_end)

    def pct(x):
        return "–" if x is None else f"{x * 100:.1f}%"

    link_base = {k: v for k, v in (("bu", filters["bu"]), ("department", filters["department"])) if v}
    c = cur["counts"]
    cards = [
        _card("headcount", "Headcount", cur["headcount"], f"{cur['headcount']:,}", prev["headcount"], "count", None,
              f"opening {cur['opening']:,}", "People employed at the end of the period.", {**link_base, "status": "employed"}),
        _card("joiners", "Joiners", cur["joiners"], f"{cur['joiners']:,}", prev["joiners"], "count", None,
              "joined in the period", "People whose date of joining is in the period."),
        _card("exits", "Exits", cur["exits"], f"{cur['exits']:,}", prev["exits"], "count", "down",
              f"{c['voluntary']} voluntary · {c['involuntary']} involuntary", "People whose last working day is in the period.",
              {**link_base, "status": "exited"}),
        _card("retention", "Retention rate", cur["retention"], pct(cur["retention"]), prev["retention"], "pct", "up",
              f"{c['stayed']:,} of {c['opening']:,} stayed", "People employed at the start of the period who are still employed at the end of it."),
        _card("attrition", "Attrition rate", cur["attrition"], pct(cur["attrition"]), prev["attrition"], "pct", "down",
              "annualised", "Exits ÷ average headcount, annualised (× 365 ÷ days in the period)."),
        _card("voluntary", "Voluntary attrition", cur["voluntary"], pct(cur["voluntary"]), prev["voluntary"], "pct", "down",
              f"{c['voluntary']} resigned", "Voluntary exits ÷ average headcount, annualised."),
        _card("involuntary", "Involuntary attrition", cur["involuntary"], pct(cur["involuntary"]), prev["involuntary"], "pct", "down",
              f"{c['involuntary']} let go", "Involuntary exits (performance, restructuring, end of contract…) ÷ average headcount, annualised."),
        _card("regrettable", "Regrettable attrition", cur["regrettable"], pct(cur["regrettable"]), prev["regrettable"], "pct", "down",
              f"{c['regrettable']} we wanted to keep", "Exits marked regrettable (usually strong performers) ÷ average headcount, annualised."),
        _card("early", "Early exits", cur["early"], pct(cur["early"]), prev["early"], "pct", "down",
              f"{c['early']} left within 6 months", "Share of the period's leavers who left within 180 days of joining."),
        _card("female", "Women in workforce", cur["female"], pct(cur["female"]), prev["female"], "pct", "up",
              f"{c['female']:,} of {cur['headcount']:,} employees", "Women as a share of headcount at the end of the period."),
        _card("tenure", "Average tenure", cur["tenure"], "–" if cur["tenure"] is None else f"{cur['tenure']:.1f} yrs",
              prev["tenure"], "years", None, "of people employed now", "Average time since joining, for people employed at the end of the period."),
        _card("notice", "Serving notice", cur["notice"], f"{cur['notice']:,}", prev["notice"], "count", "down",
              "resigned, not yet left", "People who have resigned and haven't reached their last day.", {**link_base, "status": "notice"}),
    ]
    return {
        "empty": False,
        "period": period,
        "filters": filters,
        "label": label,
        "range": f"{start:%d %b %Y} to {end:%d %b %Y}",
        "compare_label": prev_label,
        "compare_range": f"{prev_start:%d %b %Y} to {prev_end:%d %b %Y}",
        "population": len(people),
        "scope": scope_label,
        "cards": cards,
        "charts": charts(people, start, end),
        "options": options(everyone),
    }

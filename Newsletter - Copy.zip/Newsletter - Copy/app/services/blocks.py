"""Newsletter content model shared by the editor, the AI generator and the email renderer.

A newsletter is ``{"theme": {...}, "blocks": [...]}``. Every block has an ``id`` and a ``type``;
the remaining fields depend on the type (see ``BLOCK_DEFAULTS``). Everything coming from the
browser or from the model goes through ``sanitize_content`` before it is stored or rendered.
"""

import html
import re
import secrets

import nh3

FONTS = {
    "system": "-apple-system, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif",
    "georgia": "Georgia, 'Times New Roman', serif",
    "verdana": "Verdana, Geneva, sans-serif",
    "trebuchet": "'Trebuchet MS', Helvetica, sans-serif",
}

DEFAULT_THEME = {
    "brand_color": "#2563eb",
    "background": "#f1f5f9",
    "content_bg": "#ffffff",
    "text_color": "#1e293b",
    "font": "system",
}

BLOCK_DEFAULTS = {
    "header": {"eyebrow": "", "title": "Company Newsletter", "subtitle": "", "bg_color": "", "text_color": "#ffffff"},
    "heading": {"text": "Section heading", "level": 2, "align": "left"},
    "text": {"html": "<p>Write something great…</p>", "align": "left"},
    "image": {"src": "", "alt": "", "href": "", "width": 100},
    "button": {"label": "Read more", "href": "", "align": "center", "color": "", "text_color": "#ffffff"},
    "columns": {"left_html": "<p>Left column</p>", "right_html": "<p>Right column</p>"},
    "divider": {},
    "spacer": {"height": 24},
    "footer": {"html": "<p>You are receiving this because you work here.</p>", "style": "light"},
    # Big highlight figures ("12%  Revenue above target"). 1 to 4 items side by side.
    "stats": {
        "items": [
            {"value": "[number]", "label": "What it measures", "note": ""},
            {"value": "[number]", "label": "What it measures", "note": ""},
            {"value": "[number]", "label": "What it measures", "note": ""},
        ],
        "color": "",
    },
    # Highlighted summary box ("Executive insights").
    "insight": {"label": "Executive insights", "html": "<p>Summarise the most important numbers and what they mean.</p>"},
    # Data blocks, built by the storyboard from the studio's numbers (services/storyboard.py).
    "bars": {"title": "Bar chart", "subtitle": "", "items": [{"label": "Item", "value": 1, "display": "1"}], "color": ""},
    "table": {"title": "Table", "subtitle": "", "columns": ["Name", "Value"], "rows": [["Item", "1"]], "bars": []},
    "share": {"title": "Share", "subtitle": "", "items": [{"label": "Part", "value": 1, "display": "100%"}]},
}

MAX_STATS = 8
DATA_TYPES = {"bars", "table", "share"}
TRENDS = {"up", "down", "flat"}

ALIGNS = {"left", "center", "right"}
_HEX = re.compile(r"^#[0-9a-fA-F]{6}$")
_ID = re.compile(r"^[A-Za-z0-9_-]{1,40}$")

_ALLOWED_TAGS = {"p", "br", "strong", "b", "em", "i", "u", "s", "a", "ul", "ol", "li", "blockquote", "span"}
_ALLOWED_ATTRS = {"a": {"href", "title"}}
_MERGE_TAG = re.compile(r"\{\{\s*(first_name|name|email)\s*\}\}")


def new_block_id() -> str:
    return "b" + secrets.token_hex(5)


def clean_html(value) -> str:
    return nh3.clean(
        str(value or ""),
        tags=_ALLOWED_TAGS,
        attributes=_ALLOWED_ATTRS,
        url_schemes={"http", "https", "mailto"},
        link_rel="noopener",
    )


def clean_text(value, limit: int = 500) -> str:
    return str(value or "").replace("\x00", "").strip()[:limit]


def clean_url(value, *, allow_empty: bool = True) -> str:
    url = str(value or "").strip()[:2000]
    if not url and allow_empty:
        return ""
    if re.match(r"^(https?://|mailto:)", url, re.I):
        return url
    return ""


def clean_color(value, default: str) -> str:
    value = str(value or "").strip()
    return value if _HEX.match(value) else default


def _clamp_int(value, lo: int, hi: int, default: int) -> int:
    try:
        return max(lo, min(hi, int(value)))
    except (TypeError, ValueError):
        return default


def _clean_number(value) -> float:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return 0.0
    return number if number == number and 0 <= number < 1e12 else 0.0  # drop NaN / negatives / absurd values


def mix_colors(hex_a: str, hex_b: str, t: float) -> str:
    """Blend hex_a toward hex_b by t (0 = a, 1 = b). Used for tints of the brand color."""
    a = [int(hex_a[i:i + 2], 16) for i in (1, 3, 5)]
    b = [int(hex_b[i:i + 2], 16) for i in (1, 3, 5)]
    return "#" + "".join(f"{round(x + (y - x) * t):02x}" for x, y in zip(a, b))


def sanitize_theme(theme) -> dict:
    theme = theme if isinstance(theme, dict) else {}
    return {
        "brand_color": clean_color(theme.get("brand_color"), DEFAULT_THEME["brand_color"]),
        "background": clean_color(theme.get("background"), DEFAULT_THEME["background"]),
        "content_bg": clean_color(theme.get("content_bg"), DEFAULT_THEME["content_bg"]),
        "text_color": clean_color(theme.get("text_color"), DEFAULT_THEME["text_color"]),
        "font": theme.get("font") if theme.get("font") in FONTS else DEFAULT_THEME["font"],
    }


def sanitize_block(block):
    if not isinstance(block, dict) or block.get("type") not in BLOCK_DEFAULTS:
        return None
    btype = block["type"]
    bid = block.get("id") if isinstance(block.get("id"), str) and _ID.match(block["id"]) else new_block_id()
    out = {"id": bid, "type": btype}
    align = block.get("align") if block.get("align") in ALIGNS else None

    if block.get("from_data") is True:
        out["from_data"] = True  # generated from the studio's numbers; AI revisions keep it unchanged
    if btype == "header":
        out.update(
            eyebrow=clean_text(block.get("eyebrow"), 60),
            title=clean_text(block.get("title"), 200),
            subtitle=clean_text(block.get("subtitle"), 300),
            bg_color=clean_color(block.get("bg_color"), ""),
            text_color=clean_color(block.get("text_color"), "#ffffff"),
        )
    elif btype == "heading":
        out.update(
            text=clean_text(block.get("text"), 300),
            level=_clamp_int(block.get("level"), 1, 3, 2),
            align=align or "left",
        )
    elif btype == "text":
        out.update(html=clean_html(block.get("html")), align=align or "left")
    elif btype == "image":
        out.update(
            src=clean_url(block.get("src")),
            alt=clean_text(block.get("alt"), 300),
            href=clean_url(block.get("href")),
            width=_clamp_int(block.get("width"), 10, 100, 100),
        )
    elif btype == "button":
        out.update(
            label=clean_text(block.get("label"), 80),
            href=clean_url(block.get("href")),
            align=align or "center",
            color=clean_color(block.get("color"), ""),
            text_color=clean_color(block.get("text_color"), "#ffffff"),
        )
    elif btype == "columns":
        out.update(left_html=clean_html(block.get("left_html")), right_html=clean_html(block.get("right_html")))
    elif btype == "spacer":
        out.update(height=_clamp_int(block.get("height"), 4, 120, 24))
    elif btype == "footer":
        out.update(html=clean_html(block.get("html")), style="dark" if block.get("style") == "dark" else "light")
    elif btype == "stats":
        items = []
        for item in block.get("items") if isinstance(block.get("items"), list) else []:
            if not isinstance(item, dict):
                continue
            value, label = clean_text(item.get("value"), 24), clean_text(item.get("label"), 80)
            if value or label:
                good = item.get("good")
                items.append({
                    "value": value, "label": label, "note": clean_text(item.get("note"), 100),
                    "delta": clean_text(item.get("delta"), 20),
                    "trend": item.get("trend") if item.get("trend") in TRENDS else "",
                    "good": good if isinstance(good, bool) else None,
                })
        if not items:
            return None
        out.update(
            items=items[:MAX_STATS],
            color=clean_color(block.get("color"), ""),
            title=clean_text(block.get("title"), 200),
            subtitle=clean_text(block.get("subtitle"), 300),
            columns=_clamp_int(block.get("columns"), 0, 4, 0),  # 0 = as many as fit (up to 4)
            align="left" if block.get("align") == "left" else "center",
            size="large" if block.get("size") == "large" else "normal",
        )
    elif btype == "insight":
        out.update(label=clean_text(block.get("label"), 60), html=clean_html(block.get("html")))
    elif btype in ("bars", "share"):
        items = []
        for item in block.get("items") if isinstance(block.get("items"), list) else []:
            if isinstance(item, dict) and clean_text(item.get("label"), 80):
                items.append({
                    "label": clean_text(item.get("label"), 80),
                    "value": _clean_number(item.get("value")),
                    "display": clean_text(item.get("display"), 24),
                })
        if not items:
            return None
        out.update(title=clean_text(block.get("title"), 200), subtitle=clean_text(block.get("subtitle"), 300),
                   items=items[:20 if btype == "bars" else 5])
        if btype == "bars":
            out["color"] = clean_color(block.get("color"), "")
    elif btype == "table":
        columns = [clean_text(c, 40) for c in (block.get("columns") or [])][:6] if isinstance(block.get("columns"), list) else []
        if not columns:
            return None
        rows = []
        for row in block.get("rows") if isinstance(block.get("rows"), list) else []:
            if isinstance(row, list):
                cells = [clean_text(c, 80) for c in row][: len(columns)]
                rows.append(cells + [""] * (len(columns) - len(cells)))
        bars = block.get("bars") if isinstance(block.get("bars"), list) else []
        bars = [min(1.0, _clean_number(b)) for b in bars][: len(rows[:30])]
        out.update(title=clean_text(block.get("title"), 200), subtitle=clean_text(block.get("subtitle"), 300),
                   columns=columns, rows=rows[:30], bars=bars if len(bars) == len(rows[:30]) else [])
    return out


def sanitize_content(content) -> dict:
    content = content if isinstance(content, dict) else {}
    raw_blocks = content.get("blocks") if isinstance(content.get("blocks"), list) else []
    blocks, seen = [], set()
    for raw in raw_blocks[:200]:
        block = sanitize_block(raw)
        if block is None:
            continue
        if block["id"] in seen:
            block["id"] = new_block_id()
        seen.add(block["id"])
        blocks.append(block)
    return {"theme": sanitize_theme(content.get("theme")), "blocks": blocks}


def preflight_problems(subject: str, content: dict) -> list[str]:
    """Things that must be fixed before a campaign can be scheduled."""
    problems = []
    if not subject.strip():
        problems.append("Add a subject line.")
    blocks = content.get("blocks", [])
    if not blocks:
        problems.append("The newsletter has no content blocks.")
    for i, block in enumerate(blocks, start=1):
        if block["type"] == "button" and not block.get("href"):
            problems.append(f"Block {i} (button “{block.get('label', '')}”) has no link URL.")
        if block["type"] == "image" and not block.get("src"):
            problems.append(f"Block {i} (image) has no image URL.")
    return problems


def apply_merge_tags(text: str, *, name: str, email: str, escape: bool) -> str:
    first = (name or "").split(" ")[0] if name else ""
    values = {"name": name or "there", "first_name": first or "there", "email": email}

    def repl(match):
        value = values[match.group(1)]
        return html.escape(value) if escape else value

    return _MERGE_TAG.sub(repl, text)


def _html_to_text(fragment: str) -> str:
    fragment = re.sub(r'<a [^>]*href="([^"]+)"[^>]*>(.*?)</a>', r"\2 (\1)", fragment, flags=re.S | re.I)
    fragment = re.sub(r"<li[^>]*>", "\n  • ", fragment, flags=re.I)
    fragment = re.sub(r"</(p|blockquote|ul|ol)>|<br\s*/?>", "\n", fragment, flags=re.I)
    text = html.unescape(re.sub(r"<[^>]+>", "", fragment))
    return re.sub(r"\n{3,}", "\n\n", text).strip()


def to_plain_text(subject: str, content: dict) -> str:
    """Plain-text alternative part for the email (helps deliverability and accessibility)."""
    lines = []
    for block in content.get("blocks", []):
        t = block["type"]
        if t == "header":
            lines += ([block["eyebrow"].upper()] if block.get("eyebrow") else []) + [block["title"].upper(), block["subtitle"]]
        elif t == "heading":
            lines += [block["text"], "-" * min(len(block["text"]), 60)]
        elif t in ("text", "footer"):
            lines.append(_html_to_text(block["html"]))
        elif t == "columns":
            lines += [_html_to_text(block["left_html"]), _html_to_text(block["right_html"])]
        elif t == "button" and block.get("href"):
            lines.append(f"{block['label']}: {block['href']}")
        elif t == "image" and block.get("alt"):
            lines.append(f"[{block['alt']}]")
        elif t == "divider":
            lines.append("—" * 20)
        elif t == "stats":
            if block.get("title"):
                lines += [block["title"].upper()]
            for item in block["items"]:
                note = f" ({item['note']})" if item.get("note") else ""
                arrow = {"up": "▲ ", "down": "▼ "}.get(item.get("trend"), "")
                delta = f"  [{arrow}{item['delta']}]" if item.get("delta") else ""
                lines.append(f"  {item['value']}  {item['label']}{note}{delta}".rstrip())
        elif t == "insight":
            lines += [block["label"].upper(), _html_to_text(block["html"])]
        elif t in ("bars", "share"):
            lines += [block["title"].upper()] + ([block["subtitle"]] if block.get("subtitle") else [])
            lines += [f"  {i['label']}: {i['display']}" for i in block["items"]]
        elif t == "table":
            lines += [block["title"].upper()] + ([block["subtitle"]] if block.get("subtitle") else [])
            lines.append("  " + " | ".join(block["columns"]))
            lines += ["  " + " | ".join(row) for row in block["rows"]]
        lines.append("")
    return "\n".join(line for line in lines if line is not None).strip() or subject

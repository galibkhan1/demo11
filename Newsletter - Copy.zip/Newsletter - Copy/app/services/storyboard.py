"""Engagement storyboard: a data newsletter built from the studio's own numbers.

Layout (top to bottom): banner, executive insights, two headline KPI cards with change vs the previous
period, a key-metrics grid, open rate by newsletter (bars), who opened (share bar), engagement by
department and most-clicked links (tables), what to try next, a link to the Insights page and a footer
with the definitions. Every number comes from the local database; the AI (when enabled) only writes the
summary paragraph from those numbers.
"""

import logging
import os
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from statistics import median

from flask import current_app

from .. import db
from ..models import Campaign, CampaignStatus, Delivery, DeliveryStatus, Event, Recipient
from .blocks import sanitize_content
from .insights import _link_labels, recommendations, snapshot

log = logging.getLogger(__name__)

PERIODS = {
    "30": ("Last 30 days", 30),
    "90": ("Last 90 days", 90),
    "365": ("Last 12 months", 365),
    "all": ("All time", None),
}


def _aware(dt):
    if dt is None:
        return None
    return dt.replace(tzinfo=timezone.utc) if dt.tzinfo is None else dt


def pct(x, digits: int = 1) -> str:
    return "–" if x is None else f"{x * 100:.{digits}f}%"


def _rate(a: int, b: int):
    return a / b if b else None


def _hours(h) -> str:
    if h is None:
        return "–"
    return f"{max(1, round(h * 60))} min" if h < 1 else f"{h:.1f} h"


@dataclass
class Window:
    start: datetime | None
    end: datetime


@dataclass
class Metrics:
    newsletters: list = field(default_factory=list)
    delivered: int = 0
    failed: int = 0
    opened: int = 0
    clicked: int = 0
    recipients: int = 0
    readers: int = 0
    clickers: int = 0
    median_hours: float | None = None
    departments: dict = field(default_factory=dict)
    links: list = field(default_factory=list)

    @property
    def sent(self) -> int:
        return len(self.newsletters)

    @property
    def open_rate(self):
        return _rate(self.opened, self.delivered)

    @property
    def click_rate(self):
        return _rate(self.clicked, self.delivered)

    @property
    def click_to_open(self):
        return _rate(self.clicked, self.opened)

    @property
    def reach(self):
        return _rate(self.readers, self.recipients)


def _in(win: Window, dt) -> bool:
    dt = _aware(dt)
    return dt is not None and dt < win.end and (win.start is None or dt >= win.start)


def _load():
    campaigns = (
        Campaign.query.filter(Campaign.status == CampaignStatus.SENT, Campaign.started_at.isnot(None))
        .order_by(Campaign.started_at)
        .all()
    )
    ids = [c.id for c in campaigns]
    rows = []
    if ids:
        rows = (
            db.session.query(Delivery.id, Delivery.campaign_id, Delivery.recipient_id, Delivery.email, Delivery.status,
                             Delivery.opened_at, Delivery.clicked_at, Recipient.department)
            .outerjoin(Recipient, Recipient.id == Delivery.recipient_id)
            .filter(Delivery.campaign_id.in_(ids))
            .all()
        )
    return campaigns, rows


def window_metrics(win: Window, department: str, campaigns, rows) -> Metrics:
    m = Metrics()
    chosen = {c.id: c for c in campaigns if _in(win, c.started_at)}
    if not chosen:
        return m
    per = {cid: [0, 0, 0] for cid in chosen}  # delivered, opened, clicked
    people, readers, clickers = set(), set(), set()
    delays = []
    depts = defaultdict(lambda: [0, 0, 0])
    delivery_dept = {}
    for did, cid, rid, email, status, opened_at, clicked_at, dept in rows:
        if cid not in chosen or (department and dept != department):
            continue
        delivery_dept[did] = dept
        if status == DeliveryStatus.FAILED:
            m.failed += 1
            continue
        if status != DeliveryStatus.SENT:
            continue
        key = rid or email
        m.delivered += 1
        per[cid][0] += 1
        people.add(key)
        depts[dept or "(no department)"][0] += 1
        if opened_at:
            m.opened += 1
            per[cid][1] += 1
            readers.add(key)
            depts[dept or "(no department)"][1] += 1
            delays.append(max(0.0, (_aware(opened_at) - _aware(chosen[cid].started_at)).total_seconds() / 3600))
        if clicked_at:
            m.clicked += 1
            per[cid][2] += 1
            clickers.add(key)
            depts[dept or "(no department)"][2] += 1
    m.recipients, m.readers, m.clickers = len(people), len(readers), len(clickers)
    m.median_hours = median(delays) if delays else None
    m.departments = {d: {"delivered": v[0], "opened": v[1], "clicked": v[2]} for d, v in depts.items()}
    for cid, c in chosen.items():
        d, o, k = per[cid]
        if d:
            m.newsletters.append({"name": c.name, "date": _aware(c.started_at), "delivered": d,
                                  "open_rate": o / d, "click_rate": k / d})

    clicks = (
        db.session.query(Event.campaign_id, Event.url, Event.delivery_id)
        .filter(Event.campaign_id.in_(list(chosen)), Event.type == "click")
        .all()
    )
    labels = {cid: _link_labels(c.content) for cid, c in chosen.items()}
    who = defaultdict(set)
    for cid, url, did in clicks:
        if did in delivery_dept:  # respects the department filter
            who[(labels[cid].get(url, url), chosen[cid].name)].add(did)
    m.links = sorted(((label, name, len(ids)) for (label, name), ids in who.items()), key=lambda x: -x[2])[:5]
    return m


def _delta_pp(cur, prev):
    if cur is None or prev is None:
        return None
    return (cur - prev) * 100


def _card(value, label, note="", delta=None, unit="pp", higher_is_better=True, eps=0.05):
    """A KPI card. delta is a number (percentage points or a count); None means no comparison."""
    item = {"value": value, "label": label, "note": note, "delta": "", "trend": "", "good": None}
    if delta is not None:
        if abs(delta) < eps:
            item.update(delta="no change", trend="flat")
        else:
            up = delta > 0
            text = f"{delta:+.1f}pp" if unit == "pp" else (f"{delta:+.1f} h" if unit == "h" else f"{delta:+,.0f}")
            item.update(delta=text, trend="up" if up else "down",
                        good=None if higher_is_better is None else (up == higher_is_better))
    return item


def facts_for_ai(label: str, scope: str, cur: Metrics, prev: Metrics | None, headcount: int, added: int,
                 dept_rows: list, compare_label: str, joiners_leavers: tuple | None = None) -> str:
    lines = [f"Period: {label}. Audience: {scope}. Comparison: {compare_label}."]

    def line(name, now, before=None, kind="pct"):
        if kind == "pct":
            s = f"- {name}: {pct(now)}"
            if before is not None and now is not None:
                s += f" (previous period {pct(before)}, change {(now - before) * 100:+.1f} percentage points)"
        else:
            s = f"- {name}: {now}" + (f" (previous period {before})" if before is not None else "")
        lines.append(s)

    p = prev if prev and prev.sent else None
    line("Newsletters sent", cur.sent, p.sent if p else None, "n")
    line("Emails delivered", cur.delivered, p.delivered if p else None, "n")
    line("Open rate", cur.open_rate, p.open_rate if p else None)
    line("Click rate", cur.click_rate, p.click_rate if p else None)
    line("Click-to-open rate", cur.click_to_open, p.click_to_open if p else None)
    line("Employees who received at least one newsletter", cur.recipients, p.recipients if p else None, "n")
    line("Employees who opened at least one (reach)", f"{cur.readers} ({pct(cur.reach)})",
         f"{p.readers} ({pct(p.reach)})" if p else None, "n")
    line("Employees who opened none", cur.recipients - cur.readers, None, "n")
    line("Median time from send to first open", _hours(cur.median_hours), _hours(p.median_hours) if p else None, "n")
    line("Failed deliveries", cur.failed, p.failed if p else None, "n")
    line("Active employees now", headcount, None, "n")
    if joiners_leavers:
        line("Employees who joined the company in this period", joiners_leavers[0], None, "n")
        line("Employees who left the company in this period", joiners_leavers[1], None, "n")
    else:
        line("Employees added to the studio in this period", added, None, "n")
    if cur.newsletters:
        lines.append("Newsletters in this period: " + "; ".join(
            f"{n['name']} ({n['date'].strftime('%d %b')}, opened {pct(n['open_rate'])}, clicked {pct(n['click_rate'])})"
            for n in cur.newsletters))
    if dept_rows:
        lines.append("By department (open rate, click rate, change in open rate): " + "; ".join(
            f"{r['name']} {pct(r['open'])}, {pct(r['click'])}" + (f", {r['delta']:+.1f}pp" if r["delta"] is not None else "")
            for r in dept_rows))
    if cur.links:
        lines.append("Most-clicked links: " + "; ".join(f"{a} in {b} ({n} people)" for a, b, n in cur.links))
    return "\n".join(lines)


def rule_summary(label: str, scope: str, cur: Metrics, prev: Metrics | None, dept_rows: list) -> str:
    if not cur.sent:
        return (f"<p>No newsletters were sent to {scope.lower()} in this period ({label.lower()}), so there is no "
                "engagement to report yet.</p>")
    p = prev if prev and prev.sent else None
    parts = [f"{cur.sent} newsletter{'s' if cur.sent != 1 else ''} reached {cur.recipients:,} employees "
             f"({label.lower()}). <strong>{pct(cur.open_rate)}</strong> of the emails were opened"]
    if p and p.open_rate is not None:
        d = (cur.open_rate - p.open_rate) * 100
        parts[-1] += f" ({d:+.1f}pp on the previous period)" if abs(d) >= 0.05 else " (unchanged on the previous period)"
    parts[-1] += f" and {pct(cur.click_rate)} had a click."
    parts.append(f"{cur.readers:,} people ({pct(cur.reach)}) opened at least one; "
                 f"{cur.recipients - cur.readers:,} didn't open any.")
    if cur.newsletters:
        best = max(cur.newsletters, key=lambda n: n["open_rate"])
        parts.append(f"The most-read was <strong>{best['name']}</strong> at {pct(best['open_rate'])}.")
    ranked = [r for r in dept_rows if r["delivered"] >= 5]
    if len(ranked) >= 2:
        top, low = max(ranked, key=lambda r: r["open"]), min(ranked, key=lambda r: r["open"])
        parts.append(f"{top['name']} read the most ({pct(top['open'])}) and {low['name']} the least ({pct(low['open'])}).")
    if cur.median_hours is not None:
        parts.append(f"Half of the opens arrived within {_hours(cur.median_hours)} of sending.")
    return "<p>" + " ".join(parts) + "</p>"


def build_storyboard(*, period: str = "30", department: str = "", focus: str = "", theme: dict | None = None,
                     use_ai: bool = True) -> dict:
    """Returns {"subject", "preheader", "content", "notice"}."""
    cfg = current_app.config
    label, days = PERIODS.get(period, PERIODS["30"])
    now = datetime.now(timezone.utc)
    cur_win = Window(now - timedelta(days=days) if days else None, now)
    prev_win = Window(cur_win.start - timedelta(days=days), cur_win.start) if days else None
    scope = department or "All employees"
    local_now = now.astimezone()
    as_of = local_now.strftime("%d %b %Y")
    span = f"{cur_win.start.astimezone().strftime('%d %b')} to {as_of}" if days else f"up to {as_of}"
    compare_label = f"the previous {days} days" if days else "no comparison (all time)"

    campaigns, rows = _load()
    cur = window_metrics(cur_win, department, campaigns, rows)
    prev = window_metrics(prev_win, department, campaigns, rows) if prev_win else None
    p = prev if prev and prev.sent else None

    people_q = Recipient.query.filter_by(active=True)
    if department:
        people_q = people_q.filter(Recipient.department == department)
    staff = people_q.all()
    headcount = len(staff)
    added = sum(1 for r in staff if _in(cur_win, r.created_at)) if days else headcount
    # With HR profiles (date of joining / exit), report real joiners and leavers instead of "added to the studio".
    everyone_q = Recipient.query.filter(Recipient.department == department) if department else Recipient.query
    everyone = everyone_q.all()
    hr_dates = any(r.date_of_joining for r in everyone)
    start_day = cur_win.start.astimezone().date() if days else None
    today = local_now.date()
    joined = sum(1 for r in everyone if r.date_of_joining and (start_day is None or r.date_of_joining >= start_day)
                 and r.date_of_joining <= today)
    left = sum(1 for r in everyone if r.date_of_exit and (start_day is None or r.date_of_exit >= start_day)
               and r.date_of_exit <= today)

    dept_rows = []
    counts = defaultdict(int)
    for r in staff:
        counts[r.department or "(no department)"] += 1
    for name, v in cur.departments.items():
        before = p.departments.get(name) if p else None
        o = _rate(v["opened"], v["delivered"])
        ob = _rate(before["opened"], before["delivered"]) if before else None
        dept_rows.append({"name": name, "people": counts.get(name, 0), "delivered": v["delivered"], "open": o,
                          "click": _rate(v["clicked"], v["delivered"]), "delta": _delta_pp(o, ob)})
    dept_rows.sort(key=lambda r: (-r["people"], r["name"]))

    # --- executive insights: AI summary of the numbers, or the standard summary --------------------------------
    notice = ""
    summary_html = rule_summary(label, scope, cur, prev, dept_rows)
    subject = f"Newsletter engagement: {pct(cur.open_rate)} opened" if cur.sent else "Newsletter engagement"
    preheader = (f"{cur.sent} newsletter{'s' if cur.sent != 1 else ''}, {cur.readers:,} readers, and what to try next."
                 if cur.sent else "This period's engagement in numbers.")
    ai_ready = bool(os.environ.get("ANTHROPIC_API_KEY") or os.environ.get("ANTHROPIC_AUTH_TOKEN"))
    if use_ai and ai_ready and cur.sent:
        from .ai import AIError, write_storyboard_insights

        try:
            ai_out = write_storyboard_insights(
                facts_for_ai(label, scope, cur, prev, headcount, added, dept_rows, compare_label,
                             (joined, left) if hr_dates else None), focus)
            summary_html = ai_out["html"] or summary_html
            subject = ai_out["subject"] or subject
            preheader = ai_out["preheader"] or preheader
        except AIError as exc:
            notice = f"The AI summary isn't available ({exc}), so the standard summary was used."
    elif use_ai and not ai_ready:
        notice = "AI is off, so the summary is the standard one. Every number is still from your data."

    # --- blocks -------------------------------------------------------------------------------------------------
    d = lambda block: {**block, "from_data": True}  # noqa: E731 — data blocks stay unchanged in AI revisions
    blocks = [
        {"type": "header", "eyebrow": scope, "title": "Engagement Newsletter",
         "subtitle": f"{label} · {span} · data as of {as_of}"},
        {"type": "insight", "label": "Executive insights", "html": summary_html},
    ]
    hero = [
        _card(pct(cur.open_rate), "Open rate", f"vs {compare_label}" if p else "emails opened ÷ delivered",
              _delta_pp(cur.open_rate, p.open_rate) if p else None),
        _card(f"{cur.readers:,}", "Employees reached", f"{pct(cur.reach)} of {cur.recipients:,} who received one",
              (cur.readers - p.readers) if p else None, unit="n"),
    ]
    blocks.append(d({"type": "stats", "items": hero, "columns": 2, "align": "left", "size": "large"}))
    key = [
        _card(f"{cur.sent}", "Newsletters sent", label.lower(), (cur.sent - p.sent) if p else None, unit="n", higher_is_better=None),
        _card(f"{cur.delivered:,}", "Emails delivered", "", (cur.delivered - p.delivered) if p else None, unit="n", higher_is_better=None),
        _card(pct(cur.click_rate), "Click rate", "clicked ÷ delivered", _delta_pp(cur.click_rate, p.click_rate) if p else None),
        _card(pct(cur.click_to_open), "Click-to-open", "clicked ÷ opened", _delta_pp(cur.click_to_open, p.click_to_open) if p else None),
        _card(f"{headcount:,}", "Active employees",
              (f"{joined:,} joined, {left:,} left {label.lower()}" if hr_dates and days else
               f"{added:,} added {label.lower()}" if days else ""), None),
        _card(f"{cur.recipients - cur.readers:,}", "Not reached", "received, opened none",
              ((cur.recipients - cur.readers) - (p.recipients - p.readers)) if p else None, unit="n", higher_is_better=False),
        _card(_hours(cur.median_hours), "Time to open", "median, send to first open",
              (cur.median_hours - p.median_hours) if p and cur.median_hours is not None and p.median_hours is not None else None,
              unit="h", higher_is_better=False),
        _card(f"{cur.failed:,}", "Failed deliveries", "bounced or rejected", (cur.failed - p.failed) if p else None,
              unit="n", higher_is_better=False),
    ]
    blocks.append(d({"type": "stats", "title": "Key metrics", "items": key, "columns": 4, "align": "left",
                     "subtitle": f"{label}. Change is against {compare_label}." if p else f"{label}."}))

    if cur.newsletters:
        blocks.append(d({"type": "bars", "title": "Open rate by newsletter",
                         "subtitle": "Share of delivered emails that were opened. Bars are scaled to the highest rate shown.",
                         "items": [{"label": f"{n['name']} ({n['date'].astimezone().strftime('%d %b')})",
                                    "value": round(n["open_rate"] * 100, 2), "display": pct(n["open_rate"])}
                                   for n in cur.newsletters]}))
        opened_only = cur.readers - cur.clickers
        blocks.append(d({"type": "share", "title": "Who opened",
                         "subtitle": f"The {cur.recipients:,} employees who received at least one newsletter.",
                         "items": [{"label": "Opened and clicked", "value": cur.clickers, "display": f"{cur.clickers:,} people"},
                                   {"label": "Opened, didn't click", "value": opened_only, "display": f"{opened_only:,} people"},
                                   {"label": "Didn't open", "value": cur.recipients - cur.readers,
                                    "display": f"{cur.recipients - cur.readers:,} people"}]}))
    if dept_rows:
        top_open = max((r["open"] or 0) for r in dept_rows) or 1
        blocks.append(d({"type": "table", "title": "Engagement by department",
                         "subtitle": "Departments by number of active employees. The bar shows each open rate against the highest.",
                         "columns": ["Department", "Employees", "Open rate", "Click rate"] + (["vs previous"] if p else []),
                         "rows": [[r["name"], f"{r['people']:,}", pct(r["open"]), pct(r["click"])]
                                  + ([(f"{r['delta']:+.1f}pp" if abs(r["delta"]) >= 0.05 else "0.0pp")
                                      if r["delta"] is not None else "new"] if p else [])
                                  for r in dept_rows[:12]],
                         "bars": [(r["open"] or 0) / top_open for r in dept_rows[:12]]}))
    if cur.links:
        blocks.append(d({"type": "table", "title": "Most-clicked links", "subtitle": "People who clicked each link.",
                         "columns": ["Link", "Newsletter", "People"],
                         "rows": [[a, b, f"{n:,}"] for a, b, n in cur.links]}))

    # Only tips about the newsletters themselves: never the one that names employees who don't open.
    tips = [r for r in recommendations(snapshot()) if r["confidence"] != "tip" and r["id"] != "unengaged"][:3]
    if tips:
        items = "".join(f"<li><strong>{r['title']}.</strong> {r['detail'].split('. ')[0].rstrip('.')}.</li>" for r in tips)
        blocks.append({"type": "heading", "text": "What to try next", "level": 2, "align": "left"})
        blocks.append({"type": "text", "html": f"<ul>{items}</ul>", "align": "left"})

    base = cfg["PUBLIC_BASE_URL"].rstrip("/")
    blocks.append({"type": "button", "label": "Open the full insights →", "href": f"{base}/insights/", "align": "center"})
    blocks.append({"type": "footer", "style": "dark", "html": (
        f"<p><strong>Data as of {as_of} · Source: Newsletter Studio</strong></p>"
        "<p>Open rate = emails opened ÷ emails delivered. Click rate = emails with a click ÷ emails delivered. "
        "Reach = employees who opened at least one newsletter ÷ employees who received one. "
        + (f"Changes compare with {compare_label}. " if p else "")
        + "Opens are counted when images load, so real readership is somewhat higher.</p>"
        f"<p>{cfg['COMPANY_NAME']} · Internal Communications · For internal distribution only.</p>")})

    content = sanitize_content({"theme": theme or {}, "blocks": blocks})
    return {"subject": subject[:255], "preheader": preheader[:255], "content": content, "notice": notice}

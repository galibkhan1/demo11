"""Headcount & Attrition storyboard: an HR data newsletter built from employee profiles.

It uses exactly the dashboard's numbers (services/workforce.py), scoped by the same filters, including a leader's
whole org. The AI only writes the executive summary from those numbers. Only aggregates go into the newsletter and
to the AI: no individual employee is named, apart from the leader whose org it covers.
"""

import os
from datetime import date

from flask import current_app

from ..models import Recipient
from .blocks import sanitize_content
from .workforce import (FILTER_KEYS, PERIODS, _fy_label, _measure, _minus_year, charts, select_people, window,
                        workforce_kpis)


def pct(x) -> str:
    return "–" if x is None else f"{x * 100:.1f}%"


def _stat(card) -> dict:
    """A dashboard KPI card as a storyboard stat item."""
    return {"value": card["display"], "label": card["label"], "note": card["note"], "delta": card["delta"],
            "trend": card["trend"], "good": card["good"]}


def facts_text(k: dict, ch: dict, scope_label: str) -> str:
    cards = {c["key"]: c for c in k["cards"]}
    lines = [f"Scope: {scope_label}. Period: {k['label']} ({k['range']}). Comparison: {k['compare_label']} ({k['compare_range']})."]
    for key in ("headcount", "joiners", "exits", "retention", "attrition", "voluntary", "involuntary", "regrettable",
                "early", "female", "tenure", "notice"):
        c = cards[key]
        change = f" (change vs comparison: {c['delta']})" if c["delta"] else ""
        lines.append(f"- {c['label']}: {c['display']}{change}. {c['note']}. Definition: {c['definition']}")
    if ch["by_department"]:
        lines.append("By department (headcount, exits, annualised attrition, voluntary, regrettable, share of women): " + "; ".join(
            f"{r['name']} {r['headcount']}, {r['exits']} exits, {pct(r['attrition'])}, {pct(r['voluntary'])}, "
            f"{pct(r['regrettable'])}, {pct(r['female'])} women" for r in ch["by_department"][:15]))
    if len(ch["by_bu"]) > 1:
        lines.append("By business unit (headcount, annualised attrition): " + "; ".join(
            f"{r['name']} {r['headcount']}, {pct(r['attrition'])}" for r in ch["by_bu"]))
    if ch["exit_reasons"]:
        lines.append("Exit reasons in the period: " + "; ".join(f"{x['label']} {x['value']}" for x in ch["exit_reasons"]))
    if ch["gender"]:
        lines.append("Headcount by gender: " + "; ".join(f"{x['label']} {x['value']}" for x in ch["gender"]))
    return "\n".join(lines)


def rule_summary(k: dict, ch: dict, scope_label: str) -> str:
    c = {x["key"]: x for x in k["cards"]}
    parts = [f"<strong>{scope_label}</strong> closed the period with <strong>{c['headcount']['display']}</strong> people "
             f"({c['joiners']['display']} joined, {c['exits']['display']} left). "
             f"Annualised attrition is <strong>{c['attrition']['display']}</strong>"]
    if c["attrition"]["delta"]:
        parts[-1] += f" ({c['attrition']['delta']} on {k['compare_label']})"
    parts[-1] += f", of which {c['voluntary']['display']} voluntary and {c['involuntary']['display']} involuntary."
    ranked = [r for r in ch["by_department"] if r["headcount"] >= 5 and r["attrition"] is not None]
    if len(ranked) >= 2:
        hi = max(ranked, key=lambda r: r["attrition"])
        lo = min(ranked, key=lambda r: r["attrition"])
        parts.append(f"{hi['name']} has the highest attrition ({pct(hi['attrition'])}) and {lo['name']} the lowest ({pct(lo['attrition'])}).")
    parts.append(f"Regrettable attrition is {c['regrettable']['display']}; {c['notice']['display']} people are serving notice.")
    return "<p>" + " ".join(parts) + "</p>"


def build_hr_storyboard(*, period: str = "fytd", filters: dict | None = None, focus: str = "", theme: dict | None = None,
                        use_ai: bool = True) -> dict:
    cfg = current_app.config
    filters = {key: str((filters or {}).get(key) or "") for key in FILTER_KEYS}
    k = workforce_kpis(period, filters)
    if k.get("empty"):
        raise ValueError("There are no employee profiles yet. Import them on the Employees page first.")
    ch = k["charts"]
    scope_label = k["scope"]
    cards = {c["key"]: c for c in k["cards"]}
    today = date.today()

    notice = ""
    summary = rule_summary(k, ch, scope_label)
    subject = f"Headcount & attrition: {cards['attrition']['display']} attrition, {cards['headcount']['display']} people"
    preheader = f"{scope_label} · {k['label']}: joiners, exits and attrition by team."
    ai_ready = bool(os.environ.get("ANTHROPIC_API_KEY") or os.environ.get("ANTHROPIC_AUTH_TOKEN"))
    if use_ai and ai_ready:
        from .ai import AIError, write_storyboard_insights

        try:
            out = write_storyboard_insights(facts_text(k, ch, scope_label), focus, kind="hr")
            summary = out["html"] or summary
            subject = out["subject"] or subject
            preheader = out["preheader"] or preheader
        except AIError as exc:
            notice = f"The AI summary isn't available ({exc}), so the standard summary was used."
    elif use_ai:
        notice = "AI is off, so the summary is the standard one. Every number is still from your data."

    d = lambda b: {**b, "from_data": True}  # noqa: E731 — data blocks stay unchanged in AI revisions
    blocks = [
        {"type": "header", "eyebrow": scope_label, "title": "Headcount & Attrition Newsletter",
         "subtitle": f"{k['label']} · data as of {today:%d %b %Y}"},
        {"type": "insight", "label": "Executive insights", "html": summary},
        d({"type": "stats", "columns": 2, "align": "left", "size": "large",
           "items": [_stat(cards["attrition"]), _stat(cards["headcount"])]}),
        d({"type": "stats", "title": "Key metrics", "columns": 4, "align": "left",
           "subtitle": f"Annualised where marked. Change is against {k['compare_label']}.",
           "items": [_stat(cards[x]) for x in ("joiners", "exits", "voluntary", "involuntary", "regrettable", "early",
                                               "female", "notice")]}),
        d({"type": "bars", "title": "Attrition by type", "subtitle": "Annualised rates for the period. Bars are scaled to the highest rate shown.",
           "items": [{"label": cards[x]["label"].replace(" attrition", "").replace("Attrition rate", "Overall"),
                      "value": float(cards[x]["display"].rstrip("%")) if cards[x]["display"] != "–" else 0,
                      "display": cards[x]["display"]} for x in ("attrition", "voluntary", "involuntary", "regrettable")]}),
    ]
    if ch["gender"]:
        blocks.append(d({"type": "share", "title": "Gender diversity", "subtitle": f"Share of headcount at {today:%d %b %Y}.",
                         "items": [{"label": x["label"], "value": x["value"], "display": f"{x['value']:,} people"} for x in ch["gender"]]}))
    depts = [r for r in ch["by_department"] if r["headcount"] or r["exits"]]
    if depts:
        top = max((r["attrition"] or 0) for r in depts) or 1
        blocks.append(d({"type": "table", "title": "Attrition by department",
                         "subtitle": "Headcount at the end of the period; exits and annualised attrition within it. The bar compares attrition.",
                         "columns": ["Department", "Headcount", "Exits", "Attrition", "Voluntary", "Regrettable"],
                         "rows": [[r["name"], f"{r['headcount']:,}", f"{r['exits']:,}", pct(r["attrition"]), pct(r["voluntary"]),
                                   pct(r["regrettable"])] for r in depts[:15]],
                         "bars": [(r["attrition"] or 0) / top for r in depts[:15]]}))
    if len(ch["by_bu"]) > 1:
        top = max(r["headcount"] for r in ch["by_bu"]) or 1
        blocks.append(d({"type": "table", "title": "Headcount by business unit", "subtitle": "The bar compares headcount.",
                         "columns": ["Business unit", "Headcount", "Joiners", "Exits", "Attrition"],
                         "rows": [[r["name"], f"{r['headcount']:,}", f"{r['joiners']:,}", f"{r['exits']:,}", pct(r["attrition"])]
                                  for r in ch["by_bu"]],
                         "bars": [r["headcount"] / top for r in ch["by_bu"]]}))
    if ch["exit_reasons"]:
        blocks.append(d({"type": "bars", "title": "Why people left", "subtitle": f"Exit reasons in the period ({ch['exits_total']} exits).",
                         "items": [{"label": x["label"], "value": x["value"], "display": str(x["value"])} for x in ch["exit_reasons"]]}))
    base = cfg["PUBLIC_BASE_URL"].rstrip("/")
    blocks.append({"type": "button", "label": "Open the workforce dashboard →", "href": f"{base}/", "align": "center"})
    blocks.append({"type": "footer", "style": "dark", "html": (
        f"<p><strong>Data as of {today:%d %b %Y} · Source: employee profiles in Newsletter Studio</strong></p>"
        "<p>Headcount = people employed at the end of the period. Attrition = exits ÷ average headcount, annualised "
        "(× 365 ÷ days in the period). Voluntary, involuntary and regrettable attrition count only those exits. "
        f"Changes compare with {k['compare_label']}. Teams use each person's current department.</p>"
        f"<p>{cfg['COMPANY_NAME']} · People insights · Confidential, for internal distribution only.</p>")})
    content = sanitize_content({"theme": theme or {}, "blocks": blocks})
    return {"subject": subject[:255], "preheader": preheader[:255], "content": content, "notice": notice,
            "scope": scope_label}

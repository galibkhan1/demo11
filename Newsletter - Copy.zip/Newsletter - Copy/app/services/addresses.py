"""Parsing and validation for To / Cc / Bcc address lists."""

import re

from flask import current_app

EMAIL_RE = re.compile(r"^[^@\s,;<>\"]+@[^@\s,;<>\"]+\.[^@\s,;<>\"]+$")
MAX_COPY_ADDRESSES = 50


def parse_address_list(raw, limit: int = MAX_COPY_ADDRESSES) -> tuple[list[str], list[str]]:
    """Accept a list or a comma/semicolon/space separated string. Returns (valid lowercase unique, invalid)."""
    if isinstance(raw, str):
        items = re.split(r"[,;\s]+", raw)
    elif isinstance(raw, (list, tuple)):
        items = [str(x) for x in raw]
    else:
        items = []
    valid, invalid, seen = [], [], set()
    for item in items:
        addr = item.strip().strip("<>").strip().lower()
        if not addr:
            continue
        if not EMAIL_RE.match(addr) or len(addr) > 254:
            invalid.append(item.strip())
        elif addr not in seen:
            seen.add(addr)
            valid.append(addr)
    return valid[:limit], invalid


# Domains reserved for documentation and testing (RFC 2606 / 6761): mail to them can never be delivered.
# The demo data uses example.com, so these must never reach a real mail server.
_TEST_DOMAINS = ("example.com", "example.org", "example.net")
_TEST_TLDS = {"example", "test", "invalid", "localhost", "local"}


def is_demo_address(addr) -> bool:
    domain = str(addr or "").rsplit("@", 1)[-1].strip().lower().rstrip(".")
    if not domain or "@" not in str(addr or ""):
        return False
    return any(domain == d or domain.endswith("." + d) for d in _TEST_DOMAINS) or domain.rsplit(".", 1)[-1] in _TEST_TLDS


def sending_real_email() -> bool:
    """True when emails go to a real mail server (MAIL_BACKEND=smtp), not the outbox folder."""
    return current_app.config["MAIL_BACKEND"] == "smtp"


def clean_copies(cc_raw, bcc_raw) -> tuple[list[str], list[str], list[str]]:
    """Return (cc, bcc, invalid). An address in both lists is kept in Cc only."""
    cc, bad_cc = parse_address_list(cc_raw)
    bcc, bad_bcc = parse_address_list(bcc_raw)
    bcc = [a for a in bcc if a not in cc]
    return cc, bcc, bad_cc + bad_bcc

"""Data-driven recommendations, draft checks and the studio's own numbers.

Everything here is computed from the database: sent newsletters, deliveries, open/click events and
employees. Nothing in this module calls the AI. ``ideas_context`` and ``studio_data_text`` produce the
data that ``services.ai`` sends to Claude when someone asks for topic ideas or ticks "Include studio data".

Times are reported in the server's local time zone. The studio runs on the same machine people use it
from, so that is the time zone they see.
"""

import re
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from statistics import mean, median

from flask import g
from sqlalchemy import func

from .. import db
from ..models import Campaign, CampaignStatus, Delivery, DeliveryStatus, Event, Recipient
from .audience import audience_label, normalize_audience
from .blocks import _html_to_text
from .metrics import campaign_metrics, department_engagement

WEEKDAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
_MERGE = re.compile(r"\{\{\s*(first_name|name|email)\s*\}\}")
_PLACEHOLDER = re.compile(r"\[[^\[\]\n]{1,40}\]")
_DIGIT = re.compile(r"\d")
# A figure worth highlighting: 12%, ₹4.2 Cr, $3M, 4.7/5, 18 new hires, 99.98% ...
_FIGURE = re.compile(r"(?:[₹$€£]\s?\d[\d,.]*\s?(?:k|K|M|Cr|L|lakh|crore|bn)?|\d[\d,.]*\s?(?:%|x\b|/\s?\d+)|\b\d{2,}[\d,]*\b)")

SHORT_SUBJECT = 45  # characters, with merge tags filled in
SHORT_EMAIL = 180  # words


def _aware(dt):
    if dt is None:
        return None
    return dt.replace(tzinfo=timezone.utc) if dt.tzinfo is None else dt


def _local(dt):
    return _aware(dt).astimezone()  # server's local time zone


def pct(x) -> str:
    return "–" if x is None else f"{x * 100:.0f}%"


def points(a, b) -> str:
    n = round(abs(a - b) * 100)
    return f"{n} point{'' if n == 1 else 's'}"


def fmt_hours(h: float) -> str:
    if h < 1:
        return f"{max(1, round(h * 60))} minutes"
    if h < 10:
        return f"{h:.1f} hours".replace(".0 ", " ")
    return f"{round(h)} hours"


def hour_label(h: int) -> str:
    return f"{h % 24:02d}:00"


def subject_length(subject: str) -> int:
    return len(_MERGE.sub("Priya", subject or ""))


def _block_texts(block) -> list[str]:
    t = block["type"]
    if t in ("text", "footer"):
        return [_html_to_text(block.get("html", ""))]
    if t == "columns":
        return [_html_to_text(block.get("left_html", "")), _html_to_text(block.get("right_html", ""))]
    if t == "header":
        return [block.get("title", ""), block.get("subtitle", "")]
    if t == "heading":
        return [block.get("text", "")]
    if t == "button":
        return [block.get("label", "")]
    if t == "image":
        return [block.get("alt", "")]
    if t == "stats":
        return [block.get("title", "")] + [f"{i.get('value', '')} {i.get('label', '')} {i.get('note', '')}" for i in block.get("items", [])]
    if t == "insight":
        return [block.get("label", ""), _html_to_text(block.get("html", ""))]
    if t in ("bars", "share", "table"):
        return [block.get("title", ""), block.get("subtitle", "")]
    return []


def content_stats(content: dict) -> dict:
    """Measurable features of a newsletter's content."""
    blocks = (content or {}).get("blocks", [])
    body_text = " ".join(
        s for b in blocks if b["type"] not in ("footer",) for s in _block_texts(b)
    )
    links = 0
    for b in blocks:
        for key in ("html", "left_html", "right_html"):
            links += len(re.findall(r'href="(?:https?:|mailto:)', b.get(key, "") or ""))
        if b["type"] == "button" and b.get("href"):
            links += 1
        if b["type"] == "image" and b.get("href"):
            links += 1
    buttons = [i for i, b in enumerate(blocks) if b["type"] == "button"]
    return {
        "blocks": len(blocks),
        "words": len(re.findall(r"\w+", body_text)),
        "links": links,
        "buttons": len(buttons),
        "first_button_pos": (buttons[0] / max(1, len(blocks) - 1)) if buttons else None,
        "has_stats": any(b["type"] == "stats" for b in blocks),
        "figures": [f for f in _FIGURE.findall(body_text) if not re.fullmatch(r"(?:19|20)\d\d", f.strip())],
    }


@dataclass
class SentNewsletter:
    id: int
    name: str
    subject: str
    started: datetime  # local time
    audience: str
    sent: int
    open_rate: float
    click_rate: float
    click_to_open: float
    personalized: bool
    subject_len: int
    subject_has_number: bool
    words: int
    buttons: int
    button_top: bool | None


@dataclass
class Snapshot:
    newsletters: list[SentNewsletter] = field(default_factory=list)
    delivered: int = 0
    opened: int = 0
    clicked: int = 0
    open_hours: Counter = field(default_factory=Counter)  # local hour -> open events
    open_events: int = 0
    first_open_delays: list[float] = field(default_factory=list)  # hours from send to first open
    departments: list[dict] = field(default_factory=list)
    headcount: list[tuple[str, int]] = field(default_factory=list)
    active_employees: int = 0
    unengaged: list[dict] = field(default_factory=list)
    top_links: dict = field(default_factory=dict)  # campaign id -> [(label, clicks)]

    @property
    def open_rate(self):
        return self.opened / self.delivered if self.delivered else None

    @property
    def click_rate(self):
        return self.clicked / self.delivered if self.delivered else None


def _link_labels(content) -> dict:
    labels = {}
    for b in (content or {}).get("blocks", []):
        if b["type"] == "button" and b.get("href"):
            labels.setdefault(b["href"], b.get("label") or b["href"])
        for key in ("html", "left_html", "right_html"):
            for href, text in re.findall(r'<a [^>]*href="([^"]+)"[^>]*>(.*?)</a>', b.get(key, "") or "", re.S):
                labels.setdefault(href, re.sub(r"<[^>]+>", "", text).strip() or href)
    return labels


def snapshot() -> Snapshot:
    """All engagement data the recommendations need, loaded once per request."""
    if "insights_snapshot" in g:
        return g.insights_snapshot
    snap = Snapshot()
    snap.active_employees = Recipient.query.filter_by(active=True).count()
    snap.headcount = (
        db.session.query(Recipient.department, func.count(Recipient.id))
        .filter(Recipient.active.is_(True), Recipient.department != "")
        .group_by(Recipient.department)
        .order_by(func.count(Recipient.id).desc(), Recipient.department)
        .all()
    )

    campaigns = (
        Campaign.query.filter(Campaign.status == CampaignStatus.SENT, Campaign.started_at.isnot(None))
        .order_by(Campaign.started_at)
        .all()
    )
    metrics = campaign_metrics([c.id for c in campaigns])
    for c in campaigns:
        m = metrics.get(c.id)
        if not m or not m["sent"]:
            continue
        cs = content_stats(c.content)
        snap.newsletters.append(SentNewsletter(
            id=c.id, name=c.name, subject=c.subject, started=_local(c.started_at),
            audience=audience_label(c.audience), sent=m["sent"],
            open_rate=m["open_rate"], click_rate=m["click_rate"],
            click_to_open=m["clicked"] / m["opened"] if m["opened"] else 0.0,
            personalized=bool(_MERGE.search(c.subject or "")),
            subject_len=subject_length(c.subject), subject_has_number=bool(_DIGIT.search(_MERGE.sub("", c.subject or ""))),
            words=cs["words"], buttons=cs["buttons"],
            button_top=None if cs["first_button_pos"] is None else cs["first_button_pos"] < 0.5,
        ))
        snap.delivered += m["sent"]
        snap.opened += m["opened"]
        snap.clicked += m["clicked"]

    ids = [n.id for n in snap.newsletters]
    if ids:
        for (created,) in db.session.query(Event.created_at).filter(Event.type == "open", Event.campaign_id.in_(ids)):
            snap.open_hours[_local(created).hour] += 1
            snap.open_events += 1
        rows = (
            db.session.query(Delivery.opened_at, Campaign.started_at)
            .join(Campaign, Campaign.id == Delivery.campaign_id)
            .filter(Delivery.campaign_id.in_(ids), Delivery.opened_at.isnot(None))
            .all()
        )
        snap.first_open_delays = sorted(
            max(0.0, (_aware(o) - _aware(s)).total_seconds() / 3600) for o, s in rows
        )
        snap.departments = [d for d in department_engagement(ids) if d["name"] != "(none)"]

        # Employees who received at least 3 of the last 5 newsletters and opened none of them.
        recent = ids[-5:]
        if len(recent) >= 3:
            rows = (
                db.session.query(Recipient.id, Recipient.name, Recipient.email, Recipient.department,
                                 func.count(Delivery.id), func.count(Delivery.opened_at))
                .join(Delivery, Delivery.recipient_id == Recipient.id)
                .filter(Delivery.campaign_id.in_(recent), Delivery.status == DeliveryStatus.SENT,
                        Recipient.active.is_(True))
                .group_by(Recipient.id, Recipient.name, Recipient.email, Recipient.department)
                .all()
            )
            snap.unengaged = [
                {"id": rid, "name": name or email, "email": email, "department": dept, "received": got}
                for rid, name, email, dept, got, opened in rows
                if got >= 3 and opened == 0
            ]
            snap.unengaged.sort(key=lambda p: (-p["received"], p["name"]))

        by_campaign = defaultdict(list)
        link_rows = (
            db.session.query(Event.campaign_id, Event.url, func.count(func.distinct(Event.delivery_id)))
            .filter(Event.campaign_id.in_(ids), Event.type == "click")
            .group_by(Event.campaign_id, Event.url)
            .all()
        )
        labels = {c.id: _link_labels(c.content) for c in campaigns}
        for cid, url, people in link_rows:
            by_campaign[cid].append((labels.get(cid, {}).get(url, url), people))
        snap.top_links = {cid: sorted(v, key=lambda x: -x[1])[:3] for cid, v in by_campaign.items()}

    g.insights_snapshot = snap
    return snap


# ---------------------------------------------------------------------------------------------
# Comparisons
# ---------------------------------------------------------------------------------------------

@dataclass
class Split:
    a: float  # mean metric where the feature is present
    a_n: int
    b: float  # mean metric where it is absent
    b_n: int

    @property
    def diff(self) -> float:
        return self.a - self.b

    @property
    def confidence(self) -> str:
        return "strong" if min(self.a_n, self.b_n) >= 3 else "early"


def _split(items, pred, metric) -> Split | None:
    a = [getattr(n, metric) for n in items if pred(n) is True]
    b = [getattr(n, metric) for n in items if pred(n) is False]
    if not a or not b:
        return None
    return Split(mean(a), len(a), mean(b), len(b))


def _n(count: int, word: str = "newsletter") -> str:
    return f"{count} {word}{'' if count == 1 else 's'}"


@dataclass
class Benchmarks:
    personalized: Split | None
    subject_number: Split | None
    short_subject: Split | None
    short_email: Split | None
    button_top: Split | None
    one_button: Split | None


def benchmarks(snap: Snapshot) -> Benchmarks:
    items = snap.newsletters if len(snap.newsletters) >= 3 else []
    return Benchmarks(
        personalized=_split(items, lambda n: n.personalized, "open_rate"),
        subject_number=_split(items, lambda n: n.subject_has_number, "open_rate"),
        short_subject=_split(items, lambda n: n.subject_len <= SHORT_SUBJECT, "open_rate"),
        short_email=_split(items, lambda n: n.words <= SHORT_EMAIL, "click_to_open"),
        button_top=_split(items, lambda n: n.button_top, "click_to_open"),
        one_button=_split(items, lambda n: (n.buttons == 1) if n.buttons else None, "click_to_open"),
    )


# ---------------------------------------------------------------------------------------------
# Best time to send
# ---------------------------------------------------------------------------------------------

def _hour_bucket(h: int) -> str:
    if h < 9:
        return "early morning (before 09:00)"
    if h < 12:
        return "morning (09:00 to 12:00)"
    if h < 16:
        return "afternoon (12:00 to 16:00)"
    return "late (after 16:00)"


def _next_slot(weekday: int | None, hour: int) -> datetime:
    now = datetime.now().astimezone()
    for d in range(0, 8):
        cand = (now + timedelta(days=d)).replace(hour=hour, minute=0, second=0, microsecond=0)
        if cand > now + timedelta(minutes=15) and (weekday is None or cand.weekday() == weekday):
            return cand
    return now + timedelta(days=1)


def best_time(snap: Snapshot) -> dict | None:
    """When to send next, from send-day results and when people actually read."""
    if not snap.newsletters or not snap.open_events:
        return None
    news = snap.newsletters

    # Reading peak: the 2-hour window with the most open events.
    start = max(range(24), key=lambda h: (snap.open_hours[h] + snap.open_hours[(h + 1) % 24], -h))
    share = (snap.open_hours[start] + snap.open_hours[(start + 1) % 24]) / snap.open_events

    by_day = defaultdict(list)
    for n in news:
        by_day[n.started.weekday()].append(n.open_rate)
    day_rates = sorted(((mean(v), len(v), d) for d, v in by_day.items()), key=lambda x: (-x[0], -x[1]))
    weekday = day_rates[0][2] if len(day_rates) >= 2 else None

    by_bucket = defaultdict(list)
    for n in news:
        by_bucket[_hour_bucket(n.started.hour)].append(n)
    if len(by_bucket) >= 2:
        best_bucket = max(by_bucket.values(), key=lambda v: (mean(x.open_rate for x in v), len(v)))
        hour = Counter(n.started.hour for n in best_bucket).most_common(1)[0][0]
        varied_hours = True
    else:
        hour = Counter(n.started.hour for n in news).most_common(1)[0][0]
        varied_hours = False

    slot = _next_slot(weekday, hour)
    label = (f"{WEEKDAYS[weekday]} {hour_label(hour)}" if weekday is not None else hour_label(hour))
    delays = snap.first_open_delays
    return {
        "weekday": weekday,
        "hour": hour,
        "label": label,
        "at": slot.astimezone(timezone.utc).isoformat(),
        "slot_label": slot.strftime("%a %d %b, %H:%M"),
        "reading_window": f"{hour_label(start)} to {hour_label(start + 2)}",
        "reading_share": share,
        "day_rates": [{"day": WEEKDAYS[d], "rate": r, "count": c} for r, c, d in day_rates],
        "bucket_rates": [
            {"bucket": b, "rate": mean(x.open_rate for x in v), "count": len(v)} for b, v in by_bucket.items()
        ],
        "varied_hours": varied_hours,
        "half_open_within": median(delays) if delays else None,
        "p80_open_within": delays[int(len(delays) * 0.8)] if len(delays) >= 5 else None,
        "reason": f"Most reading happens {hour_label(start)} to {hour_label(start + 2)} ({pct(share)} of opens).",
    }


def opens_by_hour(snap: Snapshot) -> list[dict]:
    total = snap.open_events or 1
    return [{"hour": h, "opens": snap.open_hours[h], "share": snap.open_hours[h] / total} for h in range(24)]


# ---------------------------------------------------------------------------------------------
# Recommendations
# ---------------------------------------------------------------------------------------------

def _rec(rid, category, icon, title, detail, evidence, confidence, impact=0.0, action=None) -> dict:
    return {
        "id": rid, "category": category, "icon": icon, "title": title, "detail": detail,
        "evidence": evidence, "confidence": confidence, "impact": impact, "action": action,
    }


GENERAL_TIPS = [
    _rec("tip-subject", "Subject lines", "mail", "Keep subjects short and specific",
         "Around 30 to 50 characters fits on a phone screen. Lead with the most useful fact or number.",
         [], "tip"),
    _rec("tip-button", "Content", "click", "One clear button, near the top",
         "Newsletters with a single main call to action usually get more clicks than ones with several.",
         [], "tip"),
    _rec("tip-figures", "Content", "hash", "Show the key numbers in a Stats block",
         "Big figures (\"12% above target\", \"18 new joiners\") are the first thing people scan. "
         "Add them from the Blocks tab, or tick \"Include studio data\" in the AI writer.",
         [], "tip"),
    _rec("tip-time", "Timing", "clock", "Send mid-morning on a weekday",
         "Most office email is read between 09:00 and 12:00. Avoid Friday afternoons and Mondays before 10:00.",
         [], "tip"),
]


def recommendations(snap: Snapshot | None = None) -> list[dict]:
    snap = snap or snapshot()
    news = snap.newsletters
    recs = []

    # Timing -------------------------------------------------------------------------------
    bt = best_time(snap)
    if bt:
        parts = []
        if bt["weekday"] is not None:
            best, *rest = bt["day_rates"]
            other = rest[-1]
            parts.append(f"Newsletters sent on a {best['day']} were opened by {pct(best['rate'])} on average, "
                         f"against {pct(other['rate'])} on a {other['day']}.")
        parts.append(bt["reason"])
        if not bt["varied_hours"]:
            parts.append(f"Every newsletter so far went out around {hour_label(bt['hour'])}, so try a different "
                         "hour once to compare.")
        evidence = [f"{d['day'][:3]}: {pct(d['rate'])} opened ({_n(d['count'])})" for d in bt["day_rates"]]
        if bt["varied_hours"]:
            evidence += [f"{b['bucket'].capitalize()}: {pct(b['rate'])} ({_n(b['count'])})" for b in bt["bucket_rates"]]
        title = (f"Send on {bt['label'].replace(' ', 's around ', 1)}" if bt["weekday"] is not None
                 else f"Keep sending around {bt['label']}")
        recs.append(_rec("best-time", "Timing", "clock", title, " ".join(parts), evidence,
                         "strong" if len(news) >= 6 else "early", 0.5,
                         {"type": "time", "label": f"Next slot: {bt['slot_label']}", "at": bt["at"]}))

        if bt["half_open_within"] is not None and bt["p80_open_within"] is not None and len(snap.first_open_delays) >= 30:
            half, p80 = bt["half_open_within"], bt["p80_open_within"]
            lead = max(1, round(p80 / 24 + 0.49)) if p80 > 12 else None
            detail = (f"Half of the people who open a newsletter do so within {fmt_hours(half)}, and 80% within "
                      f"{fmt_hours(p80)}. ")
            detail += (f"Send deadlines, RSVPs and event reminders at least {_n(lead, 'day')} ahead."
                       if lead else "Same-day reminders work, as long as they go out in the morning.")
            recs.append(_rec("lead-time", "Timing", "trending-up", "Give time-sensitive news a head start", detail,
                             [f"50% of opens within {fmt_hours(half)}", f"80% within {fmt_hours(p80)}",
                              f"{snap.open_events} opens measured"], "strong", 0.3))

    # Subject lines ------------------------------------------------------------------------
    bm = benchmarks(snap)
    if bm.personalized and abs(bm.personalized.diff) >= 0.03:
        s = bm.personalized
        if s.diff > 0:
            recs.append(_rec("subject-name", "Subject lines", "users", "Greet people by name in the subject",
                             f"Subjects with {{{{first_name}}}} were opened by {pct(s.a)}, against {pct(s.b)} without "
                             f"({points(s.a, s.b)} higher).",
                             [f"With a name: {pct(s.a)} ({_n(s.a_n)})", f"Without: {pct(s.b)} ({_n(s.b_n)})"],
                             s.confidence, s.diff))
        else:
            recs.append(_rec("subject-name", "Subject lines", "users", "A name in the subject isn't helping yet",
                             f"Subjects without {{{{first_name}}}} did {points(s.a, s.b)} better ({pct(s.b)} against "
                             f"{pct(s.a)}). Lead with the news itself instead.",
                             [f"With a name: {pct(s.a)} ({_n(s.a_n)})", f"Without: {pct(s.b)} ({_n(s.b_n)})"],
                             s.confidence, -s.diff))
    if bm.subject_number and bm.subject_number.diff >= 0.03:
        s = bm.subject_number
        recs.append(_rec("subject-number", "Subject lines", "hash", "Put a number in the subject",
                         f"Subjects with a figure (\"5 things\", \"12%\") were opened by {pct(s.a)}, against {pct(s.b)} "
                         "without one.",
                         [f"With a number: {pct(s.a)} ({_n(s.a_n)})", f"Without: {pct(s.b)} ({_n(s.b_n)})"],
                         s.confidence, s.diff))
    if bm.short_subject and abs(bm.short_subject.diff) >= 0.03:
        s = bm.short_subject
        short_wins = s.diff > 0
        recs.append(_rec("subject-length", "Subject lines", "mail",
                         f"Keep subjects under {SHORT_SUBJECT} characters" if short_wins
                         else f"Descriptive subjects (over {SHORT_SUBJECT} characters) work better here",
                         f"Subjects of {SHORT_SUBJECT} characters or fewer were opened by {pct(s.a)}; longer ones by "
                         f"{pct(s.b)}.",
                         [f"Short: {pct(s.a)} ({_n(s.a_n)})", f"Long: {pct(s.b)} ({_n(s.b_n)})"],
                         s.confidence, abs(s.diff)))

    # Audience -----------------------------------------------------------------------------
    overall = snap.open_rate
    if overall is not None and snap.departments:
        low = [d for d in snap.departments if d["sent"] >= 10 and d["open_rate"] <= overall - 0.08]
        low.sort(key=lambda d: d["open_rate"])
        low = low[:2]
        if low:
            names = " and ".join(d["name"] for d in low)
            top = snap.departments[0]
            detail = (f"{names} open{'s' if len(low) == 1 else ''} newsletters less often than everyone else "
                      f"({', '.join(pct(d['open_rate']) for d in low)} against {pct(overall)} overall; "
                      f"{top['name']} leads with {pct(top['open_rate'])}). Lead with something that matters to them, "
                      "or send them a short targeted update.")
            d0 = low[0]["name"]
            recs.append(_rec("low-departments", "Audience", "users", f"Win back {names}", detail,
                             [f"{d['name']}: {pct(d['open_rate'])} ({d['sent']} emails)" for d in low]
                             + [f"{top['name']}: {pct(top['open_rate'])}", f"Overall: {pct(overall)}"],
                             "strong" if min(d["sent"] for d in low) >= 25 else "early",
                             overall - low[0]["open_rate"],
                             {"type": "draft", "label": f"Draft an update for {d0}", "name": f"{d0} update",
                              "departments": [d0],
                              "prompt": f"Short, targeted update for the {d0} team: [the 2 or 3 things that matter "
                                        f"most to {d0} this month]. Lead with the most relevant item, keep it under "
                                        "200 words, friendly and direct."}))
    if snap.unengaged:
        people = snap.unengaged
        names = ", ".join(p["name"] for p in people[:3]) + (f" and {len(people) - 3} more" if len(people) > 3 else "")
        recs.append(_rec("unengaged", "Audience", "mail-open",
                         f"{_n(len(people), 'employee')} haven't opened a recent newsletter"
                         if len(people) != 1 else "1 employee hasn't opened a recent newsletter",
                         f"{names} received at least 3 of the last 5 newsletters and opened none. Check that their "
                         "addresses are right, or send them a short personal check-in. (Some email apps block the "
                         "images that count opens, so a few of them may be reading without being counted.)",
                         [f"{p['name']} · {p['department'] or 'no department'}" for p in people[:6]],
                         "strong", 0.2,
                         {"type": "draft", "label": "Draft a check-in for them", "name": "Quick check-in",
                          "employee_ids": [p["id"] for p in people],
                          "prompt": "A short, warm personal check-in for colleagues who may have missed our recent "
                                    "newsletters: recap the [2 or 3 most important recent updates] in one line each, "
                                    "and ask them to reply if they'd prefer news in another format. Under 150 words."}))

    # Content ------------------------------------------------------------------------------
    if bm.button_top and abs(bm.button_top.diff) >= 0.02:
        s = bm.button_top
        top_wins = s.diff > 0
        recs.append(_rec("button-position", "Content", "click",
                         "Put the main button in the top half" if top_wins else "Buttons work best after the story",
                         f"Of the people who opened, {pct(s.a)} clicked when the first button was in the top half of "
                         f"the email, and {pct(s.b)} when it was lower down.",
                         [f"Top half: {pct(s.a)} clicked ({_n(s.a_n)})", f"Lower: {pct(s.b)} ({_n(s.b_n)})"],
                         s.confidence, abs(s.diff)))
    if bm.short_email and abs(bm.short_email.diff) >= 0.03:
        s = bm.short_email
        short_wins = s.diff > 0
        recs.append(_rec("email-length", "Content", "text",
                         f"Keep newsletters under {SHORT_EMAIL} words" if short_wins else "Longer newsletters get more clicks here",
                         f"Of the people who opened, {pct(s.a)} clicked on newsletters of {SHORT_EMAIL} words or fewer, "
                         f"and {pct(s.b)} on longer ones.",
                         [f"Short: {pct(s.a)} clicked ({_n(s.a_n)})", f"Long: {pct(s.b)} ({_n(s.b_n)})"],
                         s.confidence, abs(s.diff)))
    if bm.one_button and bm.one_button.diff >= 0.03:
        s = bm.one_button
        recs.append(_rec("one-button", "Content", "button", "Use one main button",
                         f"Newsletters with a single button had {pct(s.a)} of openers clicking, against {pct(s.b)} for "
                         "ones with several.",
                         [f"One button: {pct(s.a)} ({_n(s.a_n)})", f"Several: {pct(s.b)} ({_n(s.b_n)})"],
                         s.confidence, s.diff))

    # Trend --------------------------------------------------------------------------------
    if len(news) >= 5:
        last = news[-3:]
        before = news[:-3][-3:]
        a, b = mean(n.open_rate for n in last), mean(n.open_rate for n in before)
        if a - b <= -0.05:
            recs.append(_rec("trend", "Health", "trending-up", "Open rates are slipping",
                             f"The last 3 newsletters averaged {pct(a)} opens, down from {pct(b)}. Shorter newsletters, "
                             "clearer subjects or a less frequent schedule usually help.",
                             [f"{n.name}: {pct(n.open_rate)}" for n in last], "early", b - a))
        elif a - b >= 0.05:
            recs.append(_rec("trend", "Health", "trending-up", "Open rates are climbing",
                             f"The last 3 newsletters averaged {pct(a)} opens, up from {pct(b)}. Keep the same "
                             "length and tone.",
                             [f"{n.name}: {pct(n.open_rate)}" for n in last], "early", a - b))
    if news:
        days = (datetime.now().astimezone() - news[-1].started).days
        if days >= 21:
            recs.append(_rec("gap", "Health", "calendar", f"It's been {days} days since the last newsletter",
                             "A steady rhythm (every 2 to 4 weeks) keeps people opening.", [], "strong", 0.1))

    order = {"strong": 0, "early": 1, "tip": 2}
    recs.sort(key=lambda r: (order[r["confidence"]], -r["impact"]))
    if len(recs) < 3:
        have = {r["category"] for r in recs}
        recs += [t for t in GENERAL_TIPS if t["category"] not in have][: 4 - len(recs)]
    return recs


# ---------------------------------------------------------------------------------------------
# Draft check (editor "Tips" tab)
# ---------------------------------------------------------------------------------------------

def _check(cid, status, title, detail="", action=None) -> dict:
    return {"id": cid, "status": status, "title": title, "detail": detail, "action": action}


def review_draft(subject: str, preheader: str, content: dict, audience) -> dict:
    snap = snapshot()
    bm = benchmarks(snap)
    cs = content_stats(content)
    blocks = content.get("blocks", [])
    checks = []
    subject = (subject or "").strip()
    preheader = (preheader or "").strip()

    # Subject
    n = subject_length(subject)
    if not subject:
        checks.append(_check("subject", "warn", "Add a subject line", "It's the first thing people see in their inbox."))
    elif bm.short_subject and bm.short_subject.diff >= 0.03 and n > SHORT_SUBJECT:
        s = bm.short_subject
        checks.append(_check("subject", "warn", f"Subject is {n} characters",
                             f"Your subjects of {SHORT_SUBJECT} characters or fewer were opened by {pct(s.a)}, longer ones "
                             f"by {pct(s.b)}. Try trimming it."))
    elif n > 70:
        checks.append(_check("subject", "warn", f"Subject is {n} characters", "Phones cut it off around 40 to 60 characters."))
    elif n < 15:
        checks.append(_check("subject", "tip", f"Subject is only {n} characters", "Say what's inside: the main news or a number."))
    else:
        checks.append(_check("subject", "good", f"Subject length is good ({n} characters)"))

    if subject:
        if _MERGE.search(subject):
            checks.append(_check("subject-name", "good", "Subject is personalized"))
        elif bm.personalized and bm.personalized.diff >= 0.03:
            s = bm.personalized
            checks.append(_check("subject-name", "tip", "Add {{first_name}} to the subject",
                                 f"Your personalized subjects were opened by {pct(s.a)}, against {pct(s.b)} without."))
        if _DIGIT.search(_MERGE.sub("", subject)):
            checks.append(_check("subject-number", "good", "Subject includes a number"))
        elif bm.subject_number and bm.subject_number.diff >= 0.03 and cs["figures"]:
            s = bm.subject_number
            figs = list(dict.fromkeys(f.strip() for f in cs["figures"]))[:3]
            checks.append(_check("subject-number", "tip", "Put a key number in the subject",
                                 f"Subjects with a figure were opened by {pct(s.a)}, against {pct(s.b)}. This draft "
                                 f"mentions {', '.join(figs)}."))

    # Preview text
    if not preheader:
        checks.append(_check("preheader", "warn", "Add preview text",
                             "Outlook and phones show it right after the subject. One short sentence is enough."))
    elif preheader.lower() == subject.lower():
        checks.append(_check("preheader", "tip", "Preview text repeats the subject", "Use it to add a second detail."))
    else:
        checks.append(_check("preheader", "good", "Preview text is set"))

    # Placeholders left by the AI
    found, first_block = [], None
    for text in (subject, preheader):
        found += _PLACEHOLDER.findall(text)
    for b in blocks:
        hits = [p for t in _block_texts(b) for p in _PLACEHOLDER.findall(t)]
        if hits and first_block is None:
            first_block = b["id"]
        found += hits
    if found:
        uniq = list(dict.fromkeys(found))
        checks.append(_check("placeholders", "warn",
                             f"{len(found)} placeholder{'s' if len(found) != 1 else ''} to fill in",
                             "Replace " + ", ".join(uniq[:4]) + (" and more" if len(uniq) > 4 else "") + " before sending.",
                             {"type": "select", "block": first_block, "label": "Show me"} if first_block else None))
    elif blocks:
        checks.append(_check("placeholders", "good", "No placeholders left to fill"))

    # Length
    words = cs["words"]
    if blocks:
        if bm.short_email and bm.short_email.diff >= 0.03 and words > SHORT_EMAIL:
            s = bm.short_email
            checks.append(_check("length", "tip", f"{words} words",
                                 f"Your newsletters of {SHORT_EMAIL} words or fewer got {pct(s.a)} of openers clicking, "
                                 f"longer ones {pct(s.b)}.",
                                 {"type": "ai", "label": "Shorten with AI",
                                  "prompt": f"Make it shorter, under {SHORT_EMAIL} words; keep every fact, number and link."}))
        elif words > 450:
            checks.append(_check("length", "tip", f"{words} words is long",
                                 "Most people skim. Keep the main points and link to the details.",
                                 {"type": "ai", "label": "Shorten with AI",
                                  "prompt": "Make it shorter and easier to skim; keep every fact, number and link."}))
        elif words < 25:
            checks.append(_check("length", "tip", f"Only {words} words so far", "Add the main story or ask the AI writer for a draft."))
        else:
            checks.append(_check("length", "good", f"{words} words, about {max(1, round(words / 200))} min to read"))

    # Call to action
    if blocks:
        missing = [b for b in blocks if b["type"] == "button" and not b.get("href")]
        if missing:
            checks.append(_check("button-link", "warn", "A button has no link",
                                 "Add the link URL in the properties panel. Sending is blocked until then.",
                                 {"type": "select", "block": missing[0]["id"], "label": "Show me"}))
        if not cs["buttons"]:
            checks.append(_check("button", "tip", "Add one clear button",
                                 "A button for the main next step (read, register, RSVP) gets more clicks than a text link."))
        else:
            if cs["buttons"] > 3:
                checks.append(_check("buttons", "tip", f"{cs['buttons']} buttons compete for attention",
                                     "Keep one main button and turn the rest into text links."))
            top = cs["first_button_pos"] < 0.5
            if not top and bm.button_top and bm.button_top.diff >= 0.02:
                s = bm.button_top
                first = next(b for b in blocks if b["type"] == "button")
                checks.append(_check("button-position", "tip", "Move the main button higher",
                                     f"When the first button was in the top half, {pct(s.a)} of openers clicked, "
                                     f"against {pct(s.b)} lower down.",
                                     {"type": "select", "block": first["id"], "label": "Show me"}))
            elif not missing:
                checks.append(_check("button", "good", "Has a clear call to action"))

    # Key figures
    if cs["has_stats"]:
        checks.append(_check("figures", "good", "Key numbers are highlighted in a Stats block"))
    elif len(set(cs["figures"])) >= 2:
        figs = list(dict.fromkeys(f.strip() for f in cs["figures"]))[:3]
        checks.append(_check("figures", "tip", "Highlight the key numbers",
                             f"This draft mentions {', '.join(figs)}. A Stats block shows them as big figures people "
                             "notice at a glance.",
                             {"type": "ai", "label": "Add with AI",
                              "prompt": "Add a stats block near the top that highlights the 2 to 4 most important figures "
                                        "already in this newsletter. Don't add any new numbers and keep everything else."}))

    # Images
    no_alt = [b for b in blocks if b["type"] == "image" and not b.get("alt")]
    if no_alt:
        checks.append(_check("alt", "warn", "An image has no description",
                             "Outlook often blocks images; the description (alt text) shows instead.",
                             {"type": "select", "block": no_alt[0]["id"], "label": "Show me"}))

    if blocks and not any(b["type"] == "footer" for b in blocks):
        checks.append(_check("footer", "tip", "Add a footer", "Say who sent it and who to contact with questions."))

    # Audience
    aud = normalize_audience(audience)
    overall = snap.open_rate
    if overall is not None and snap.departments:
        rates = {d["name"]: d for d in snap.departments if d["sent"] >= 10}
        if aud["mode"] == "departments":
            pool = [rates[d] for d in aud.get("departments", []) if d in rates]
        elif aud["mode"] == "all":
            pool = list(rates.values())
        else:
            pool = []
        low = sorted((d for d in pool if d["open_rate"] <= overall - 0.08), key=lambda d: d["open_rate"])
        if low:
            d = low[0]
            checks.append(_check("audience", "tip", f"{d['name']} usually opens less ({pct(d['open_rate'])})",
                                 f"Overall it's {pct(overall)}. Mention something for {d['name']} early in the newsletter."))

    bt = best_time(snap)
    if bt:
        checks.append(_check("time", "tip", f"Best time to send: {bt['label']}", bt["reason"],
                             {"type": "time", "label": "Use when scheduling", "at": bt["at"]}))

    order = {"warn": 0, "tip": 1, "good": 2}
    checks.sort(key=lambda c: order[c["status"]])
    scored = [c for c in checks if c["id"] != "time"]
    return {
        "checks": checks,
        "good": sum(1 for c in scored if c["status"] == "good"),
        "total": len(scored),
        "warnings": sum(1 for c in scored if c["status"] == "warn"),
        "based_on": len(snap.newsletters),
    }


# ---------------------------------------------------------------------------------------------
# Studio numbers (Stats block filler and AI context)
# ---------------------------------------------------------------------------------------------

def studio_facts(snap: Snapshot | None = None, space: str | None = "hr") -> list[dict]:
    """Studio numbers: people and newsletter totals, plus the figures of the space the user works in (only that one)."""
    snap = snap or snapshot()
    facts = []

    def add(group, key, value, label, note=""):
        facts.append({"group": group, "key": key, "value": str(value), "label": label, "note": note})

    depts = len(snap.headcount)
    add("People", "employees", snap.active_employees, "Newsletter recipients (active employees)",
        f"across {_n(depts, 'department')}" if depts else "")
    if depts:
        add("People", "departments", depts, "Departments")
    for name, count in snap.headcount:
        add("People", f"dept:{name}", count, f"{name} team members")

    # HR profiles: joiners and leavers in the last 30 days (Headcount & Attrition space only)
    profiles = Recipient.query.filter(Recipient.date_of_joining.isnot(None)).with_entities(
        Recipient.date_of_joining, Recipient.date_of_exit).all() if space == "hr" else []
    if profiles:
        today = datetime.now().astimezone().date()
        since = today - timedelta(days=30)
        add("People", "joined30", sum(1 for j, _x in profiles if since <= j <= today), "Joined in the last 30 days")
        add("People", "left30", sum(1 for _j, x in profiles if x and since <= x <= today), "Left in the last 30 days")

    news = snap.newsletters
    if news:
        first = news[0].started
        add("Newsletters", "sent", len(news), "Newsletters sent", f"since {first.strftime('%B %Y')}")
        recent = sum(1 for n in news if (datetime.now().astimezone() - n.started).days <= 30)
        add("Newsletters", "sent30", recent, "Newsletters in the last 30 days")
        add("Newsletters", "delivered", f"{snap.delivered:,}", "Emails delivered")
        add("Engagement", "open_rate", pct(snap.open_rate), "Average open rate")
        add("Engagement", "click_rate", pct(snap.click_rate), "Average click rate")
        last = news[-1]
        add("Engagement", "last_open", pct(last.open_rate), "Opened the latest newsletter", last.name)
        top = max(news, key=lambda n: n.open_rate)
        if top.id != last.id:
            add("Engagement", "top_open", pct(top.open_rate), "Opened our most-read newsletter", top.name)
        if snap.departments:
            d = snap.departments[0]
            add("Engagement", "top_dept", pct(d["open_rate"]), f"{d['name']} open rate", "most engaged team")
        bt = best_time(snap)
        if bt:
            add("Engagement", "reading_window", bt["reading_window"].replace(" to ", "–"), "When most people read",
                f"{pct(bt['reading_share'])} of opens")

    # Workforce (from employee profiles): financial year to date, same numbers as the dashboard. Totals only.
    wf = _workforce_fytd() if space == "hr" else None
    if space in ("dei", "performance", "goals"):
        from ..spaces import SPACES
        from .space_reports import space_report

        r = space_report(space)
        if not r.get("empty"):
            for g in r["groups"]:
                when = f", {g['note']}" if g.get("note") else ""
                for c in g["cards"]:
                    change = f"{c['delta']} vs {r['compare_label']}" if c["delta"] and r.get("compare_label") else c["note"]
                    add(SPACES[space]["name"], f"{space}:{c['key']}", c["display"], f"{c['label']}{when}", change)
    if wf:
        cards = {c["key"]: c for c in wf["cards"]}
        period = wf["label"]
        for key, label in (("headcount", "Headcount"), ("joiners", "Joiners"), ("exits", "Exits"),
                           ("attrition", "Attrition rate (annualised)"), ("voluntary", "Voluntary attrition"),
                           ("regrettable", "Regrettable attrition"), ("notice", "Serving notice")):
            c = cards[key]
            change = f"{c['delta']} vs {wf['compare_label']}" if c["delta"] else ""
            add("Workforce", f"wf:{key}", c["display"], f"{label}, {period}", change)
    return facts


def _workforce_fytd():
    from .workforce import workforce_kpis

    k = workforce_kpis("fytd")
    return None if k.get("empty") else k


def studio_data_text(snap: Snapshot | None = None, space: str | None = "hr") -> str:
    """The studio numbers as plain text for the AI writer: totals plus the current space's figures only."""
    snap = snap or snapshot()
    today = datetime.now().astimezone().strftime("%d %B %Y")
    lines = [f"As of {today}:"]
    for f in studio_facts(snap, space):
        if f["key"].startswith("dept:"):
            continue
        note = f" ({f['note']})" if f["note"] else ""
        lines.append(f"- {f['label']}: {f['value']}{note}")
    if snap.headcount:
        lines.append("- Newsletter recipients by department (active, not paused): " + ", ".join(f"{d} {n}" for d, n in snap.headcount))
    if space in ("dei", "performance", "goals"):
        from .space_newsletter import facts_text
        from .space_reports import space_report

        r = space_report(space)
        if not r.get("empty"):
            lines.append(facts_text(r))
    wf = _workforce_fytd() if space == "hr" else None
    if wf:
        ch = wf["charts"]

        def pc(x):
            return "–" if x is None else f"{x * 100:.1f}%"

        lines.append(f"- Attrition by department, {wf['label']} (annualised; headcount, exits, attrition, voluntary): " + "; ".join(
            f"{r['name']} {r['headcount']}, {r['exits']} exits, {pc(r['attrition'])}, {pc(r['voluntary'])}"
            for r in ch["by_department"]))
        lines.append(f"- Attrition by business unit, {wf['label']} (headcount, attrition): " + "; ".join(
            f"{r['name']} {r['headcount']}, {pc(r['attrition'])}" for r in ch["by_bu"]))
        if ch["exit_reasons"]:
            lines.append("- Exit reasons this period: " + ", ".join(f"{x['label']} {x['value']}" for x in ch["exit_reasons"]))
    return "\n".join(lines)


def ideas_context(snap: Snapshot | None = None, space: str | None = "hr") -> str:
    """Engagement data summarised for the AI topic-ideas request."""
    snap = snap or snapshot()
    out = [studio_data_text(snap, space), ""]
    if snap.newsletters:
        out.append("Sent newsletters (oldest first):")
        for n in snap.newsletters[-12:]:
            links = "; ".join(f"{label} ({people} people)" for label, people in snap.top_links.get(n.id, []))
            out.append(
                f"- {n.started.strftime('%d %b %Y')} | {n.name} | subject: {n.subject} | to: {n.audience} | "
                f"opened {pct(n.open_rate)}, clicked {pct(n.click_rate)}" + (f" | most clicked: {links}" if links else "")
            )
        out.append("")
    else:
        out.append("No newsletters have been sent yet.\n")
    if snap.departments:
        out.append("Open rate by department: " + ", ".join(
            f"{d['name']} {pct(d['open_rate'])}" for d in snap.departments))
    upcoming = Campaign.query.filter(Campaign.status.in_([CampaignStatus.SCHEDULED, CampaignStatus.DRAFT])).order_by(
        Campaign.updated_at.desc()).limit(8).all()
    names = [c.name for c in upcoming if c.name and c.name != "Untitled newsletter"]
    if names:
        out.append("Already drafted or scheduled: " + "; ".join(names))
    recs = [r["title"] for r in recommendations(snap) if r["confidence"] != "tip"]
    if recs:
        out.append("What the data suggests: " + "; ".join(recs))
    return "\n".join(out)

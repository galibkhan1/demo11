"""Who receives a campaign ("To").

Audience format stored on Campaign.audience:
    {"mode": "all"}                                  every active employee
    {"mode": "departments", "departments": [...]}    active employees in those departments
    {"mode": "employees", "employee_ids": [...]}     hand-picked active employees

Older rows without "mode" are read as: departments listed -> "departments", otherwise "all".
"""

from .. import db
from ..models import Recipient

MODES = ("all", "departments", "employees")
MAX_PICKED = 5000


def audience_mode(audience) -> str:
    audience = audience if isinstance(audience, dict) else {}
    mode = audience.get("mode")
    if mode in MODES:
        return mode
    return "departments" if audience.get("departments") else "all"


def known_departments() -> list[str]:
    rows = db.session.query(Recipient.department).filter(Recipient.department != "").distinct().all()
    return sorted(r[0] for r in rows)


def normalize_audience(raw) -> dict:
    """Validate an audience coming from the browser against the database."""
    raw = raw if isinstance(raw, dict) else {}
    mode = audience_mode(raw)
    if mode == "departments":
        known = set(known_departments())
        depts = sorted({d for d in raw.get("departments", []) if isinstance(d, str) and d in known})
        return {"mode": "departments", "departments": depts}
    if mode == "employees":
        ids = []
        for value in raw.get("employee_ids", [])[:MAX_PICKED]:
            try:
                ids.append(int(value))
            except (TypeError, ValueError):
                continue
        existing = {r for (r,) in db.session.query(Recipient.id).filter(Recipient.id.in_(ids))} if ids else set()
        seen, ordered = set(), []
        for i in ids:
            if i in existing and i not in seen:
                seen.add(i)
                ordered.append(i)
        return {"mode": "employees", "employee_ids": ordered}
    return {"mode": "all"}


def audience_query(audience):
    """Active recipients matching an audience."""
    query = Recipient.query.filter(Recipient.active.is_(True))
    mode = audience_mode(audience)
    audience = audience or {}
    if mode == "departments":
        depts = [d for d in audience.get("departments", []) if d]
        query = query.filter(Recipient.department.in_(depts)) if depts else query.filter(db.false())
    elif mode == "employees":
        ids = audience.get("employee_ids", [])
        query = query.filter(Recipient.id.in_(ids)) if ids else query.filter(db.false())
    return query


def audience_people(audience) -> list[dict]:
    """Details of hand-picked employees, in the order they were picked (for the editor)."""
    if audience_mode(audience) != "employees":
        return []
    ids = (audience or {}).get("employee_ids", [])
    if not ids:
        return []
    by_id = {r.id: r for r in Recipient.query.filter(Recipient.id.in_(ids)).all()}
    return [person_json(by_id[i]) for i in ids if i in by_id]


def person_json(r: Recipient) -> dict:
    return {"id": r.id, "name": r.name, "email": r.email, "department": r.department, "active": r.active}


def audience_label(audience) -> str:
    mode = audience_mode(audience)
    if mode == "departments":
        return ", ".join((audience or {}).get("departments", [])) or "No departments selected"
    if mode == "employees":
        n = len((audience or {}).get("employee_ids", []))
        return f"{n} selected employee{'' if n == 1 else 's'}"
    return "All employees"

"""Prompt suggestions worked out from the studio's data (no AI call; instant).

Two kinds:
- focus: questions for the data storyboard's executive summary ("Why did Engineering's open rate fall?").
- newsletter: ready-to-edit briefs for the AI writer ("Update for Customer Support"). Facts the writer still
  has to supply are left as [bracketed] gaps, so the AI never invents them.

Suggestions never name individual employees.
"""

from datetime import datetime, timedelta, timezone

from ..models import Recipient
from .insights import best_time, snapshot
from .storyboard import PERIODS, Window, _load, _rate, pct, window_metrics

MAX_EACH = 6


def _short(name: str, limit: int = 26) -> str:
    return name if len(name) <= limit else name[: limit - 1].rstrip(" :,-") + "…"


def suggest_prompts(period: str = "30", department: str = "", include_hr: bool = False, space: str | None = "hr") -> dict:
    """Suggestions for the editor and Insights. ``space`` is the space the user is working in: the recommended prompts
    and the "Use your data" focus ideas cover only that space (None = no space: newsletter ideas only)."""
    label, days = PERIODS.get(period, PERIODS["30"])
    now = datetime.now(timezone.utc)
    cur_win = Window(now - timedelta(days=days) if days else None, now)
    prev_win = Window(cur_win.start - timedelta(days=days), cur_win.start) if days else None
    campaigns, rows = _load()
    cur = window_metrics(cur_win, department, campaigns, rows)
    prev = window_metrics(prev_win, department, campaigns, rows) if prev_win else None
    p = prev if prev and prev.sent else None
    who = department or "everyone"
    span = f"in the {label.lower()}" if days else "so far"

    focus, letters = [], []

    def add(target, short, prompt, **extra):
        if len(target) < MAX_EACH and all(x["prompt"] != prompt for x in target):
            target.append({"label": short, "prompt": prompt, **extra})

    # Department open rates in this period (and change vs the previous one)
    depts = []
    for name, v in cur.departments.items():
        if v["delivered"] < 5 or name == "(no department)":
            continue
        rate = _rate(v["opened"], v["delivered"])
        before = p.departments.get(name) if p else None
        change = (rate - _rate(before["opened"], before["delivered"])) * 100 if before and before["delivered"] else None
        depts.append({"name": name, "open": rate, "change": change})

    # ---------------- focus questions for the storyboard summary ----------------
    if cur.sent:
        if p:
            moves = [(n, a, b) for n, a, b in (("open rate", cur.open_rate, p.open_rate),
                                               ("click rate", cur.click_rate, p.click_rate),
                                               ("click-to-open rate", cur.click_to_open, p.click_to_open))
                     if a is not None and b is not None]
            if moves:
                name, a, b = max(moves, key=lambda m: abs(m[1] - m[2]))
                d = (a - b) * 100
                if abs(d) >= 1:
                    verb = "rose" if d > 0 else "fell"
                    add(focus, f"Why the {name} {verb}",
                        f"Explain why the {name} {verb} {abs(d):.1f} points against the previous period "
                        f"({pct(b)} to {pct(a)}), and what that means for the next newsletter.")
        if len(depts) >= 2 and not department:
            low = min(depts, key=lambda r: r["open"])
            top = max(depts, key=lambda r: r["open"])
            add(focus, f"Why {low['name']} reads least",
                f"Focus on {low['name']}: they opened {pct(low['open'])} of newsletters, the lowest of any team "
                f"(the highest is {top['name']} at {pct(top['open'])}). What should we change for them?")
            drops = [r for r in depts if r["change"] is not None and r["change"] <= -5]
            if drops:
                worst = min(drops, key=lambda r: r["change"])
                add(focus, f"What changed for {worst['name']}",
                    f"{worst['name']}'s open rate fell {abs(worst['change']):.1f} points against the previous period. "
                    "Lead with that and suggest one practical fix.")
            missed = cur.recipients - cur.readers
            if missed:
                add(focus, f"The {missed} we're not reaching",
                    f"{missed} employee{'s' if missed != 1 else ''} received newsletters but opened none. Focus on reach: "
                    "why might we be missing them, and how do we get through? Don't name anyone.")
            add(focus, f"What {top['name']} does right",
                f"{top['name']} reads the most ({pct(top['open'])} opened). What can we learn from them for the other teams?")
        if len(depts) < 2 or department:
            missed = cur.recipients - cur.readers
            if missed:
                add(focus, f"The {missed} we're not reaching",
                    f"{missed} employee{'s' if missed != 1 else ''} received newsletters but opened none. Focus on reach: "
                    "why might we be missing them, and how do we get through? Don't name anyone.")
        best = max(cur.newsletters, key=lambda n: n["open_rate"])
        if len(cur.newsletters) >= 2:
            add(focus, f"Why “{_short(best['name'], 20)}” worked",
                f"What made {best['name']} the most-read newsletter ({pct(best['open_rate'])} opened)? "
                "Suggest how to repeat it.")
        if cur.links:
            link, letter, people = cur.links[0]
            add(focus, "What people clicked",
                f"The most-clicked link was “{link}” in {letter} ({people} people). "
                "What does that tell us about what employees want to read?")
        if p:
            add(focus, "Compare with last period",
                "Compare this period with the previous one: lead with the biggest change, then what stayed the same.")

    # ---------------- newsletter briefs for the AI writer ----------------
    snap = snapshot()
    overall = snap.open_rate
    if cur.sent or snap.newsletters:
        add(letters, "Numbers roundup",
            f"Monthly numbers roundup for {who}. Show our key figures in a stats block near the top: "
            "[your business figures, e.g. revenue, new customers, hires]. Add our newsletter readership too. "
            "One short paragraph on each figure, upbeat, under 250 words.", use_data=True)
    if depts and not department:
        low = min(depts, key=lambda r: r["open"])
        add(letters, f"Update for {low['name']}",
            f"Short, targeted update for the {low['name']} team, who open {pct(low['open'])} of our newsletters"
            + (f" against {pct(overall)} overall" if overall is not None else "")
            + f". Lead with [the news that matters most to {low['name']}], keep it under 150 words, "
            "with one clear button to [link].", departments=[low["name"]])
    if department:
        add(letters, f"Update for {department}",
            f"Short update for the {department} team: lead with [the news that matters most to {department}], "
            "keep it under 150 words, with one clear button to [link].", departments=[department])
    if cur.links:
        link, letter, people = cur.links[0]
        add(letters, f"More on “{_short(link, 22)}”",
            f"Follow-up to “{link}”, which {people} people clicked in {letter}. Share [what's new since then] "
            "and link to [URL]. Short and specific.")
    if cur.newsletters:
        best = max(cur.newsletters, key=lambda n: n["open_rate"])
        add(letters, f"In the style of “{_short(best['name'], 18)}”",
            f"Write a newsletter about [topic] in the same style and length as {best['name']}, "
            f"our most-read newsletter {span} ({pct(best['open_rate'])} opened). Lead with the key number in the subject.")
    if cur.recipients - cur.readers > 0:
        add(letters, "Win back quiet readers",
            "A short, friendly newsletter for colleagues who haven't opened recent newsletters: the "
            "[3 most important recent updates] in one line each, a subject line with a number, under 120 words.")
    bt = best_time(snap)
    if bt and bt.get("half_open_within") is not None:
        add(letters, "Event reminder",
            f"Reminder about [event] on [date] at [place]. Half of our readers open within "
            f"{bt['half_open_within']:.1f} hours, so it goes out ahead of time. One button to [RSVP link], under 120 words.")
    if not letters:
        add(letters, "First newsletter",
            "A friendly first newsletter introducing [what this newsletter is for] and what's coming next month: "
            "[2 or 3 upcoming items]. Under 200 words.")

    return {"period": period, "period_label": label, "department": department, "focus": focus, "newsletter": letters,
            "hr": suggest_hr_prompts() if include_hr and space == "hr" else [],
            "space": (suggest_hr_prompts() if space == "hr" else suggest_space_focus(space)) if include_hr and space else [],
            "writer": writer_prompts(letters, space)}


def suggest_hr_prompts(period: str = "fytd") -> list[dict]:
    """Focus questions for the Headcount & Attrition storyboard, each with the scope it applies to."""
    from .workforce import leader_options, workforce_kpis

    k = workforce_kpis(period, {})
    if k.get("empty"):
        return []
    cards = {c["key"]: c for c in k["cards"]}
    ch = k["charts"]
    out = []

    def add(label, prompt, **scope):
        if len(out) < 8:
            out.append({"label": label, "prompt": prompt, "scope": {"kind": "hr", "period": period, **scope}})

    everyone = Recipient.query.filter(Recipient.date_of_joining.isnot(None)).all()
    heads = [x for x in leader_options(everyone) if x["rank"] <= 1 and x["size"] >= 10]  # CEO + business-unit heads
    ranked = []
    for x in heads:
        if x["rank"] == 0:
            continue
        kk = workforce_kpis(period, {"leader": x["value"]})
        rate = next(c for c in kk["cards"] if c["key"] == "attrition")
        ranked.append((x, rate["display"], float(rate["display"].rstrip("%")) if rate["display"] != "–" else 0))
    ranked.sort(key=lambda t: -t[2])
    for x, display, _v in ranked[:2]:
        add(f"Attrition in {x['name']}'s org",
            f"Department-wise attrition for {x['name']}'s org ({x['designation']}, {display} annualised): which teams are "
            "losing the most people, voluntary vs involuntary, and how it compares with last year.", leader=x["value"])
    depts = [r for r in ch["by_department"] if r["headcount"] >= 10 and r["attrition"]]
    if depts:
        top = max(depts, key=lambda r: r["attrition"])
        add(f"Why {top['name']} attrition is {top['attrition'] * 100:.1f}%",
            f"Focus on {top['name']}: annualised attrition is {top['attrition'] * 100:.1f}%, the highest of any team. "
            "What do the recorded exit reasons, voluntary vs involuntary split and early exits show, and where should we act?",
            department=top["name"])
    regret = cards["regrettable"]
    if regret["display"] not in ("–", "0.0%"):
        add(f"Regrettable exits ({regret['note'].split(' ')[0]})",
            f"Focus on regrettable attrition: {regret['note']} ({regret['display']} annualised). Which departments are "
            "affected and what were the recorded reasons? Suggest one retention action.")
    early = cards["early"]
    if early["display"] not in ("–", "0.0%"):
        add(f"Early exits: {early['display']} of leavers",
            f"{early['display']} of this period's leavers left within 6 months of joining ({early['note']}). "
            "Treat it as an onboarding check: which teams, and what does it suggest about hiring and onboarding?")
    add("Gender diversity update",
        f"Gender diversity: women are {cards['female']['display']} of headcount ({cards['female']['note']}). "
        "Point out the departments with the highest and lowest share of women and what that means for hiring.")
    if cards["attrition"]["delta"]:
        add("Attrition vs last year",
            f"Compare attrition with {k['compare_label']}: overall attrition is {cards['attrition']['display']} "
            f"({cards['attrition']['delta']}). Lead with the biggest change by department, then what stayed the same.")
    if cards["notice"]["display"] not in ("0", "–"):
        add(f"{cards['notice']['display']} people serving notice",
            f"{cards['notice']['display']} people have resigned and are serving notice. Summarise which departments the "
            "upcoming exits are in and what leaders should plan for. Don't name anyone.")
    return out


def writer_prompts(letters: list | None = None, space: str | None = "hr") -> list[dict]:
    """Recommended prompts for the AI writer box, built from the data.

    Each follows a good-prompt shape: who it's for, what to cover (and which studio numbers to use), tone,
    length and the call to action, with [brackets] for facts only the writer knows.
    """
    from datetime import date, timedelta

    from .workforce import workforce_kpis

    out = []

    def add(label, prompt, use_data=False):
        if all(x["prompt"] != prompt for x in out):
            out.append({"label": label, "prompt": prompt, "use_data": use_data})

    if space in ("dei", "performance", "goals"):
        for x in _space_writer_prompts(space):
            add(x["label"], x["prompt"], x["use_data"])
    k = workforce_kpis("fytd") if space == "hr" else {"empty": True}
    if not k.get("empty"):
        cards = {c["key"]: c for c in k["cards"]}
        ch = k["charts"]
        add("People update: attrition by team",
            f"Monthly people update for all employees. Using the studio data for {k['label']}, put headcount, joiners, "
            "exits and attrition in a stats block near the top, then a short section on attrition by department that "
            "names the teams with the highest and lowest rates. Add [any HR announcement or policy change]. Warm, factual "
            "tone, under 300 words. Don't name individual employees.", use_data=True)
        joiners = recent_joiners()
        if joiners:
            n = len(joiners)
            add(f"Welcome {n} new joiner{'s' if n != 1 else ''}", welcome_prompt(joiners))
        bus = [r for r in ch["by_bu"] if r["headcount"] >= 10 and r["attrition"] is not None]
        if bus:
            top = max(bus, key=lambda r: r["attrition"])
            head = (Recipient.query.filter_by(business_unit=top["name"], grade="G12").first())
            who = f" ({head.name}'s org)" if head else ""
            add(f"{top['name']} team update",
                f"Update for the {top['name']} business unit{who}. Using the studio data for {k['label']}, cover headcount, "
                f"joiners, exits and attrition by department for {top['name']} ({top['attrition'] * 100:.1f}% annualised), "
                "call out the team with the highest attrition, and end with [one ask or message from the leader]. "
                "Direct and constructive, under 250 words.", use_data=True)
        regret = cards["regrettable"]
        if regret["display"] not in ("–", "0.0%"):
            add("Retention note for managers",
                f"Short note to people managers about retention: regrettable attrition is {regret['display']} "
                f"({regret['note']}) for {k['label']}. Using the studio data, show which departments it's in, suggest "
                "[2 or 3 retention actions], and link to [stay-interview guide]. Supportive and practical, under 200 words.",
                use_data=True)
    for x in (letters or [])[:3]:
        add(x["label"], x["prompt"], bool(x.get("use_data")))
    return out[:7]


def _space_cards(space: str):
    from .space_reports import space_report

    r = space_report(space)
    if r.get("empty"):
        return None, {}
    return r, {c["key"]: c["display"] for g in r["groups"] for c in g["cards"]}


def _space_writer_prompts(space: str) -> list[dict]:
    """Recommended prompts for the DEI, Performance and Goals spaces (each quotes the space's own numbers)."""
    r, c = _space_cards(space)
    if r is None or (space == "goals" and r.get("notice")):
        return []
    rule = " Don't name individual employees."
    if space == "dei":
        return [
            {"label": "DEI update: gender balance", "use_data": True, "prompt":
             f"Diversity update for all employees. Using the studio data, put the share of women in the workforce ({c['female']}), women in "
             f"leadership ({c['leaders']}) and the share of women among this year's joiners ({c['joiners_f']}) in a stats block "
             "near the top, then a short section on where we're making progress and where we aren't, by level and department. "
             "Add [one DEI initiative or event, with its link]. Respectful, factual tone, under 300 words." + rule},
            {"label": "Women in leadership note", "use_data": True, "prompt":
             f"Short note to leaders and people managers: women hold {c['leaders']} of leadership roles and {c['managers']} of "
             "manager roles. Using the studio data, show the share of women by level, suggest [2 or 3 actions, e.g. diverse "
             "shortlists, mentoring] and link to [the DEI policy]. Constructive, under 200 words." + rule},
            {"label": "Celebrate an inclusion day", "use_data": False, "prompt":
             "Newsletter for [International Women's Day / Pride Month / another inclusion day] on [date]: what we're doing "
             "([events]), how to take part, and a short message from [leader]. Warm and inclusive, under 200 words, one button "
             "to [RSVP or event page]."},
        ]
    if space == "performance":
        return [
            {"label": "Performance cycle update", "use_data": True, "prompt":
             f"Update for all employees on the performance cycle. Using the studio data, show the rating spread (average "
             f"{c['avg']}, {c['high']} rated 4 or 5) in a stats block, explain what the ratings mean and what happens next "
             "([calibration dates, promotion timelines]). Clear and reassuring, under 250 words." + rule},
            {"label": "Retaining high performers", "use_data": True, "prompt":
             f"Note to people managers: high-performer attrition is {c['high_att']} this financial year and {c['high_notice']} "
             "high performers are serving notice. Using the studio data, show which departments are most affected, suggest "
             "[2 or 3 retention actions] and link to [stay-interview guide]. Practical, under 200 words." + rule},
            {"label": "Thank you to top teams", "use_data": True, "prompt":
             "A thank-you newsletter recognising the departments with the highest average ratings this cycle (from the studio "
             "data), with [one highlight per team]. No individual names or ratings. Warm, under 200 words."},
        ]
    return [
        {"label": "Goals check-in", "use_data": True, "prompt":
         f"Goals check-in for all employees. Using the studio data, show average progress ({c['avg_progress']}), goals "
         f"completed ({c['completed']}) and goals at risk ({c['at_risk']}) in a stats block, then what to do before the next "
         "review: [update progress by [date] in [tool]]. Encouraging, under 250 words." + rule},
        {"label": "Goals at risk: help for managers", "use_data": True, "prompt":
         f"Note to managers: {c['at_risk']} of goals are at risk, {c['behind']} are behind and {c['overdue']} are overdue. "
         "Using the studio data, show which teams are furthest behind, suggest [3 ways to unblock goals] and link to "
         "[goal-setting guide]. Supportive, under 200 words." + rule},
        {"label": "Reminder: update your goals", "use_data": False, "prompt":
         "Short reminder to update goal progress in [tool] by [date]: why it matters, how long it takes ([5 minutes]) and "
         "who to ask ([HR contact]). Friendly, under 120 words, one button to [tool link]."},
    ]


def suggest_space_focus(space: str | None) -> list[dict]:
    """Focus ideas for "Use your data" in the DEI, Performance and Goals spaces, each with the team it applies to."""
    if space not in ("dei", "performance", "goals"):
        return []
    r, c = _space_cards(space)
    if r is None or (space == "goals" and r.get("notice")):
        return []
    panels = {p["id"]: p for p in r["panels"]}
    out = []

    def add(label, prompt, scope=None):
        out.append({"label": label, "prompt": prompt, "scope": {"kind": space, **(scope or {})}})

    dept = panels.get("dept", {}).get("items") or []
    if space == "dei":
        add(f"Women in leadership: {c['leaders']}",
            f"Focus on women in leadership ({c['leaders']} of G10+ roles, against {c['female']} of all employees): where the "
            "gap opens up by level, and one practical step.")
        add("Joiners vs leavers",
            f"Compare the share of women among this year's joiners ({c['joiners_f']}) and leavers ({c['leavers_f']}), and what "
            "it means for gender balance.")
        add("Female vs male attrition",
            f"Focus on attrition by gender: {c['att_f']} for women and {c['att_m']} for men (annualised). Where is the gap, and "
            "what could we do?")
        if dept:
            lo = dept[-1]
            add(f"Gender balance in {lo['label']}", f"Focus on {lo['label']}, where women are {lo['display']} of the team: "
                "compare it with the company and suggest one action.", {"department": lo["label"]})
    elif space == "performance":
        add(f"High-performer attrition: {c['high_att']}",
            f"Focus on keeping high performers: their attrition is {c['high_att']} this year and {c['high_notice']} are serving "
            "notice. Which teams are most affected?")
        add("Rating spread by level", "Focus on how ratings differ by level and tenure, and what that suggests for growth "
            "and development.")
        add("Leavers' ratings", f"Focus on who is leaving: leavers' average rating is {c['leaver_avg']}. Are we losing "
            "strong or weaker performers?")
        if len(dept) >= 2:
            lo = dept[-1]
            add(f"Ratings in {lo['label']}", f"Focus on {lo['label']}, with the lowest average rating ({lo['display']}): "
                "compare it with the company, without singling anyone out.", {"department": lo["label"]})
    else:
        add(f"Goals at risk: {c['at_risk']}",
            f"Focus on the goals that need attention: {c['at_risk']} at risk, {c['behind']} behind and {c['overdue']} overdue. "
            "Which teams, and what would help?")
        add(f"Due this quarter: {c['due_quarter']}", f"Focus on the {c['due_quarter']} open goals due this quarter and what "
            "teams should prioritise.")
        add("Teams furthest ahead", "Focus on the teams furthest ahead on their goals, and what others can learn from them.")
        if len(dept) >= 2:
            lo = dept[-1]
            add(f"Progress in {lo['label']}", f"Focus on {lo['label']}, the team furthest behind ({lo['display']} average "
                "progress): what's holding it back and one practical step.", {"department": lo["label"]})
    return out[:6]



def recent_joiners(days: int = 30, today=None) -> list:
    """People who joined in the last ``days`` days and are still employed, newest first."""
    from datetime import date, timedelta

    today = today or date.today()
    since = today - timedelta(days=days)
    people = (Recipient.query.filter(Recipient.date_of_joining >= since, Recipient.date_of_joining <= today)
              .order_by(Recipient.date_of_joining.desc(), Recipient.name).all())
    return [r for r in people if r.date_of_exit is None or r.date_of_exit > today]


WELCOME_LIMIT = 12


def welcome_prompt(joiners: list) -> str:
    """A welcome-newsletter prompt that already contains each joiner's details from their profile.

    Only directory details (name, role, team, office, joining date, manager) are used. They're shown in the prompt
    box, so the writer sees exactly what goes to the AI and can remove anyone before clicking Generate.
    """
    n = len(joiners)
    lines = []
    for r in joiners[:WELCOME_LIMIT]:
        bits = [r.designation, r.department and f"{r.department} team", r.location and f"based in {r.location}",
                r.date_of_joining and f"joined {r.date_of_joining:%d %b}",
                r.manager and r.manager.name and f"reports to {r.manager.name}"]
        lines.append(f"- {r.name or r.email.split('@')[0]}: " + ", ".join(b for b in bits if b))
    more = f"\n(and {n - WELCOME_LIMIT} more who joined in the same period)" if n > WELCOME_LIMIT else ""
    return (
        f"Welcome newsletter for all employees introducing the {n} {'person' if n == 1 else 'people'} who joined "
        "in the last 30 days:\n" + "\n".join(lines) + more + "\n\n"
        "Give each person a short, warm introduction using the details above. Add a fun fact only where one is given "
        "here: [optional fun facts]. Then a short 'Getting started' section with [onboarding links] and who to ask for "
        "help. Friendly and personal, under 300 words, one button to [onboarding page]."
    )

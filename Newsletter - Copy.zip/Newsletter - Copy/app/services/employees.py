"""Employee HR profiles: the field list shared by the profile view, CSV import and CSV export."""

from datetime import date, datetime

from ..security import csv_safe, csv_unescape

# (attribute, CSV column, label, kind). manager / hrbp are linked employees, written as their email in CSV.
PROFILE_FIELDS = [
    ("employee_code", "employee_id", "Employee ID", "text"),
    ("name", "name", "Name", "text"),
    ("email", "email", "Email", "text"),
    ("gender", "gender", "Gender", "text"),
    ("designation", "designation", "Designation", "text"),
    ("grade", "grade", "Grade", "text"),
    ("department", "department", "Department", "text"),
    ("business_unit", "business_unit", "Business unit", "text"),
    ("location", "location", "Location", "text"),
    ("employment_type", "employment_type", "Employment type", "text"),
    ("work_mode", "work_mode", "Work mode", "text"),
    ("cost_center", "cost_center", "Cost centre", "text"),
    ("manager", "manager_email", "Manager", "person"),
    ("hrbp", "hrbp_email", "HR business partner", "person"),
    ("date_of_joining", "date_of_joining", "Date of joining", "date"),
    ("date_of_resignation", "date_of_resignation", "Date of resignation", "date"),
    ("date_of_exit", "date_of_exit", "Date of exit", "date"),
    ("exit_type", "exit_type", "Exit type", "text"),
    ("exit_reason", "exit_reason", "Exit reason", "text"),
    ("regrettable", "regrettable", "Regrettable exit", "bool"),
    ("performance_rating", "performance_rating", "Performance rating", "int"),
    ("date_of_birth", "date_of_birth", "Date of birth", "date"),
    ("phone", "phone", "Phone", "text"),
]
TEXT_LIMITS = {"employee_code": 20, "gender": 20, "grade": 10, "employment_type": 30, "work_mode": 20,
               "cost_center": 30, "exit_type": 20, "phone": 30, "designation": 120, "business_unit": 120,
               "location": 120, "exit_reason": 120, "department": 120, "name": 255}
DATE_FORMATS = ("%Y-%m-%d", "%d-%m-%Y", "%d/%m/%Y", "%d-%b-%Y", "%d %b %Y", "%m/%d/%Y")


def parse_date(value):
    value = str(value or "").strip()
    if not value:
        return None
    for fmt in DATE_FORMATS:
        try:
            return datetime.strptime(value, fmt).date()
        except ValueError:
            continue
    raise ValueError(f"'{value}' isn't a date (use YYYY-MM-DD)")


def parse_bool(value):
    value = str(value or "").strip().lower()
    if not value:
        return None
    if value in {"1", "true", "yes", "y"}:
        return True
    if value in {"0", "false", "no", "n"}:
        return False
    raise ValueError(f"'{value}' isn't yes/no")


def parse_int(value, lo=1, hi=5):
    value = str(value or "").strip()
    if not value:
        return None
    number = int(float(value))
    if not lo <= number <= hi:
        raise ValueError(f"'{value}' must be {lo} to {hi}")
    return number


def fmt_value(value) -> str:
    if value is None:
        return ""
    if isinstance(value, bool):
        return "Yes" if value else "No"
    if isinstance(value, (date, datetime)):
        return value.strftime("%Y-%m-%d")
    return str(value)


def tenure(r, today: date | None = None) -> str:
    if not r.date_of_joining:
        return ""
    end = r.date_of_exit if r.date_of_exit and r.date_of_exit <= (today or date.today()) else (today or date.today())
    months = max(0, (end.year - r.date_of_joining.year) * 12 + end.month - r.date_of_joining.month)
    years, months = divmod(months, 12)
    return (f"{years} yr " if years else "") + f"{months} mo"


def profile_json(r, hidden: set | None = None) -> dict:
    """Profile fields for the profile dialog, as display strings (``hidden``: fields of spaces the viewer can't open)."""
    hidden = hidden or set()
    status = r.employment_status
    if status == "Serving notice" and "date_of_resignation" in hidden:
        status = "Active"
    out = {"id": r.id, "status": status, "newsletters": "Receives newsletters" if r.active else "Paused",
           "tenure": tenure(r), "fields": []}
    for attr, _col, label, kind in PROFILE_FIELDS:
        if attr in hidden:
            continue
        if kind == "person":
            person = getattr(r, attr)
            value = f"{person.name} ({person.designation or person.email})" if person else ""
        else:
            value = fmt_value(getattr(r, attr))
        out["fields"].append({"key": attr, "label": label, "value": value})
    reports = getattr(r, "_direct_reports", None)
    if reports is not None:
        out["direct_reports"] = reports
    return out


def export_header(hidden: set | None = None) -> list[str]:
    hidden = hidden or set()
    return [col for attr, col, _l, _k in PROFILE_FIELDS if attr not in hidden] + ["status", "receives_newsletters"]


def export_row(r, hidden: set | None = None) -> list[str]:
    hidden = hidden or set()
    row = []
    for attr, _col, _label, kind in PROFILE_FIELDS:
        if attr in hidden:
            continue
        if kind == "person":
            person = getattr(r, attr)
            row.append(person.email if person else "")
        else:
            row.append(fmt_value(getattr(r, attr)) if kind != "bool" else
                       ("" if getattr(r, attr) is None else ("yes" if getattr(r, attr) else "no")))
    status = r.employment_status
    if status == "Serving notice" and "date_of_resignation" in hidden:
        status = "Active"
    return [csv_safe(v) for v in row + [status, "yes" if r.active else "no"]]


EXPORT_HEADER = [col for _a, col, _l, _k in PROFILE_FIELDS] + ["status", "receives_newsletters"]


def apply_row(recipient, row: dict, fields: dict, people_by_email: dict, hidden: set | None = None) -> list[str]:
    """Copy the profile columns present in a CSV row onto an employee. Returns problems (bad values are skipped).

    ``hidden``: fields of spaces the importer can't open; those columns are ignored.
    """
    problems = []
    hidden = hidden or set()
    for attr, col, label, kind in PROFILE_FIELDS:
        if col in ("email",) or col not in fields or attr in hidden:
            continue
        raw = row.get(fields[col])
        if isinstance(raw, str):
            raw = csv_unescape(raw)
        try:
            if kind == "text":
                setattr(recipient, attr, (str(raw or "").strip()[: TEXT_LIMITS.get(attr, 120)] or
                                          ("" if attr in ("name", "department") else None)))
            elif kind == "date":
                setattr(recipient, attr, parse_date(raw))
            elif kind == "bool":
                setattr(recipient, attr, parse_bool(raw))
            elif kind == "int":
                setattr(recipient, attr, parse_int(raw))
            elif kind == "person":
                email = str(raw or "").strip().lower()
                setattr(recipient, attr, people_by_email.get(email) if email else None)
                if email and email not in people_by_email:
                    problems.append(f"{label} {email} isn't an employee")
        except ValueError as exc:
            problems.append(f"{label}: {exc}")
    return problems

"""Newsletter built from a space's data (DEI, Performance or Goals) — AI writer → Use your data.

Same idea as the Headcount & Attrition newsletter (services/hr_storyboard.py): the numbers come straight from the
space report (services/space_reports.py) with the dashboard filters, and the AI only writes the short summary.
Panels that list individual employees are never included, and only aggregates are sent to the AI.
"""

import os
from datetime import date

from flask import current_app

from ..spaces import SPACES
from .blocks import sanitize_content
from .space_reports import space_report


def _stat(card) -> dict:
    return {"value": card["display"], "label": card["label"], "note": card["note"], "delta": card["delta"],
            "trend": card["trend"], "good": card["good"]}


def _cards(report) -> list[dict]:
    return [c for g in report["groups"] for c in g["cards"]]


def facts_text(report: dict) -> str:
    """The report as plain text for the AI (aggregates only; private panels left out)."""
    name = SPACES[report["space"]]["name"]
    lines = [f"{name} data. Scope: {report['scope']}. {report['label']}. {report['population']:,} people employed in scope."]
    for g in report["groups"]:
        for c in g["cards"]:
            when = f" ({g['note']})" if g.get("note") else ""
            change = f"; change vs {report['compare_label']}: {c['delta']}" if c["delta"] and report.get("compare_label") else ""
            lines.append(f"- {c['label']}{when}: {c['display']}{change}. {c['note']}. Definition: {c['definition']}")
    for p in report["panels"]:
        if p.get("private"):
            continue
        if p["type"] in ("hbars", "donut"):
            items = p["items"]
            text = "; ".join(f"{x['label']} {x.get('display', x['value'])}" + (f" ({x['sub']})" if x.get("sub") else "")
                             for x in items[:15])
        elif p["type"] == "columns":
            keys = [s["key"] for s in p["series"]]
            text = "; ".join(f"{row['label']}: " + ", ".join(f"{s['label']} {row.get(s['key'], 0)}" for s in p["series"])
                             for row in p["rows"]) if len(keys) > 1 else "; ".join(f"{row.get('full', row['label'])} {row.get(keys[0], 0)}"
                                                                                 for row in p["rows"])
        else:  # table
            head = ", ".join(c["label"] for c in p["columns"])
            text = f"({head}) " + "; ".join(" | ".join(row) for row in p["rows"][:15])
        lines.append(f"{p['title']} — {p.get('sub', '')}: {text}")
    lines.append("Definitions: " + report["definitions"])
    return "\n".join(lines)


def rule_summary(report: dict) -> str:
    sentences = report["summary"][:4] or ["No numbers for this scope yet."]
    return f"<p><strong>{report['scope']}</strong>: " + " ".join(sentences) + "</p>"


def _panel_blocks(p: dict) -> list[dict]:
    d = lambda b: {**b, "from_data": True}  # noqa: E731 — data blocks stay unchanged in AI revisions
    if p["type"] == "donut":
        total = sum(x["value"] for x in p["items"]) or 1
        return [d({"type": "share", "title": p["title"], "subtitle": p.get("sub", ""),
                   "items": [{"label": x["label"], "value": x["value"],
                              "display": f"{x['value']:,} · {x['value'] / total * 100:.0f}%"} for x in p["items"] if x["value"]][:5]})]
    if p["type"] == "hbars":
        if not p["items"]:
            return []
        return [d({"type": "bars", "title": p["title"], "subtitle": p.get("sub", ""),
                   "items": [{"label": x["label"], "value": x["value"], "display": x["display"]} for x in p["items"][:20]]})]
    if p["type"] == "columns":
        series = p["series"]
        if len(series) == 1:
            key = series[0]["key"]
            return [d({"type": "bars", "title": p["title"], "subtitle": p.get("sub", ""),
                       "items": [{"label": r.get("full", r["label"]), "value": r.get(key, 0), "display": f"{r.get(key, 0):,}"}
                                 for r in p["rows"]]})]
        return [d({"type": "table", "title": p["title"], "subtitle": p.get("sub", ""),
                   "columns": [""] + [s["label"] for s in series][:5],
                   "rows": [[r["label"]] + [f"{r.get(s['key'], 0):,}" for s in series][:5] for r in p["rows"]], "bars": []})]
    # table: the first six columns, with a bar from one numeric column
    cols = [c["label"] for c in p["columns"]][:6]
    rows = [row[:6] for row in p["rows"][:30]]
    bars = []
    bc = p.get("bar_col")
    if bc is not None and bc < 6:
        vals = [s[bc] if isinstance(s[bc], (int, float)) else 0 for s in p["sort"][:30]]
        top = max(vals) if vals else 0
        bars = [(v or 0) / top for v in vals] if top else []
    return [d({"type": "table", "title": p["title"], "subtitle": p.get("sub", ""), "columns": cols, "rows": rows, "bars": bars})]


def build_space_newsletter(space: str, *, filters: dict | None = None, focus: str = "", theme: dict | None = None,
                           use_ai: bool = True) -> dict:
    cfg = current_app.config
    report = space_report(space, filters)
    if report.get("empty"):
        raise ValueError("There are no employee profiles yet. Import them on the Employees page first.")
    if report.get("notice"):
        raise ValueError(report["notice"])
    info = SPACES[space]
    cards = _cards(report)
    today = date.today()

    notice = ""
    summary = rule_summary(report)
    subject = f"{info['name']}: {cards[0]['label'].lower()} {cards[0]['display']}, {cards[1]['label'].lower()} {cards[1]['display']}"
    preheader = f"{report['scope']} · {report['label']}."
    ai_ready = bool(os.environ.get("ANTHROPIC_API_KEY") or os.environ.get("ANTHROPIC_AUTH_TOKEN"))
    if use_ai and ai_ready:
        from .ai import AIError, write_storyboard_insights

        try:
            out = write_storyboard_insights(facts_text(report), focus, kind=space)
            summary = out["html"] or summary
            subject = out["subject"] or subject
            preheader = out["preheader"] or preheader
        except AIError as exc:
            notice = f"The AI summary isn't available ({exc}), so the standard summary was used."
    elif use_ai:
        notice = "AI is off, so the summary is the standard one. Every number is still from your data."

    d = lambda b: {**b, "from_data": True}  # noqa: E731
    blocks = [
        {"type": "header", "eyebrow": report["scope"], "title": info["newsletter_title"], "subtitle": report["label"]},
        {"type": "insight", "label": "Executive insights", "html": summary},
        d({"type": "stats", "columns": 2, "align": "left", "size": "large", "items": [_stat(c) for c in cards[:2]]}),
    ]
    more = cards[2:10]
    if more:
        sub = f"Change is against {report['compare_label']}." if report.get("compare_label") else ""
        blocks.append(d({"type": "stats", "title": "Key metrics", "columns": 4, "align": "left", "subtitle": sub,
                         "items": [_stat(c) for c in more]}))
    for p in report["panels"]:
        if not p.get("private"):
            blocks.extend(_panel_blocks(p))
    base = cfg["PUBLIC_BASE_URL"].rstrip("/")
    blocks.append({"type": "button", "label": f"Open the {info['name']} dashboard →", "href": f"{base}/", "align": "center"})
    blocks.append({"type": "footer", "style": "dark", "html": (
        f"<p><strong>Data as of {today:%d %b %Y} · Source: employee profiles in Newsletter Studio</strong></p>"
        f"<p>{report['definitions']}</p>"
        f"<p>{cfg['COMPANY_NAME']} · People insights · Confidential, for internal distribution only.</p>")})
    content = sanitize_content({"theme": theme or {}, "blocks": blocks})
    return {"subject": subject[:255], "preheader": preheader[:255], "content": content, "notice": notice,
            "scope": report["scope"]}

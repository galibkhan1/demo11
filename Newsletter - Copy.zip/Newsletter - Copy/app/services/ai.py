"""Prompt -> newsletter generation with Claude.

Claude returns the newsletter as structured JSON (subject, preheader, theme color and a list of
typed blocks) constrained by ``NEWSLETTER_SCHEMA``, so the result drops straight into the
drag-and-drop editor where people can keep editing it.
"""

import html as html_lib
import json
import logging
import re

from flask import current_app

from .blocks import sanitize_content

log = logging.getLogger(__name__)


class AIError(Exception):
    """A user-presentable generation failure."""


def _obj(type_name: str, props: dict) -> dict:
    properties = {"type": {"type": "string", "const": type_name}, **props}
    return {
        "type": "object",
        "properties": properties,
        "required": list(properties),
        "additionalProperties": False,
    }


_STR = {"type": "string"}
_ALIGN = {"type": "string", "enum": ["left", "center", "right"]}
_HTML = {"type": "string", "description": "HTML using only <p>, <strong>, <em>, <u>, <a href>, <ul>, <ol>, <li>, <blockquote>, <br>."}

NEWSLETTER_SCHEMA = {
    "type": "object",
    "properties": {
        "subject": {"type": "string", "description": "Email subject line, under 70 characters."},
        "preheader": {"type": "string", "description": "Inbox preview text, under 110 characters."},
        "brand_color": {"type": "string", "description": "Accent color as #rrggbb that fits the topic."},
        "blocks": {
            "type": "array",
            "items": {
                "anyOf": [
                    _obj("header", {"title": _STR, "subtitle": _STR}),
                    _obj("heading", {"text": _STR, "level": {"type": "integer", "enum": [1, 2, 3]}, "align": _ALIGN}),
                    _obj("text", {"html": _HTML, "align": _ALIGN}),
                    _obj("image", {"src": {"type": "string", "description": "Image URL given by the user, else empty string."}, "alt": _STR}),
                    _obj("button", {"label": _STR, "href": {"type": "string", "description": "URL given by the user, else empty string."}, "align": _ALIGN}),
                    _obj("columns", {"left_html": _HTML, "right_html": _HTML}),
                    _obj("divider", {}),
                    _obj("spacer", {"height": {"type": "integer"}}),
                    _obj("footer", {"html": _HTML}),
                    _obj("stats", {"items": {
                        "type": "array",
                        "description": "1 to 4 key figures shown side by side as big numbers.",
                        "items": {
                            "type": "object",
                            "properties": {
                                "value": {"type": "string", "description": "The figure exactly as given, e.g. \"12%\", \"18\", \"4.7/5\". Max 12 characters."},
                                "label": {"type": "string", "description": "What it measures, 2 to 5 words."},
                                "note": {"type": "string", "description": "Optional short context such as \"up from 9% in Q2\", else empty string."},
                            },
                            "required": ["value", "label", "note"],
                            "additionalProperties": False,
                        },
                    }}),
                ]
            },
        },
    },
    "required": ["subject", "preheader", "brand_color", "blocks"],
    "additionalProperties": False,
}

SYSTEM_PROMPT = """You are the internal communications writer for {company}. You write email newsletters \
that employees actually read: warm, clear, specific, and skimmable.

You return the newsletter as structured blocks that are rendered into an email and then edited by a human \
in a visual editor.

Structure and style:
- Open with a "header" block (newsletter title plus a short subtitle such as the edition or date), and \
end with a "footer" block (a short sign-off and who to contact with questions).
- Use "heading" blocks (level 2) to introduce sections and "text" blocks for body copy. Keep paragraphs short. \
Use bullet lists where they help scanning. Use "divider" blocks between major sections and "columns" only \
for genuinely parallel short items (e.g. two quick updates side by side).
- When the request, the draft or the studio data contains important figures (results, milestones, counts, \
percentages), highlight the 2 to 4 most important ones in a "stats" block near the top, then explain them in the \
text. Keep each value short ("12%", "18", "4.7/5", "₹4.2 Cr"). Don't use a stats block when there are no real figures.
- The greeting may use the merge tag {{{{first_name}}}}, which is replaced with each employee's first name.
- Write in plain, human language. No corporate filler, no emoji unless the request asks for them.

Facts and links:
- Use only facts, names, numbers, dates and URLs that appear in the request, the current draft or the \
<studio_data> section. Never invent people, statistics, quotes, events or links, and never round, combine or \
recalculate numbers. Studio data are real figures from the newsletter studio; use them only where they fit the request. Where a specific detail is needed but was not \
given, write a short bracketed placeholder such as [date] or [team lead name] so the editor can spot and fill it.
- For "button" and "image" blocks, set href/src to a URL from the request, or to an empty string if none was \
given; the editor will fill it in. Only add an image block where an image clearly belongs.

When you are given a current draft and a revision instruction, apply the instruction and keep everything \
else as close to the current draft as possible."""


def _client():
    import anthropic  # imported lazily: the SDK is large and only needed when generating

    try:
        return anthropic.Anthropic()
    except anthropic.AnthropicError as exc:  # e.g. no API key configured
        raise AIError("AI is not configured: set ANTHROPIC_API_KEY in your .env file.") from exc


def _draft_for_prompt(subject: str, preheader: str, content: dict) -> str:
    """The current draft in the model's schema shape (ids and styling stripped)."""
    blocks = []
    for block in content.get("blocks", []):
        b = {k: v for k, v in block.items() if k not in {"id", "bg_color", "text_color", "color", "width"}}
        if b["type"] == "image":
            b.pop("href", None)
        blocks.append(b)
    return json.dumps({"subject": subject, "preheader": preheader, "blocks": blocks}, ensure_ascii=False, indent=1)


def _call(*, system: str, user_message: str, schema: dict, max_tokens: int = 16000) -> dict:
    """Send one structured-output request and return the parsed JSON object."""
    import anthropic

    cfg = current_app.config
    try:
        response = _client().beta.messages.create(
            model=cfg["AI_MODEL"],
            max_tokens=max_tokens,
            betas=["server-side-fallback-2026-07-01"],
            fallbacks="default",  # if the model declines, the API retries on Anthropic's recommended fallback
            system=system,
            messages=[{"role": "user", "content": user_message}],
            output_config={"effort": cfg["AI_EFFORT"], "format": {"type": "json_schema", "schema": schema}},
        )
    except anthropic.AuthenticationError as exc:
        raise AIError("The Anthropic API key was rejected. Check ANTHROPIC_API_KEY in .env.") from exc
    except anthropic.PermissionDeniedError as exc:
        raise AIError("The Anthropic API key does not have access to this model.") from exc
    except anthropic.RateLimitError as exc:
        raise AIError("The AI service is busy (rate limited). Try again in a minute.") from exc
    except anthropic.BadRequestError as exc:
        log.exception("AI bad request")
        raise AIError(f"The AI request was rejected: {exc.message}") from exc
    except anthropic.APIStatusError as exc:
        log.exception("AI API error")
        raise AIError(f"The AI service returned an error ({exc.status_code}). Try again shortly.") from exc
    except anthropic.APIConnectionError as exc:
        raise AIError("Could not reach the AI service. Check the server's internet connection.") from exc
    except TypeError as exc:  # raised by the SDK when no credentials are configured at all
        if "authentication" not in str(exc).lower():
            raise
        raise AIError("AI is not configured: set ANTHROPIC_API_KEY in your .env file.") from exc

    if response.stop_reason == "refusal":
        raise AIError("The AI declined this request. Try rephrasing it.")
    if response.stop_reason == "max_tokens":
        raise AIError("The response came out too long. Ask for something shorter.")

    text = next((block.text for block in response.content if block.type == "text"), None)
    try:
        data = json.loads(text or "")
    except json.JSONDecodeError as exc:
        log.error("AI returned non-JSON output (request %s)", getattr(response, "_request_id", "?"))
        raise AIError("The AI returned an unexpected response. Please try again.") from exc
    if not isinstance(data, dict):
        raise AIError("The AI returned an unexpected response. Please try again.")
    return data


def generate_newsletter(
    prompt: str, *, current: dict | None = None, theme: dict | None = None, studio_data: str | None = None
) -> dict:
    """Generate (or, when ``current`` is given, revise) a newsletter from a natural-language prompt.

    ``current`` is ``{"subject", "preheader", "content"}``. ``studio_data`` is optional plain text with real
    figures from the studio (see ``insights.studio_data_text``). Returns the same shape as ``current``.
    """
    prompt = (prompt or "").strip()
    if not prompt:
        raise AIError("Describe the newsletter you want first.")

    revising = bool(current and current.get("content", {}).get("blocks"))
    kept = []  # data blocks (charts, tables, KPI cards built from the studio's numbers) are never rewritten
    if revising:
        all_blocks = current["content"]["blocks"]
        kept = [(i, b) for i, b in enumerate(all_blocks) if b.get("from_data")]
        editable = {**current["content"], "blocks": [b for b in all_blocks if not b.get("from_data")]}
        user_message = (
            "Here is the current newsletter draft:\n<draft>\n"
            + _draft_for_prompt(current.get("subject", ""), current.get("preheader", ""), editable)
            + "\n</draft>\n\nRevise it according to this instruction:\n<instruction>\n"
            + prompt
            + "\n</instruction>"
            + ("\n\nThe newsletter also contains charts, tables and KPI cards built from live data. They stay exactly "
               "as they are and aren't shown here, so don't add blocks that repeat or replace them." if kept else "")
        )
    else:
        user_message = "Write a newsletter based on this request:\n<request>\n" + prompt + "\n</request>"
    if studio_data:
        user_message += (
            "\n\nReal figures from the newsletter studio, accurate as of today. Use the ones that fit the "
            "request:\n<studio_data>\n" + studio_data + "\n</studio_data>"
        )

    cfg = current_app.config
    data = _call(
        system=SYSTEM_PROMPT.format(company=cfg["COMPANY_NAME"]),
        user_message=user_message,
        schema=NEWSLETTER_SCHEMA,
    )

    # Keep the editor's existing theme; a fresh draft also adopts the model's suggested accent color.
    theme = dict(theme or {})
    if not revising:
        theme["brand_color"] = data.get("brand_color") or theme.get("brand_color")
    new_blocks = [b for b in data.get("blocks", []) if isinstance(b, dict)]
    for index, block in kept:  # put the data blocks back where they were
        new_blocks.insert(min(index, len(new_blocks)), block)
    content = sanitize_content({"theme": theme, "blocks": new_blocks})
    return {
        "subject": str(data.get("subject", ""))[:255],
        "preheader": str(data.get("preheader", ""))[:255],
        "content": content,
    }


IDEAS_PROMPT = """You are the internal communications strategist for {company}. Using the engagement data you are \
given, suggest ideas for the next employee newsletters.

For each idea:
- title: a short working title, at most 60 characters.
- why: one or two sentences that cite specific numbers from the data (open rates, clicks, departments, timing) \
explaining why this idea should work now.
- subject: a subject line under 55 characters. It may use {{{{first_name}}}}.
- prompt: a brief for the newsletter writer, 2 to 4 sentences: what to cover, tone and length. Facts the \
communications team still has to supply go in [square brackets], for example [launch date].
- departments: an empty list to send to everyone, or the departments a targeted version should go to.

Rules:
- Ground every idea in the data. Never invent company events, results, people or numbers that aren't in it; \
leave them as [bracketed] gaps in the prompt instead.
- Learn from what worked: reuse the formats, subjects and links that got the most opens and clicks.
- Don't repeat a topic sent in the last 30 days or already drafted, unless the data shows strong interest.
- Include at least one idea for everyone and, if some departments open much less than others, one targeted at them."""


def suggest_topics(context: str, departments: list[str], count: int = 4) -> list[dict]:
    """Newsletter ideas grounded in the studio's engagement data (``insights.ideas_context``)."""
    dept_items = {"type": "string", "enum": departments} if departments else {"type": "string"}
    schema = {
        "type": "object",
        "properties": {
            "ideas": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "title": _STR, "why": _STR, "subject": _STR, "prompt": _STR,
                        "departments": {"type": "array", "items": dept_items},
                    },
                    "required": ["title", "why", "subject", "prompt", "departments"],
                    "additionalProperties": False,
                },
            }
        },
        "required": ["ideas"],
        "additionalProperties": False,
    }
    cfg = current_app.config
    data = _call(
        system=IDEAS_PROMPT.format(company=cfg["COMPANY_NAME"]),
        user_message=f"<engagement_data>\n{context}\n</engagement_data>\n\nSuggest {count} newsletter ideas.",
        schema=schema,
        max_tokens=8000,
    )
    ideas = []
    known = set(departments)
    for raw in data.get("ideas", [])[:6]:
        if not isinstance(raw, dict) or not str(raw.get("title", "")).strip():
            continue
        ideas.append({
            "title": str(raw.get("title", "")).strip()[:80],
            "why": str(raw.get("why", "")).strip()[:500],
            "subject": str(raw.get("subject", "")).strip()[:120],
            "prompt": str(raw.get("prompt", "")).strip()[:2000],
            "departments": [d for d in raw.get("departments") or [] if d in known],
        })
    if not ideas:
        raise AIError("The AI didn't return any ideas. Try again.")
    return ideas


STORYBOARD_PROMPT = """You write the executive summary at the top of {company}'s internal "Engagement Newsletter", \
a data newsletter about how employees read internal newsletters.

You get the period's numbers. Write one or two short paragraphs, 70 to 120 words in total, that a busy manager \
can read in 20 seconds: the headline result, the biggest change against the previous period (if there is one), \
which teams read most and least, and one practical implication.

Rules:
- Use only numbers that appear in the data, written exactly as given. Don't calculate new numbers, round them \
or invent comparisons. Don't present guesses about causes as facts.
- Put **double asterisks** around at most two key numbers.
- Plain, direct sentences. No greeting, no sign-off, no hype words.
- If the request includes a focus, address it first.
Also write a subject line under 60 characters that leads with the key number, and inbox preview text under \
100 characters."""

HR_STORYBOARD_PROMPT = """You write the executive summary at the top of {company}'s "Headcount & Attrition Newsletter", an internal HR data newsletter for leaders.

You get the numbers for one scope (the whole company, a business unit, a department or one leader's org) and one period. Write one or two short paragraphs, 70 to 130 words in total, that a busy leader can read in 20 seconds: closing headcount and retention, overall attrition and its voluntary / involuntary split, the biggest change against the comparison period, which departments have the highest and lowest attrition, and one practical implication (for example where to focus retention).

Rules:
- Use only numbers that appear in the data, written exactly as given. Don't calculate new numbers, round them or invent comparisons. Don't present guesses about causes as facts; exit reasons are recorded reasons, not proof.
- Don't name individual employees (the leader named in the scope is fine).
- Put **double asterisks** around at most two key numbers.
- Plain, direct sentences. No greeting, no sign-off, no hype words.
- If the request includes a focus, address it first.
Also write a subject line under 60 characters that leads with the key number, and inbox preview text under 100 characters."""

SPACE_PROMPT = """You write the executive summary at the top of {company}'s "{title}", an internal data newsletter about {about}.

You get the numbers for one scope (the whole company, a business unit, a department or one leader's org). Write one or two short paragraphs, 70 to 130 words in total, that a busy leader can read in 20 seconds: {cover}, and one practical implication.

Rules:
- Use only numbers that appear in the data, written exactly as given. Don't calculate new numbers, round them or invent comparisons. Don't present guesses about causes as facts.
- Don't name or describe individual employees (the leader named in the scope is fine). {extra}
- Put **double asterisks** around at most two key numbers.
- Plain, direct sentences. No greeting, no sign-off, no hype words.
- If the request includes a focus, address it first.
Also write a subject line under 60 characters that leads with the key number, and inbox preview text under 100 characters."""

SPACE_AI = {
    "dei": {"title": "DEI Newsletter", "about": "diversity, equity and inclusion in the workforce",
            "cover": "the share of women overall and in leadership, how hiring and attrition compare for women and men, and which levels or teams are least balanced",
            "extra": "Report gender and age as recorded, respectfully and without stereotypes."},
    "performance": {"title": "Performance Newsletter", "about": "performance ratings",
                    "cover": "the rating spread, which teams rate highest and lowest, and how attrition compares for high and low performers",
                    "extra": "Never single out a person, and don't imply that a team's rating says anything about any one member."},
    "goals": {"title": "Goals Newsletter", "about": "progress on this cycle's goals",
              "cover": "overall progress and completion, the share of goals at risk or behind, overdue goals, and which teams are furthest ahead and behind",
              "extra": ""},
}

STORYBOARD_SCHEMA = {
    "type": "object",
    "properties": {
        "subject": _STR,
        "preheader": _STR,
        "paragraphs": {"type": "array", "items": _STR, "description": "One or two paragraphs."},
    },
    "required": ["subject", "preheader", "paragraphs"],
    "additionalProperties": False,
}


def write_storyboard_insights(facts: str, focus: str = "", kind: str = "engagement") -> dict:
    """AI-written summary for a newsletter built from data (kind "engagement", "hr", "dei", "performance" or "goals").

    Returns {"subject", "preheader", "html"}."""
    cfg = current_app.config
    message = "<data>\n" + facts + "\n</data>"
    if focus.strip():
        message += "\n\n<focus>\n" + focus.strip()[:1000] + "\n</focus>"
    data = _call(
        system=(SPACE_PROMPT.format(company=cfg["COMPANY_NAME"], **SPACE_AI[kind]) if kind in SPACE_AI else
                (HR_STORYBOARD_PROMPT if kind == "hr" else STORYBOARD_PROMPT).format(company=cfg["COMPANY_NAME"])),
        user_message=message,
        schema=STORYBOARD_SCHEMA,
        max_tokens=4000,
    )
    paragraphs = [str(p).strip() for p in data.get("paragraphs", []) if str(p).strip()][:3]
    html = "".join(
        "<p>" + re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", html_lib.escape(p)) + "</p>" for p in paragraphs
    )
    return {
        "subject": str(data.get("subject", "")).strip()[:255],
        "preheader": str(data.get("preheader", "")).strip()[:255],
        "html": html,
    }

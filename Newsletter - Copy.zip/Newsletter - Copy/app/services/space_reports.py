"""Numbers for the DEI, Performance and Goals spaces (Headcount & Attrition uses services/workforce.py).

Each report uses the dashboard filters (leader's org, business unit, department, location, gender, grade band,
employment type) and returns the same shape, so one dashboard page and one newsletter builder serve every space:

    groups  — KPI cards in titled groups (same card format as the workforce dashboard)
    panels  — charts and tables: donut, hbars, columns or table
    summary — plain sentences with the key numbers (standard newsletter summary and AI facts)

Panels marked ``private`` list individual employees: they appear on the dashboard only, never in a newsletter or
in anything sent to the AI.
"""

from datetime import date
from statistics import median

from .workforce import (FILTER_KEYS, GRADE_BANDS, _cached, _card, _employed, _fy_label, _fy_start, _measure,
                        _minus_year, _profiles, options, select_people)

GENDERS = ("Female", "Male", "Non-binary")
RATING_LABELS = {1: "1 · Needs improvement", 2: "2 · Partly meets", 3: "3 · Meets", 4: "4 · Exceeds", 5: "5 · Outstanding"}
TENURE_BANDS = (("Under 1 year", 0, 1), ("1–2 years", 1, 2), ("2–3 years", 2, 3), ("3–5 years", 3, 5), ("5+ years", 5, 99))
AGE_BANDS = (("Under 25", 0, 25), ("25–34", 25, 35), ("35–44", 35, 45), ("45–54", 45, 55), ("55+", 55, 200))
STATUS_ORDER = ("Completed", "On track", "At risk", "Behind", "Not started")


def pct(x) -> str:
    return "–" if x is None else f"{x * 100:.1f}%"


def share(n, d):
    return n / d if d else None


def _age(r, on: date):
    b = r.date_of_birth
    if not b:
        return None
    return on.year - b.year - ((on.month, on.day) < (b.month, b.day))


def _years(r, on: date) -> float:
    return (on - r.date_of_joining).days / 365.25


def _group_by(items, key):
    out = {}
    for it in items:
        k = key(it)
        if k:
            out.setdefault(k, []).append(it)
    return out


def _band(grade):
    return next((label for label, grades in GRADE_BANDS.values() if grade in grades), None)


def _plain(key, label, display, note="", definition="", link=None):
    return {"key": key, "label": label, "display": display, "note": note, "definition": definition,
            "delta": "", "trend": "", "good": None, "link": link}


def _hbar(label, value, display, sub=""):
    return {"label": label, "value": round(value or 0, 4), "display": display, "sub": sub}


def _table(columns, rows, sortvals, bar_col=None):
    """columns: [(label, numeric?)]; rows: display strings; sortvals: raw values for sorting."""
    return {"columns": [{"label": c, "num": num} for c, num in columns], "rows": rows, "sort": sortvals,
            "bar_col": bar_col}


def space_report(space: str, filters: dict | None = None, today: date | None = None) -> dict:
    today = today or date.today()
    filters = {k: str((filters or {}).get(k) or "") for k in FILTER_KEYS}
    fn = {"dei": _dei, "performance": _performance, "goals": _goals}[space]
    return _cached(("space", space, tuple(sorted(filters.items())), today), lambda: fn(filters, today))


def _base(space, filters, today):
    everyone = _profiles()
    if not everyone:
        return None
    people, scope, _leader = select_people(filters, everyone)
    current = [r for r in people if _employed(r, today)]
    return {"everyone": everyone, "people": people, "scope": scope, "current": current,
            "out": {"empty": False, "space": space, "filters": filters, "scope": scope, "population": len(current),
                    "options": options(everyone), "as_of": f"{today:%d %b %Y}", "notice": ""}}


# --------------------------------------------------------------------------------------------- DEI
def _dei(filters, today):
    base = _base("dei", filters, today)
    if not base:
        return {"empty": True, "space": "dei"}
    people, cur = base["people"], base["current"]
    fy, prev_today = _fy_start(today), _minus_year(today)
    prev_fy = _minus_year(fy)
    prev = [r for r in people if _employed(r, prev_today)]

    def women(rs):
        return share(sum(1 for r in rs if r.gender == "Female"), len(rs))

    def band(rs, key):
        return [r for r in rs if r.grade in GRADE_BANDS[key][1]]

    def joined(start, end):
        return [r for r in people if start <= r.date_of_joining <= end]

    def left(start, end):
        return [r for r in people if r.date_of_exit and start <= r.date_of_exit <= end]

    def attrition(gender, start, end):
        return _measure([r for r in people if r.gender == gender], start, end)["attrition"]

    ages = [a for a in (_age(r, today) for r in cur) if a is not None]
    prev_ages = [a for a in (_age(r, prev_today) for r in prev) if a is not None]
    med, prev_med = (median(ages) if ages else None), (median(prev_ages) if prev_ages else None)
    under30 = share(sum(1 for a in ages if a < 30), len(ages))
    over50 = share(sum(1 for a in ages if a >= 50), len(ages))
    j, pj = joined(fy, today), joined(prev_fy, prev_today)
    lv, plv = left(fy, today), left(prev_fy, prev_today)
    att_f, att_m = attrition("Female", fy, today), attrition("Male", fy, today)
    p_att_f, p_att_m = attrition("Female", prev_fy, prev_today), attrition("Male", prev_fy, prev_today)
    lead, mgr = band(cur, "leader"), band(cur, "manager")
    nb = sum(1 for r in cur if r.gender == "Non-binary")
    period = f"{_fy_label(fy)} to date"
    women_n = sum(1 for r in cur if r.gender == "Female")

    groups = [
        {"title": "Gender balance", "icon": "users", "cards": [
            _card("female", "Women in workforce", women(cur), pct(women(cur)), women(prev), "pct", "up",
                  f"{women_n:,} of {len(cur):,} employees", "Women as a share of people employed today."),
            _card("leaders", "Women in leadership", women(lead), pct(women(lead)), women(band(prev, "leader")), "pct", "up",
                  f"{sum(1 for r in lead if r.gender == 'Female')} of {len(lead)} in G10+", "Women as a share of grades G10 and above."),
            _card("managers", "Women managers", women(mgr), pct(women(mgr)), women(band(prev, "manager")), "pct", "up",
                  f"{sum(1 for r in mgr if r.gender == 'Female')} of {len(mgr)} at G8", "Women as a share of grade G8 (people managers)."),
            _card("nonbinary", "Non-binary employees", nb, f"{nb:,}", sum(1 for r in prev if r.gender == "Non-binary"), "count", None,
                  "employed today", "People employed today whose gender is recorded as non-binary."),
        ]},
        {"title": "Hiring & attrition", "icon": "trending-down", "note": period, "cards": [
            _card("joiners_f", "Women among joiners", women(j), pct(women(j)), women(pj), "pct", "up",
                  f"{sum(1 for r in j if r.gender == 'Female')} of {len(j)} joiners", "Share of this financial year's joiners who are women."),
            _card("leavers_f", "Women among leavers", women(lv), pct(women(lv)), women(plv), "pct", "down",
                  f"{sum(1 for r in lv if r.gender == 'Female')} of {len(lv)} leavers", "Share of this financial year's leavers who are women."),
            _card("att_f", "Female attrition", att_f, pct(att_f), p_att_f, "pct", "down", "annualised",
                  "Women who left ÷ average number of women employed, annualised."),
            _card("att_m", "Male attrition", att_m, pct(att_m), p_att_m, "pct", "down", "annualised",
                  "Men who left ÷ average number of men employed, annualised."),
        ]},
        {"title": "Age", "icon": "calendar", "cards": [
            _card("median_age", "Median age", med, "–" if med is None else f"{med:.0f} yrs", prev_med, "years", None,
                  "of people employed today", "Middle age of people employed today (from date of birth)."),
            _card("under30", "Under 30", under30, pct(under30), share(sum(1 for a in prev_ages if a < 30), len(prev_ages)), "pct", None,
                  f"{sum(1 for a in ages if a < 30)} people", "Share of people employed today who are under 30."),
            _card("over50", "50 and over", over50, pct(over50), share(sum(1 for a in prev_ages if a >= 50), len(prev_ages)), "pct", None,
                  f"{sum(1 for a in ages if a >= 50)} people", "Share of people employed today who are 50 or older."),
        ]},
    ]

    gender_counts = [{"label": g, "value": sum(1 for r in cur if r.gender == g)} for g in GENDERS]
    by_band = [(label, band(cur, key)) for key, (label, _g) in GRADE_BANDS.items()]
    depts = _group_by(cur, lambda r: r.department)
    locs = _group_by(cur, lambda r: r.location)
    age_rows = [{"label": label, "value": sum(1 for a in ages if lo <= a < hi)} for label, lo, hi in AGE_BANDS]
    flow = [{"label": "Joiners", **{g: sum(1 for r in j if r.gender == g) for g in GENDERS}},
            {"label": "Leavers", **{g: sum(1 for r in lv if r.gender == g) for g in GENDERS}}]

    dept_rows, dept_sort = [], []
    for name in sorted(depts, key=lambda d: -len(depts[d])):
        staff = depts[name]
        everyone_in = [r for r in people if r.department == name]
        af = _measure([r for r in everyone_in if r.gender == "Female"], fy, today)["attrition"]
        am = _measure([r for r in everyone_in if r.gender == "Male"], fy, today)["attrition"]
        senior = [r for r in staff if r.grade in GRADE_BANDS["manager"][1] | GRADE_BANDS["leader"][1]]
        a = [x for x in (_age(r, today) for r in staff) if x is not None]
        vals = [len(staff), women(staff), women(senior), af, am, median(a) if a else None]
        dept_rows.append([name, f"{len(staff):,}", pct(vals[1]), pct(vals[2]), pct(af), pct(am),
                          "–" if vals[5] is None else f"{vals[5]:.0f}"])
        dept_sort.append([name] + vals)

    panels = [
        {"id": "gender", "type": "donut", "size": "narrow", "title": "Gender split", "sub": "People employed today",
         "items": gender_counts, "center": "employees"},
        {"id": "bands", "type": "hbars", "size": "wide", "title": "Women by level", "sub": "Share of women in each grade band",
         "items": [_hbar(label, (women(rs) or 0) * 100, pct(women(rs)), f"{sum(1 for r in rs if r.gender == 'Female')} of {len(rs)}")
                   for label, rs in by_band if rs]},
        {"id": "dept", "type": "hbars", "size": "half", "title": "Women by department", "sub": "Share of women in each team",
         "items": [_hbar(n, (women(rs) or 0) * 100, pct(women(rs)), f"{sum(1 for r in rs if r.gender == 'Female')} of {len(rs)}")
                   for n, rs in sorted(depts.items(), key=lambda kv: -(women(kv[1]) or 0))]},
        {"id": "loc", "type": "hbars", "size": "half", "title": "Women by location", "sub": "Share of women in each office",
         "items": [_hbar(n, (women(rs) or 0) * 100, pct(women(rs)), f"{sum(1 for r in rs if r.gender == 'Female')} of {len(rs)}")
                   for n, rs in sorted(locs.items(), key=lambda kv: -(women(kv[1]) or 0))]},
        {"id": "flow", "type": "columns", "size": "wide", "title": "Joiners and leavers by gender", "sub": period,
         "rows": flow, "series": [{"key": g, "label": g} for g in GENDERS]},
        {"id": "age", "type": "hbars", "size": "narrow", "title": "Age groups", "sub": "People employed today",
         "items": [_hbar(x["label"], x["value"], f"{x['value']:,}") for x in age_rows]},
        {"id": "dept_table", "type": "table", "size": "full", "title": "By department",
         "sub": f"People employed today; attrition is annualised for {period}. Senior = G8 and above.",
         **_table([("Department", False), ("Headcount", True), ("Women", True), ("Women in senior roles", True),
                   ("Female attrition", True), ("Male attrition", True), ("Median age", True)], dept_rows, dept_sort, bar_col=2)},
    ]

    summary = [f"Women are {pct(women(cur))} of the {len(cur):,} people employed today"
               + (f" ({groups[0]['cards'][0]['delta']} on a year ago)." if groups[0]["cards"][0]["delta"] else ".")]
    if lead:
        summary.append(f"Women hold {pct(women(lead))} of leadership roles (G10 and above) and {pct(women(mgr))} of manager roles (G8).")
    if j:
        summary.append(f"This financial year, {pct(women(j))} of joiners and {pct(women(lv))} of leavers were women.")
    if att_f is not None and att_m is not None:
        summary.append(f"Annualised attrition is {pct(att_f)} for women and {pct(att_m)} for men.")
    ranked = [(n, women(rs)) for n, rs in depts.items() if len(rs) >= 8]
    if len(ranked) >= 2:
        hi, lo = max(ranked, key=lambda x: x[1]), min(ranked, key=lambda x: x[1])
        summary.append(f"{hi[0]} has the highest share of women ({pct(hi[1])}) and {lo[0]} the lowest ({pct(lo[1])}).")
    if med is not None:
        summary.append(f"The median age is {med:.0f}; {pct(under30)} are under 30 and {pct(over50)} are 50 or older.")

    return {**base["out"], "label": f"As of {today:%d %b %Y}", "compare_label": "a year ago",
            "groups": groups, "panels": panels, "summary": summary,
            "definitions": ("Shares use people employed on the date shown. Senior roles = grades G8 and above; leadership = "
                            "G10 and above. Hiring and attrition cover the financial year to date (April to March); attrition "
                            "is annualised. Changes compare with the same date a year earlier.")}


# --------------------------------------------------------------------------------------------- Performance
def _performance(filters, today):
    base = _base("performance", filters, today)
    if not base:
        return {"empty": True, "space": "performance"}
    people, cur = base["people"], base["current"]
    fy = _fy_start(today)
    period = f"{_fy_label(fy)} to date"
    rated = [r for r in cur if r.performance_rating]

    def avg(rs):
        vals = [r.performance_rating for r in rs if r.performance_rating]
        return sum(vals) / len(vals) if vals else None

    def high(rs):
        return [r for r in rs if (r.performance_rating or 0) >= 4]

    def low(rs):
        return [r for r in rs if r.performance_rating and r.performance_rating <= 2]

    exits = [r for r in people if r.date_of_exit and fy <= r.date_of_exit <= today]
    high_all = [r for r in people if (r.performance_rating or 0) >= 4]
    low_all = [r for r in people if r.performance_rating and r.performance_rating <= 2]
    high_att = _measure(high_all, fy, today)["attrition"]
    low_att = _measure(low_all, fy, today)["attrition"]
    high_notice = [r for r in high(cur) if r.date_of_resignation and r.date_of_resignation <= today]
    leaver_avg = avg(exits)
    a = avg(rated)

    groups = [
        {"title": "Ratings", "icon": "chart", "note": "people employed today", "cards": [
            _plain("avg", "Average rating", "–" if a is None else f"{a:.2f} / 5", f"{len(rated):,} rated",
                   "Average of current ratings on a 1 to 5 scale."),
            _plain("high", "High performers", pct(share(len(high(rated)), len(rated))), f"{len(high(rated)):,} rated 4 or 5",
                   "Share of rated employees with a rating of 4 (exceeds) or 5 (outstanding)."),
            _plain("solid", "Meeting expectations", pct(share(sum(1 for r in rated if r.performance_rating == 3), len(rated))),
                   f"{sum(1 for r in rated if r.performance_rating == 3):,} rated 3", "Share of rated employees with a rating of 3."),
            _plain("low", "Low performers", pct(share(len(low(rated)), len(rated))), f"{len(low(rated)):,} rated 1 or 2",
                   "Share of rated employees with a rating of 1 or 2."),
        ]},
        {"title": "Performance & attrition", "icon": "trending-down", "note": period, "cards": [
            _plain("high_att", "High-performer attrition", pct(high_att), "annualised",
                   "Leavers rated 4 or 5 ÷ average number of people rated 4 or 5, annualised."),
            _plain("low_att", "Low-performer attrition", pct(low_att), "annualised",
                   "Leavers rated 1 or 2 ÷ average number of people rated 1 or 2, annualised."),
            _plain("high_notice", "High performers on notice", f"{len(high_notice):,}", "resigned, not yet left",
                   "People rated 4 or 5 who have resigned and haven't reached their last day."),
            _plain("leaver_avg", "Leavers' average rating", "–" if leaver_avg is None else f"{leaver_avg:.2f} / 5",
                   f"{len(exits)} leavers", "Average rating of people who left this financial year."),
        ]},
    ]

    dist = [{"label": str(k), "full": RATING_LABELS[k], "count": sum(1 for r in rated if r.performance_rating == k)} for k in range(1, 6)]
    bands = [{"label": "High (4–5)", "value": len(high(rated))},
             {"label": "Meets (3)", "value": sum(1 for r in rated if r.performance_rating == 3)},
             {"label": "Low (1–2)", "value": len(low(rated))}]
    depts = _group_by(rated, lambda r: r.department)
    by_band = [(label, [r for r in rated if r.grade in grades]) for label, grades in GRADE_BANDS.values()]
    by_tenure = [(label, [r for r in rated if lo <= _years(r, today) < hi]) for label, lo, hi in TENURE_BANDS]
    leavers = [{"label": RATING_LABELS[k], "value": sum(1 for r in exits if r.performance_rating == k)} for k in range(5, 0, -1)]

    def hb(label, rs):
        v = avg(rs)
        return _hbar(label, v or 0, "–" if v is None else f"{v:.2f}", f"{pct(share(len(high(rs)), len(rs)))} high")

    dept_rows, dept_sort = [], []
    for name in sorted(depts, key=lambda d: -(avg(depts[d]) or 0)):
        rs = depts[name]
        ex = [r for r in exits if r.department == name and (r.performance_rating or 0) >= 4]
        hp_att = _measure([r for r in high_all if r.department == name], fy, today)["attrition"]
        vals = [len(rs), avg(rs), share(len(high(rs)), len(rs)), share(len(low(rs)), len(rs)), len(ex), hp_att]
        dept_rows.append([name, f"{len(rs):,}", f"{vals[1]:.2f}", pct(vals[2]), pct(vals[3]), f"{len(ex)}", pct(hp_att)])
        dept_sort.append([name] + vals)

    panels = [
        {"id": "dist", "type": "columns", "size": "wide", "title": "Rating distribution", "sub": "People employed today, by rating",
         "rows": dist, "series": [{"key": "count", "label": "Employees"}]},
        {"id": "bands", "type": "donut", "size": "narrow", "title": "Rating bands", "sub": "Share of rated employees",
         "items": bands, "center": "rated"},
        {"id": "dept", "type": "hbars", "size": "half", "title": "Average rating by department", "sub": "1 to 5 scale · share rated 4 or 5",
         "items": [hb(n, rs) for n, rs in sorted(depts.items(), key=lambda kv: -(avg(kv[1]) or 0))]},
        {"id": "grade", "type": "hbars", "size": "half", "title": "Average rating by level", "sub": "Grade bands",
         "items": [hb(label, rs) for label, rs in by_band if rs]},
        {"id": "tenure", "type": "hbars", "size": "half", "title": "Average rating by tenure", "sub": "Time since joining",
         "items": [hb(label, rs) for label, rs in by_tenure if rs]},
        {"id": "leavers", "type": "hbars", "size": "half", "title": "Leavers by rating", "sub": f"{len(exits)} leavers, {period}",
         "items": [_hbar(x["label"], x["value"], str(x["value"])) for x in leavers]},
        {"id": "dept_table", "type": "table", "size": "full", "title": "By department",
         "sub": f"Rated employees today; exits and attrition for {period}.",
         **_table([("Department", False), ("Rated", True), ("Average rating", True), ("High (4–5)", True), ("Low (1–2)", True),
                   ("High performers who left", True), ("High-performer attrition", True)], dept_rows, dept_sort, bar_col=2)},
    ]

    summary = []
    if a is not None:
        summary.append(f"The average rating is {a:.2f} out of 5 across {len(rated):,} rated employees; "
                       f"{pct(share(len(high(rated)), len(rated)))} are rated 4 or 5 and {pct(share(len(low(rated)), len(rated)))} are rated 1 or 2.")
    ranked = [(n, avg(rs)) for n, rs in depts.items() if len(rs) >= 8]
    if len(ranked) >= 2:
        hi, lo = max(ranked, key=lambda x: x[1]), min(ranked, key=lambda x: x[1])
        summary.append(f"{hi[0]} has the highest average rating ({hi[1]:.2f}) and {lo[0]} the lowest ({lo[1]:.2f}).")
    summary.append(f"This financial year, annualised attrition is {pct(high_att)} among high performers and {pct(low_att)} among low performers.")
    if high_notice:
        summary.append(f"{len(high_notice)} high performers are serving notice.")

    return {**base["out"], "label": f"As of {today:%d %b %Y}", "compare_label": "",
            "groups": groups, "panels": panels, "summary": summary,
            "definitions": ("Ratings are each person's current rating on a 1 to 5 scale (5 = outstanding). High performers are "
                            "rated 4 or 5; low performers 1 or 2. Attrition covers the financial year to date and is annualised.")}


# --------------------------------------------------------------------------------------------- Goals
def _goals(filters, today):
    from ..models import Goal

    base = _base("goals", filters, today)
    if not base:
        return {"empty": True, "space": "goals"}
    cur = base["current"]
    fy = _fy_start(today)
    cycle = _fy_label(fy)
    by_id = {r.id: r for r in cur}
    goals = Goal.query.filter(Goal.cycle == cycle).all() if by_id else []
    goals = [g for g in goals if g.recipient_id in by_id]
    n = len(goals)

    def count(status, gs=None):
        return sum(1 for g in (goals if gs is None else gs) if g.status == status)

    def overdue(gs):
        return [g for g in gs if g.due_date and g.due_date < today and g.status != "Completed"]

    def avg_progress(gs):
        return sum(g.progress for g in gs) / len(gs) / 100 if gs else None

    owners = {g.recipient_id for g in goals}
    q_end = next(d for d in (date(fy.year, 6, 30), date(fy.year, 9, 30), date(fy.year, 12, 31), date(fy.year + 1, 3, 31)) if d >= today) \
        if today <= date(fy.year + 1, 3, 31) else today
    due_q = [g for g in goals if g.due_date and today <= g.due_date <= q_end and g.status != "Completed"]

    groups = [
        {"title": "Progress", "icon": "target", "note": cycle, "cards": [
            _plain("total", "Goals", f"{n:,}", f"for {len(owners):,} people", f"Goals set for {cycle}."),
            _plain("avg_progress", "Average progress", pct(avg_progress(goals)), "across all goals", "Average progress of every goal (0 to 100%)."),
            _plain("completed", "Completed", pct(share(count("Completed"), n)), f"{count('Completed'):,} goals", "Share of goals marked completed."),
            _plain("on_track", "On track", pct(share(count("On track"), n)), f"{count('On track'):,} goals", "Share of goals marked on track."),
        ]},
        {"title": "Needs attention", "icon": "alert", "cards": [
            _plain("at_risk", "At risk", pct(share(count("At risk"), n)), f"{count('At risk'):,} goals", "Share of goals marked at risk."),
            _plain("behind", "Behind", pct(share(count("Behind"), n)), f"{count('Behind'):,} goals", "Share of goals marked behind (includes overdue)."),
            _plain("overdue", "Overdue", f"{len(overdue(goals)):,}", "past due, not completed", "Goals whose due date has passed and that aren't completed."),
            _plain("not_started", "Not started", f"{count('Not started'):,}", "no progress yet", "Goals with no progress recorded."),
        ]},
        {"title": "Coverage", "icon": "users", "cards": [
            _plain("coverage", "Employees with goals", pct(share(len(owners), len(cur))), f"{len(owners):,} of {len(cur):,}",
                   "Share of people employed today who have at least one goal this cycle."),
            _plain("per_person", "Goals per person", "–" if not owners else f"{n / len(owners):.1f}", "for people with goals",
                   "Average number of goals for people who have goals."),
            _plain("due_quarter", "Due this quarter", f"{len(due_q):,}", f"open goals due by {q_end:%d %b}",
                   "Open goals due between today and the end of this quarter."),
        ]},
    ]

    status_items = [{"label": s, "value": count(s)} for s in STATUS_ORDER]
    by_dept = _group_by(goals, lambda g: by_id[g.recipient_id].department)
    by_cat = _group_by(goals, lambda g: g.category)
    quarters = {}
    for g in goals:
        if g.due_date:
            qn = (g.due_date.month - 4) // 3 + 1 if g.due_date.month >= 4 else 4
            quarters.setdefault(f"Q{qn} · due {g.due_date:%d %b}", []).append(g)

    def attention(gs):
        return share(sum(1 for g in gs if g.status in ("At risk", "Behind")), len(gs))

    dept_rows, dept_sort = [], []
    for name in sorted(by_dept, key=lambda d: -(avg_progress(by_dept[d]) or 0)):
        gs = by_dept[name]
        people_n = len({g.recipient_id for g in gs})
        vals = [people_n, len(gs), avg_progress(gs), share(count("Completed", gs), len(gs)), share(count("At risk", gs), len(gs)),
                share(count("Behind", gs), len(gs)), len(overdue(gs))]
        dept_rows.append([name, f"{people_n:,}", f"{len(gs):,}", pct(vals[2]), pct(vals[3]), pct(vals[4]), pct(vals[5]), f"{vals[6]}"])
        dept_sort.append([name] + vals)

    needs = sorted([g for g in goals if g.status in ("Behind", "At risk")],
                   key=lambda g: (g.status != "Behind", g.due_date or date.max, g.progress))[:15]
    need_rows = [[by_id[g.recipient_id].name, by_id[g.recipient_id].department, g.title,
                  f"{g.due_date:%d %b %Y}" if g.due_date else "–", f"{g.progress}%",
                  ("Overdue" if g in overdue([g]) else g.status)] for g in needs]
    need_sort = [[by_id[g.recipient_id].name, by_id[g.recipient_id].department, g.title,
                  g.due_date.isoformat() if g.due_date else "", g.progress, g.status] for g in needs]

    panels = [
        {"id": "status", "type": "donut", "size": "narrow", "title": "Goal status", "sub": f"All goals, {cycle}",
         "items": status_items, "center": "goals", "palette": "status"},
        {"id": "dept", "type": "hbars", "size": "wide", "title": "Progress by department", "sub": "Average progress of each team's goals (at risk and behind: see the table below)",
         "items": [_hbar(d, (avg_progress(gs) or 0) * 100, pct(avg_progress(gs)), f"{len(gs)} goals")
                   for d, gs in sorted(by_dept.items(), key=lambda kv: -(avg_progress(kv[1]) or 0))]},
        {"id": "category", "type": "hbars", "size": "half", "title": "Progress by category", "sub": "Average progress",
         "items": [_hbar(c, (avg_progress(gs) or 0) * 100, pct(avg_progress(gs)), f"{len(gs)} goals")
                   for c, gs in sorted(by_cat.items(), key=lambda kv: -len(kv[1]))]},
        {"id": "quarter", "type": "hbars", "size": "half", "title": "Completion by due date", "sub": "Share of goals completed, by quarter due",
         "items": [_hbar(q, (share(count("Completed", gs), len(gs)) or 0) * 100, pct(share(count("Completed", gs), len(gs))),
                         f"{len(overdue(gs))} overdue") for q, gs in sorted(quarters.items())]},
        {"id": "dept_table", "type": "table", "size": "full", "title": "By department", "sub": f"Goals for {cycle}.",
         **_table([("Department", False), ("People", True), ("Goals", True), ("Average progress", True), ("Completed", True),
                   ("At risk", True), ("Behind", True), ("Overdue", True)], dept_rows, dept_sort, bar_col=3)},
        {"id": "needs", "type": "table", "size": "full", "private": True, "title": "Goals that need attention",
         "sub": "Behind (including overdue) first, then at risk; soonest due first. Shown on the dashboard only.",
         **_table([("Employee", False), ("Department", False), ("Goal", False), ("Due", False), ("Progress", True), ("Status", False)],
                  need_rows, need_sort)},
    ]

    summary = []
    if n:
        summary.append(f"{n:,} goals are set for {cycle}, for {pct(share(len(owners), len(cur)))} of employees. "
                       f"Average progress is {pct(avg_progress(goals))}; {pct(share(count('Completed'), n))} are completed and "
                       f"{pct(share(count('On track'), n))} are on track.")
        summary.append(f"{pct(share(count('At risk'), n))} are at risk and {pct(share(count('Behind'), n))} are behind, "
                       f"including {len(overdue(goals))} overdue goals.")
        ranked = [(d, avg_progress(gs)) for d, gs in by_dept.items() if len(gs) >= 10]
        if len(ranked) >= 2:
            hi, lo = max(ranked, key=lambda x: x[1]), min(ranked, key=lambda x: x[1])
            summary.append(f"{hi[0]} is furthest ahead ({pct(hi[1])} average progress) and {lo[0]} furthest behind ({pct(lo[1])}).")
        if due_q:
            summary.append(f"{len(due_q)} open goals are due by {q_end:%d %b}.")
    notice = "" if n else (f"No goals for {cycle} yet. Run flask --app run seed-goals for demo goals.")

    return {**base["out"], "label": f"{cycle} · as of {today:%d %b %Y}", "compare_label": "", "notice": notice,
            "groups": groups, "panels": panels, "summary": summary, "cycle": cycle,
            "definitions": (f"Goals for the {cycle} cycle (April to March) of people employed on the date shown. Progress and "
                            "status are as recorded for each goal; overdue = past its due date and not completed.")}

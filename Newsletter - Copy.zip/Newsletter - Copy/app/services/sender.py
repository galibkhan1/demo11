"""Scheduled + queued sending.

Each worker cycle:
1. Activates campaigns whose ``scheduled_at`` has passed: one ``Delivery`` row per target recipient.
2. Claims a rate-limited batch of queued deliveries and sends them through the mail backend.
3. Marks campaigns ``sent`` once no deliveries are left in flight.

Row claiming uses ``SELECT ... FOR UPDATE SKIP LOCKED`` on PostgreSQL, so running the embedded
worker and one or more ``flask worker`` processes side by side never double-sends.
"""

import logging
import threading
import time
from collections import defaultdict
from datetime import timedelta

from flask import current_app

from .. import db
from ..models import Campaign, CampaignStatus, Delivery, DeliveryStatus, utcnow
from . import mailer, renderer
from .addresses import is_demo_address, sending_real_email
from .audience import audience_query  # also used by routes

log = logging.getLogger(__name__)
STALE_CLAIM = timedelta(minutes=10)


def activate_due_campaigns() -> int:
    due = (
        Campaign.query.filter(
            Campaign.status == CampaignStatus.SCHEDULED, Campaign.scheduled_at <= utcnow()
        )
        .with_for_update(skip_locked=True)
        .all()
    )
    for campaign in due:
        if campaign.repeat:
            from .recurring import spawn_copy

            spawn_copy(campaign)  # the dated copy is queued on the next cycle; the template moves to its next date
            continue
        recipients = audience_query(campaign.audience).all()
        if not recipients:
            campaign.status = CampaignStatus.FAILED
            campaign.last_error = "No active recipients matched the audience at send time."
            continue
        db.session.add_all(
            Delivery(campaign_id=campaign.id, recipient_id=r.id, email=r.email, name=r.name) for r in recipients
        )
        campaign.status = CampaignStatus.SENDING
        campaign.started_at = utcnow()
        campaign.last_error = ""
        has_copies = bool((campaign.cc or []) + (campaign.bcc or []))
        campaign.copy_status = "pending" if has_copies else ""
        campaign.copy_error = ""
        campaign.copy_attempts = 0
        log.info("Campaign %s queued for %d recipients", campaign.id, len(recipients))
    db.session.commit()
    return len(due)


def _release_stale_claims() -> None:
    """Deliveries claimed by a worker that died mid-batch go back on the queue."""
    Delivery.query.filter(
        Delivery.status == DeliveryStatus.SENDING, Delivery.claimed_at < utcnow() - STALE_CLAIM
    ).update({"status": DeliveryStatus.QUEUED}, synchronize_session=False)
    db.session.commit()


def _claim_batch(limit: int) -> list[Delivery]:
    batch = (
        Delivery.query.filter(Delivery.status == DeliveryStatus.QUEUED)
        .order_by(Delivery.id)
        .limit(limit)
        .with_for_update(skip_locked=True)
        .all()
    )
    now = utcnow()
    for delivery in batch:
        delivery.status = DeliveryStatus.SENDING
        delivery.claimed_at = now
    db.session.commit()
    return batch


def process_queue(limit: int) -> int:
    _release_stale_claims()
    batch = _claim_batch(limit)
    if not batch:
        return 0

    max_attempts = current_app.config["MAX_SEND_ATTEMPTS"]
    real = sending_real_email()
    by_campaign = defaultdict(list)
    for delivery in batch:
        by_campaign[delivery.campaign_id].append(delivery)

    try:
        with mailer.get_backend() as backend:
            for campaign_id, deliveries in by_campaign.items():
                campaign = db.session.get(Campaign, campaign_id)
                template = renderer.render_campaign_template(campaign, track=True)
                for delivery in deliveries:
                    delivery.attempts += 1
                    if real and is_demo_address(delivery.email):
                        # Never hand demo data to a real mail server: it bounces and hurts the sender's reputation.
                        delivery.status = DeliveryStatus.FAILED
                        delivery.error = "Not sent: demo address. Test domains like example.com can't receive real email."
                        continue
                    try:
                        email = renderer.personalize(
                            template, name=delivery.name, email=delivery.email, token=delivery.token
                        )
                        backend.send(
                            mailer.build_message(
                                to_email=delivery.email,
                                to_name=delivery.name,
                                subject=email.subject,
                                html=email.html,
                                text=email.text,
                                cc=campaign.cc or None,  # shown to the reader, not delivered here
                            ),
                            [delivery.email],
                        )
                    except Exception as exc:  # noqa: BLE001 — record any per-message failure and move on
                        log.warning("Send to %s failed: %s", delivery.email, exc)
                        delivery.error = str(exc)[:1000]
                        delivery.status = (
                            DeliveryStatus.QUEUED if delivery.attempts < max_attempts else DeliveryStatus.FAILED
                        )
                    else:
                        delivery.status = DeliveryStatus.SENT
                        delivery.sent_at = utcnow()
                        delivery.error = ""
    except Exception as exc:  # noqa: BLE001 — backend connection failed: requeue the whole batch
        log.error("Mail backend unavailable: %s", exc)
        for delivery in batch:
            if delivery.status == DeliveryStatus.SENDING:
                delivery.status = DeliveryStatus.QUEUED
                delivery.error = f"Mail backend error: {exc}"[:1000]
    db.session.commit()
    return len(batch)


def send_campaign_copies() -> None:
    """Send ONE untracked copy of each starting campaign to its Cc + Bcc addresses."""
    campaigns = (
        Campaign.query.filter(Campaign.status == CampaignStatus.SENDING, Campaign.copy_status == "pending")
        .with_for_update(skip_locked=True)
        .all()
    )
    if not campaigns:
        return
    max_attempts = current_app.config["MAX_SEND_ATTEMPTS"]
    for campaign in campaigns:
        cc, bcc = campaign.cc or [], campaign.bcc or []
        # Employees in the audience already get their own personal email: don't send them a second one.
        employees = {e for (e,) in db.session.query(Delivery.email).filter(Delivery.campaign_id == campaign.id)}
        real = sending_real_email()
        envelope = [a for a in cc + bcc if a not in employees and not (real and is_demo_address(a))]
        if not envelope:
            campaign.copy_status = "sent"
            continue
        try:
            template = renderer.render_campaign_template(campaign, track=False)
            email = renderer.personalize(template, name="", email="")
            message = mailer.build_message(
                to_header="undisclosed-recipients:;",
                cc=cc or None,
                subject=email.subject,
                html=email.html,
                text=email.text,
            )
            with mailer.get_backend() as backend:
                backend.send(message, envelope)
        except Exception as exc:  # noqa: BLE001 — retry on the next cycle
            campaign.copy_attempts += 1
            campaign.copy_error = str(exc)[:1000]
            log.warning("Cc/Bcc copy for campaign %s failed: %s", campaign.id, exc)
            if campaign.copy_attempts >= max_attempts:
                campaign.copy_status = "failed"
        else:
            campaign.copy_status = "sent"
            campaign.copy_error = ""
            log.info("Campaign %s: copy sent to %d Cc/Bcc address(es)", campaign.id, len(envelope))
    db.session.commit()


def finalize_campaigns() -> None:
    sending = Campaign.query.filter(Campaign.status == CampaignStatus.SENDING).all()
    for campaign in sending:
        if campaign.copy_status == "pending":
            continue  # wait until the Cc/Bcc copy has been sent (or has given up)
        in_flight = Delivery.query.filter(
            Delivery.campaign_id == campaign.id,
            Delivery.status.in_([DeliveryStatus.QUEUED, DeliveryStatus.SENDING]),
        ).count()
        if in_flight:
            continue
        failed = Delivery.query.filter_by(campaign_id=campaign.id, status=DeliveryStatus.FAILED).count()
        campaign.status = CampaignStatus.SENT
        campaign.finished_at = utcnow()
        notes = []
        if failed:
            notes.append(f"{failed} email(s) could not be delivered.")
        if campaign.copy_status == "failed":
            notes.append(f"The Cc/Bcc copy could not be sent: {campaign.copy_error}")
        campaign.last_error = " ".join(notes)
    db.session.commit()


def run_cycle() -> None:
    cfg = current_app.config
    per_cycle = max(1, cfg["SEND_RATE_PER_MINUTE"] * cfg["WORKER_INTERVAL_SECONDS"] // 60)
    activate_due_campaigns()
    send_campaign_copies()
    process_queue(per_cycle)
    finalize_campaigns()


def run_forever(app, stop_event: threading.Event | None = None) -> None:
    interval = app.config["WORKER_INTERVAL_SECONDS"]
    log.info("Newsletter worker started (every %ss, %s emails/min)", interval, app.config["SEND_RATE_PER_MINUTE"])
    while not (stop_event and stop_event.is_set()):
        with app.app_context():
            try:
                run_cycle()
            except Exception:  # noqa: BLE001 — keep the worker alive
                log.exception("Worker cycle failed")
                db.session.rollback()
            finally:
                db.session.remove()
        time.sleep(interval)


def start_background_worker(app) -> threading.Thread:
    thread = threading.Thread(target=run_forever, args=(app,), name="newsletter-worker", daemon=True)
    thread.start()
    return thread

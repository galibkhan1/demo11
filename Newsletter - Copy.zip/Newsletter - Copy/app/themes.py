"""App (studio UI) themes. The CSS for each lives in static/css/app.css under html[data-theme="..."].

`preview` colors only drive the little mock-ups on the Settings page.
"""

DEFAULT_THEME = "indigo"

THEMES = {
    "indigo": {
        "name": "Indigo", "mode": "light", "description": "The default. Navy sidebar with indigo accents.",
        "preview": {"bg": "#f3f5f9", "surface": "#ffffff", "border": "#e3e8ef", "primary": "#4f46e5",
                    "gradient": "linear-gradient(135deg, #4f46e5, #6366f1 60%, #7c3aed)", "text": "#0f172a", "line": "#e3e8ef", "sidebar": "#0f172a"},
    },
    "ocean": {
        "name": "Ocean", "mode": "light", "description": "Crisp blues with a cool cyan sweep.",
        "preview": {"bg": "#f3f7fb", "surface": "#ffffff", "border": "#e2eaf3", "primary": "#1d6ff2",
                    "gradient": "linear-gradient(135deg, #1d4ed8, #1d6ff2 50%, #0891b2)", "text": "#0f172a", "line": "#e3ebf5", "sidebar": "#0b1729"},
    },
    "emerald": {
        "name": "Emerald", "mode": "light", "description": "Fresh greens. Easy on the eyes all day.",
        "preview": {"bg": "#f3f8f6", "surface": "#ffffff", "border": "#e0ece6", "primary": "#059669",
                    "gradient": "linear-gradient(135deg, #065f46, #059669 50%, #0d9488)", "text": "#0f1f19", "line": "#e2efe9", "sidebar": "#0a1a16"},
    },
    "sunset": {
        "name": "Sunset", "mode": "light", "description": "Warm orange melting into rose.",
        "preview": {"bg": "#fbf6f3", "surface": "#ffffff", "border": "#f1e6df", "primary": "#ea580c",
                    "gradient": "linear-gradient(135deg, #ea580c, #e11d48 55%, #be185d)", "text": "#1f140e", "line": "#f3e9e2", "sidebar": "#1a1210"},
    },
    "rose": {
        "name": "Rose", "mode": "light", "description": "Playful pink with a purple glow.",
        "preview": {"bg": "#fbf5f8", "surface": "#ffffff", "border": "#f1e3eb", "primary": "#db2777",
                    "gradient": "linear-gradient(135deg, #db2777, #c026d3 55%, #7c3aed)", "text": "#1f0f18", "line": "#f3e6ee", "sidebar": "#1a0f17"},
    },
    "slate": {
        "name": "Slate", "mode": "light", "description": "Minimal monochrome for a focused look.",
        "preview": {"bg": "#f4f5f7", "surface": "#ffffff", "border": "#e3e6ea", "primary": "#334155",
                    "gradient": "linear-gradient(135deg, #0f172a, #334155 55%, #475569)", "text": "#0f172a", "line": "#e5e8ec", "sidebar": "#111827"},
    },
    "midnight": {
        "name": "Midnight", "mode": "dark", "description": "Deep navy dark mode with indigo accents.",
        "preview": {"bg": "#0e0f1a", "surface": "#171928", "border": "#2a2d43", "primary": "#8b7dff",
                    "gradient": "linear-gradient(135deg, #4f46e5, #7c3aed 55%, #a21caf)", "text": "#eceefb", "line": "#2a2d43", "sidebar": "#08090f"},
    },
    "aurora": {
        "name": "Aurora", "mode": "dark", "description": "Dark teal with northern-lights highlights.",
        "preview": {"bg": "#07141b", "surface": "#0e1f29", "border": "#1d3a4a", "primary": "#2dd4bf",
                    "gradient": "linear-gradient(135deg, #0f766e, #0e7490 50%, #6d28d9)", "text": "#e6f4f8", "line": "#1d3a4a", "sidebar": "#040d12"},
    },
}


def valid_theme(key) -> str:
    return key if key in THEMES else DEFAULT_THEME

"""Security helpers: admin-only routes, sign-in throttling, security headers, CSV formula escaping."""

import threading
import time
from collections import defaultdict, deque
from functools import wraps

from flask import abort, current_app, flash, jsonify, redirect, request, url_for
from flask_login import current_user


# ------------------------------------------------------------------------------------------- admin-only routes
def is_admin(user=None) -> bool:
    user = user if user is not None else current_user
    return bool(getattr(user, "is_authenticated", False) and getattr(user, "role", "") == "admin")


def admin_required(view):
    """Only admins (employee records, users & access, company-wide actions). Others get a clear refusal."""
    @wraps(view)
    def wrapped(*args, **kwargs):
        if is_admin():
            return view(*args, **kwargs)
        if request.is_json or request.accept_mimetypes.best == "application/json":
            return jsonify(error="Only an admin can do this."), 403
        if request.method == "POST":
            flash("Only an admin can do this.", "error")
            return redirect(request.referrer or url_for("dashboard.index"))
        abort(403)
    return wrapped


# ------------------------------------------------------------------------------------------- sign-in throttling
class LoginThrottle:
    """Too many failed sign-ins for one email (or from one address) lock it for a while. In memory, per process."""

    def __init__(self):
        self._fails = defaultdict(deque)
        self._lock = threading.Lock()

    def _keys(self, email: str, ip: str) -> list[str]:
        return [f"email:{email.lower()}", f"ip:{ip}"]

    def _limits(self):
        cfg = current_app.config
        return int(cfg.get("LOGIN_MAX_ATTEMPTS", 5)), int(cfg.get("LOGIN_LOCK_MINUTES", 15)) * 60

    def blocked_for(self, email: str, ip: str) -> int:
        """Seconds until sign-in is allowed again (0 = allowed).

        One account locks after LOGIN_MAX_ATTEMPTS failures; one address after four times that, so a colleague
        who mistypes their own password on a shared computer doesn't lock everyone else out.
        """
        max_attempts, window = self._limits()
        now = time.time()
        wait = 0
        with self._lock:
            for key in self._keys(email, ip):
                limit = max_attempts if key.startswith("email:") else max_attempts * 4
                q = self._fails[key]
                while q and now - q[0] > window:
                    q.popleft()
                if len(q) >= limit:
                    wait = max(wait, int(window - (now - q[0])) + 1)
        return wait

    def failed(self, email: str, ip: str) -> None:
        now = time.time()
        with self._lock:
            for key in self._keys(email, ip):
                self._fails[key].append(now)

    def succeeded(self, email: str, ip: str) -> None:
        with self._lock:
            self._fails.pop(f"email:{email.lower()}", None)

    def reset(self) -> None:
        with self._lock:
            self._fails.clear()


login_throttle = LoginThrottle()


class RateLimit:
    """At most `limit` actions per `window` seconds per key (e.g. help questions per user). In memory, per process."""

    def __init__(self, limit_setting: str, window_setting: str, default_limit: int, default_minutes: int):
        self._settings = (limit_setting, window_setting, default_limit, default_minutes)
        self._hits = defaultdict(deque)
        self._lock = threading.Lock()

    def hit(self, key: str) -> int:
        """Record one action; returns 0 if allowed, else the seconds until the next one is."""
        limit_setting, window_setting, default_limit, default_minutes = self._settings
        limit = int(current_app.config.get(limit_setting, default_limit))
        window = int(current_app.config.get(window_setting, default_minutes)) * 60
        now = time.time()
        with self._lock:
            q = self._hits[key]
            while q and now - q[0] > window:
                q.popleft()
            if len(q) >= limit:
                return int(window - (now - q[0])) + 1
            q.append(now)
            return 0

    def reset(self) -> None:
        with self._lock:
            self._hits.clear()


help_limit = RateLimit("HELP_MAX_QUESTIONS", "HELP_WINDOW_MINUTES", 30, 10)


# ------------------------------------------------------------------------------------------- security headers
CSP = "; ".join([
    "default-src 'self'",
    "script-src 'self' 'unsafe-inline'",        # the templates use small inline scripts
    "style-src 'self' 'unsafe-inline'",
    "img-src 'self' data: https: http:",       # email images come from anywhere the writer links to
    "font-src 'self' data:",
    "connect-src 'self'",                       # page scripts can only talk to this app
    "frame-src 'self'",
    "object-src 'none'",
    "base-uri 'self'",
    "form-action 'self'",
    "frame-ancestors 'none'",                   # no one can embed the studio (clickjacking)
])


def add_security_headers(response):
    response.headers.setdefault("Content-Security-Policy", CSP)
    response.headers.setdefault("X-Frame-Options", "DENY")
    response.headers.setdefault("X-Content-Type-Options", "nosniff")
    response.headers.setdefault("Referrer-Policy", "same-origin")
    response.headers.setdefault("Permissions-Policy", "camera=(), microphone=(), geolocation=(), payment=()")
    response.headers.setdefault("Cross-Origin-Opener-Policy", "same-origin")
    # Signed-in pages hold employee data: don't keep them in the browser cache (back button after sign-out).
    if (getattr(current_user, "is_authenticated", False) and request.endpoint != "static"
            and not request.path.startswith("/t/")):
        response.headers["Cache-Control"] = "no-store"
    return response


# ------------------------------------------------------------------------------------------- CSV formula escaping
_FORMULA_START = ("=", "+", "-", "@", "\t", "\r")


def csv_safe(value) -> str:
    """Spreadsheet apps run cells that start with = + - @ as formulas: prefix them with ' so they stay text."""
    text = "" if value is None else str(value)
    return "'" + text if text.startswith(_FORMULA_START) else text


def csv_unescape(value: str) -> str:
    """Undo csv_safe when a file we exported is imported again."""
    if len(value) > 1 and value[0] == "'" and value[1] in "=+-@\t\r":
        return value[1:]
    return value

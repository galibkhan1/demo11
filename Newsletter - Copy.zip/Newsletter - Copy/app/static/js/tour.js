// First-login guided tour: a short walkthrough of the space chooser, the dashboard, the newsletters list and
// the editor. Each part shows once, the first time someone opens that page; "Skip tour" ends it everywhere.
// Progress is saved on the account (POST /tour/progress, /tour/skip). "Take the tour" in the sidebar restarts it.
(function () {
  const cfgEl = document.getElementById("tour-config");
  if (!cfgEl) return;
  let cfg;
  try { cfg = JSON.parse(cfgEl.textContent); } catch (_) { return; }

  const csrf = document.querySelector('meta[name="csrf-token"]')?.content || "";
  const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const LABELS = { spaces: "Spaces", dashboard: "Dashboard", newsletters: "Newsletters", editor: "Editor" };
  const left = (chapter) => cfg.remaining.includes(chapter);
  const spaceName = cfg.space || "current";

  // ---------------------------------------------------------------- the steps of each part
  // target: CSS selector(s) to highlight (several = one box around all); alt: fallback selector;
  // place: preferred side for the card. Steps whose target isn't on the page (or is hidden) are left out.
  const PARTS = {
    spaces: {
      steps: [
        { target: ".sp-admin", title: "You can open every space",
          body: "As an admin you see all the spaces, and you choose who can open which one in Settings → Users & access." },
        { target: ".sp-grid", title: "Choose a space",
          body: "Each space holds one kind of people data, such as headcount and attrition, DEI, performance or goals. "
            + "The dashboard, newsletters built from data and the numbers the AI uses cover only the space you pick."
            + (left("dashboard") ? " Click one to open it, and the tour carries on there." : "") },
        { target: ".sp-none", title: "No space yet",
          body: "You don't have access to a space yet, so ask an admin for one. Meanwhile you can still write newsletters from a prompt." },
      ],
    },
    dashboard: {
      go: { chapter: "newsletters", url: cfg.urls.newsletters },
      steps: [
        { target: "[data-tour=space]", place: "right", title: `You're in the ${spaceName} space`,
          body: "Everything on this dashboard comes from this space. Click here any time to switch to another one." },
        { target: "#wf-filters, #sp-filters", title: "Filter the numbers",
          body: "Pick a period and narrow it down by department, location and more. Every card, chart and table on the page follows your filters." },
        { target: ".kpi-strip", title: "Key numbers at a glance",
          body: "Headline figures with the change against the previous period. Further down, hover a chart for exact values or click a table column to sort it." },
        { target: "#emp-card .card-head", title: "The people behind the numbers",
          body: "The table lists the first 10 employees who match your filters. Download CSV gives you the full list." },
        { target: ".tb-search", title: "Find anyone",
          body: "Search employees by name, email, ID or designation. Press Ctrl K on any page to jump here." },
        { target: "#help-fab", place: "left", title: "Questions? Ask here",
          body: "The help assistant answers how-to questions on every page, like how to write a prompt for an attrition newsletter, and gives you prompts you can use straight away." },
        { target: "[data-tour=newsletters]", place: "right", title: "Your newsletters",
          body: "Drafts, scheduled and sent newsletters all live here." },
      ],
    },
    newsletters: {
      steps: [
        { target: "#nl-tabs", title: "Drafts, scheduled and sent",
          body: "Filter your newsletters here. A sent newsletter opens its results: opens, clicks and the most-clicked links." },
        { target: "[data-tour=insights]", place: "right", title: "Learn what works",
          body: "Newsletter insights shows the best time to send, open and click trends, and ideas for your next topic." },
        { target: ".page-head .actions", title: "Create a newsletter",
          body: "Start a new one here, or with New newsletter at the top of the sidebar."
            + (left("editor") ? " Open it and the tour shows you around the editor." : "") },
      ],
    },
    editor: {
      steps: [
        { target: ".write-mode", place: "right", title: "Two ways to make it",
          body: "Write a prompt: describe the newsletter and the AI drafts it. Use your data: choose the numbers and it's built for you, with charts and a short summary." },
        { target: ".ai-card", place: "right", title: "Describe your newsletter",
          body: "Give the facts, links and tone, then click Generate. Short of ideas? Click a recommended prompt below it and fill in the [brackets]." },
        { target: ".ed-compose", place: "right", title: "Who gets it",
          body: "Choose the audience, add Cc or Bcc, and write the subject and the preview line people see in their inbox." },
        { target: ".ed-tabs", place: "right", title: "Blocks, style and tips",
          body: "Blocks adds text, images, buttons, stats and more. Style sets the colours and fonts. Tips checks your draft before you send it." },
        { target: "#canvas .blk", alt: "#canvas", title: "Edit right on the page",
          body: "Click any block to change its text or settings, and drag blocks to put them in a different order.",
          altBody: "Your newsletter appears here. Once you generate a draft or add blocks, click any block to change it, and drag blocks to reorder them." },
        { target: ["#btn-preview", "#btn-test"], title: "Check before you send",
          body: "Preview shows it the way employees will see it. Send test emails a copy to you first." },
        { target: "#btn-schedule", title: "Send or schedule",
          body: "Send it now, pick a date and time, or repeat it daily, weekly or monthly." },
      ],
    },
  };
  const part = PARTS[cfg.chapter];
  if (!part) return;

  const WELCOME = {
    welcome: true,
    title: `Welcome${cfg.first ? ", " + cfg.first : ""}!`,
    body: "Here's a quick tour of Newsletter Studio. It takes about a minute and shows where your data lives and how to send your first newsletter. You can skip it at any time.",
  };
  const OUTLINE = [["layers", "Choose a space"], ["dashboard", "Read your dashboard"], ["mail", "Find your newsletters"], ["pencil", "Write and send one"]];

  // ---------------------------------------------------------------- helpers
  function post(url, body) {
    return fetch(url, {
      method: "POST", keepalive: true, credentials: "same-origin",
      headers: { "Content-Type": "application/json", "X-CSRFToken": csrf, Accept: "application/json" },
      body: JSON.stringify(body || {}),
    }).then((r) => (r.ok ? r.json() : null)).catch(() => null);
  }
  function shown(node) {
    if (!node) return false;
    const r = node.getBoundingClientRect();
    if (r.width < 2 || r.height < 2) return false;
    const st = getComputedStyle(node);
    return st.visibility !== "hidden" && st.display !== "none";
  }
  function first(sel) { return [...document.querySelectorAll(sel)].find(shown) || null; }
  function nodesFor(step) {
    if (!step.target) return [];
    let nodes = [].concat(step.target).map(first).filter(Boolean);
    if (!nodes.length && step.alt) nodes = [first(step.alt)].filter(Boolean);
    return nodes;
  }
  function box(nodes) {
    const rs = nodes.map((n) => n.getBoundingClientRect());
    return {
      left: Math.min(...rs.map((r) => r.left)), top: Math.min(...rs.map((r) => r.top)),
      right: Math.max(...rs.map((r) => r.right)), bottom: Math.max(...rs.map((r) => r.bottom)),
    };
  }
  const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
  // Resolves once scrolling has stopped (the highlighted item hasn't moved for a few frames), at most 1.6 s.
  function settle(nodes) {
    return new Promise((resolve) => {
      const t0 = performance.now();
      let lastTop = null, still = 0;
      const tick = () => {
        const top = box(nodes).top;
        still = lastTop !== null && Math.abs(top - lastTop) < 0.5 ? still + 1 : 0;
        lastTop = top;
        if (still >= 5 || performance.now() - t0 > 1600) resolve();
        else requestAnimationFrame(tick);
      };
      setTimeout(() => requestAnimationFrame(tick), 80); // smooth scrolling starts a frame or two later
    });
  }
  function el(tag, cls, text) {
    const n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text != null) n.textContent = text;
    return n;
  }

  // ---------------------------------------------------------------- build
  const steps = part.steps.filter((s) => nodesFor(s).length);
  if (cfg.fresh) steps.unshift(WELCOME);
  if (!steps.length) return;

  let idx = 0, marked = null, active = false, frame = 0, opener = null;
  const root = el("div", "tour");
  const NS = "http://www.w3.org/2000/svg";
  const shade = document.createElementNS(NS, "svg");
  shade.setAttribute("class", "tour-shade");
  shade.setAttribute("aria-hidden", "true");
  const path = document.createElementNS(NS, "path");
  path.setAttribute("fill-rule", "evenodd");
  shade.append(path);
  const ring = el("div", "tour-ring");
  ring.setAttribute("aria-hidden", "true");

  const pop = el("div", "tour-pop");
  pop.setAttribute("role", "dialog");
  pop.setAttribute("aria-modal", "true");
  pop.setAttribute("aria-labelledby", "tour-title");
  pop.setAttribute("aria-describedby", "tour-body");
  const arrow = el("span", "tour-arrow");
  arrow.setAttribute("aria-hidden", "true");
  const hero = el("div", "tour-hero");
  hero.append(svgIcon("compass", 26));
  const partLabel = el("div", "tour-part");
  const title = el("h2", "tour-title");
  title.id = "tour-title";
  const body = el("p", "tour-body");
  body.id = "tour-body";
  const outline = el("ol", "tour-outline");
  OUTLINE.forEach(([ic, label], i) => {
    const li = el("li");
    const num = el("span", "num");
    num.append(svgIcon(ic, 15));
    li.append(num, el("span", null, `${i + 1}. ${label}`));
    outline.append(li);
  });
  const foot = el("div", "tour-foot");
  const skipBtn = el("button", "btn btn-ghost btn-sm tour-skip", "Skip tour");
  const dots = el("span", "tour-dots");
  dots.setAttribute("aria-hidden", "true");
  const backBtn = el("button", "btn btn-sm tour-back", "Back");
  const nextBtn = el("button", "btn btn-primary btn-sm tour-next");
  [skipBtn, backBtn, nextBtn].forEach((b) => { b.type = "button"; });
  foot.append(skipBtn, dots, backBtn, nextBtn);
  pop.append(arrow, hero, partLabel, title, body, outline, foot);
  root.append(shade, ring, pop);

  const realSteps = steps.filter((s) => !s.welcome);

  // ---------------------------------------------------------------- show a step
  async function show(i) {
    idx = i;
    const step = steps[i];
    const last = i === steps.length - 1;
    pop.classList.toggle("welcome", !!step.welcome);
    hero.hidden = !step.welcome;
    outline.hidden = !(step.welcome && cfg.chapter === "spaces");
    const n = realSteps.indexOf(step);
    partLabel.textContent = step.welcome
      ? "Quick tour"
      : `Part ${cfg.total - cfg.remaining.length} of ${cfg.total} · ${LABELS[cfg.chapter]} · ${n + 1}/${realSteps.length}`;
    title.textContent = step.title;
    const usingAlt = step.alt && ![].concat(step.target).some((s) => first(s));
    let text = usingAlt && step.altBody ? step.altBody : step.body;
    if (last && !step.welcome && !cfg.remaining.length) text += " That's the tour! You can take it again any time from Take the tour in the sidebar.";
    body.textContent = text;
    dots.replaceChildren(...realSteps.map((s) => el("i", s === step ? "on" : "")));
    dots.style.visibility = step.welcome || realSteps.length < 2 ? "hidden" : ""; // keeps its space in the row
    backBtn.hidden = i === 0;

    nextBtn.replaceChildren();
    if (step.welcome) nextBtn.append("Start the tour ", svgIcon("arrow-right", 15));
    else if (!last) nextBtn.append("Next");
    else if (part.go && left(part.go.chapter)) nextBtn.append(`Next: ${LABELS[part.go.chapter]} `, svgIcon("arrow-right", 15));
    else nextBtn.append(cfg.remaining.length ? "Got it" : "Finish");

    // Reaching the last step counts as having seen this part (even if they then click the highlighted item).
    if (last && !marked) marked = post(cfg.urls.progress, { chapter: cfg.chapter });

    const nodes = nodesFor(step);
    if (nodes.length) {
      const r = box(nodes);
      const inView = r.top >= 60 && r.bottom <= innerHeight - 12 && r.left >= 0 && r.right <= innerWidth;
      if (!inView) {
        pop.classList.add("is-moving");
        nodes[0].scrollIntoView({ block: r.bottom - r.top > innerHeight * 0.6 ? "start" : "center", inline: "nearest",
          behavior: reduced ? "auto" : "smooth" });
        await settle(nodes);
        if (idx !== i) return;
      }
    }
    place();
    pop.classList.remove("is-moving");
    pop.classList.remove("entering");
    void pop.offsetWidth;
    pop.classList.add("entering");
    nextBtn.focus({ preventScroll: true });
  }

  // ---------------------------------------------------------------- position the highlight and the card
  function place() {
    if (!active) return;
    const step = steps[idx];
    const vw = document.documentElement.clientWidth, vh = innerHeight, m = 12, gap = 14, pad = 6;
    shade.setAttribute("viewBox", `0 0 ${vw} ${vh}`);
    const outer = `M0 0H${vw}V${vh}H0Z`;
    const nodes = step.welcome ? [] : nodesFor(step);
    let hole = null;
    if (nodes.length) {
      const r = box(nodes);
      const x1 = clamp(r.left - pad, 4, vw - 4), y1 = clamp(r.top - pad, 4, vh - 4);
      const x2 = clamp(r.right + pad, 4, vw - 4), y2 = clamp(r.bottom + pad, 4, vh - 4);
      if (x2 - x1 > 4 && y2 - y1 > 4) hole = { x1, y1, x2, y2 };
    }
    if (hole) {
      const { x1, y1, x2, y2 } = hole;
      const rr = Math.min(10, (x2 - x1) / 2, (y2 - y1) / 2);
      path.setAttribute("d", `${outer}M${x1 + rr} ${y1}H${x2 - rr}A${rr} ${rr} 0 0 1 ${x2} ${y1 + rr}V${y2 - rr}`
        + `A${rr} ${rr} 0 0 1 ${x2 - rr} ${y2}H${x1 + rr}A${rr} ${rr} 0 0 1 ${x1} ${y2 - rr}V${y1 + rr}A${rr} ${rr} 0 0 1 ${x1 + rr} ${y1}Z`);
      Object.assign(ring.style, { left: x1 + "px", top: y1 + "px", width: x2 - x1 + "px", height: y2 - y1 + "px" });
      ring.hidden = false;
    } else {
      path.setAttribute("d", outer);
      ring.hidden = true;
    }

    const narrow = vw < 640;
    pop.classList.toggle("docked", narrow && !!hole);
    pop.classList.remove("wide");
    let pw = pop.offsetWidth, ph = pop.offsetHeight;
    let x, y, side = "none";
    if (!hole) {
      x = (vw - pw) / 2; y = (vh - ph) / 2;
    } else if (narrow) {
      // Phones: a card along the bottom (or the top, when the highlight is low on the screen).
      x = m; y = (hole.y1 + hole.y2) / 2 > vh / 2 ? m : vh - ph - m;
    } else {
      const { x1, y1, x2, y2 } = hole;
      const room = { bottom: vh - y2, top: y1, right: vw - x2, left: x1 };
      const fits = (s) => ((s === "bottom" || s === "top") ? room[s] >= ph + gap + m : room[s] >= pw + gap + m);
      side = [step.place, "bottom", "top", "right", "left"].filter(Boolean).find(fits);
      if (!side) {
        // Nothing fits beside a big highlight: a wider, shorter card often fits above or below it.
        pop.classList.add("wide");
        pw = pop.offsetWidth; ph = pop.offsetHeight;
        side = ["top", "bottom"].find(fits);
        if (!side) { pop.classList.remove("wide"); pw = pop.offsetWidth; ph = pop.offsetHeight; side = "over"; }
      }
      const cx = (x1 + x2) / 2, cy = (y1 + y2) / 2;
      if (side === "bottom") { y = y2 + gap; x = cx - pw / 2; }
      else if (side === "top") { y = y1 - gap - ph; x = cx - pw / 2; }
      else if (side === "right") { x = x2 + gap; y = cy - ph / 2; }
      else if (side === "left") { x = x1 - gap - pw; y = cy - ph / 2; }
      else { x = cx - pw / 2; y = y1 + 16; } // too big to sit beside: sit on top of it
      x = clamp(x, m, vw - pw - m);
      y = clamp(y, m, vh - ph - m);
      if (side === "bottom" || side === "top") arrow.style.cssText = `left: ${clamp(cx - x, 18, pw - 18) - 6}px`;
      else if (side === "right" || side === "left") arrow.style.cssText = `top: ${clamp(cy - y, 18, ph - 18) - 6}px`;
    }
    pop.dataset.side = side;
    pop.style.left = Math.round(x) + "px";
    pop.style.top = Math.round(y) + "px";
  }
  const schedule = () => { cancelAnimationFrame(frame); frame = requestAnimationFrame(place); };

  // ---------------------------------------------------------------- actions
  function close() {
    active = false;
    window.removeEventListener("scroll", schedule, true);
    window.removeEventListener("resize", schedule);
    document.removeEventListener("keydown", onKey, true);
    ro?.disconnect();
    root.remove();
    if (opener && document.contains(opener)) opener.focus({ preventScroll: true });
  }
  function skip() {
    post(cfg.urls.skip);
    close();
    window.toast?.("Tour skipped. You can take it again any time from Take the tour in the sidebar.", "info", 6000);
  }
  async function next() {
    if (idx < steps.length - 1) return show(idx + 1);
    if (part.go && left(part.go.chapter)) {
      nextBtn.disabled = true;
      await marked;
      location.href = part.go.url;
      return;
    }
    close();
    if (!cfg.remaining.length) window.toast?.("You're all set. Enjoy Newsletter Studio!", "success", 5000);
  }
  function back() { if (idx > 0) show(idx - 1); }
  function onKey(e) {
    if (!active) return;
    if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); skip(); return; }
    const typing = /^(INPUT|TEXTAREA|SELECT)$/.test(document.activeElement?.tagName) || document.activeElement?.isContentEditable;
    if (typing) return;
    if (e.key === "ArrowRight") { e.preventDefault(); next(); }
    else if (e.key === "ArrowLeft") { e.preventDefault(); back(); }
  }
  nextBtn.addEventListener("click", next);
  backBtn.addEventListener("click", back);
  skipBtn.addEventListener("click", skip);
  // A click on the dimmed page nudges the card instead of doing anything behind it.
  path.addEventListener("click", () => {
    pop.classList.remove("nudge");
    void pop.offsetWidth;
    pop.classList.add("nudge");
  });

  let ro = null;
  function start() {
    if (active || document.querySelector("dialog[open]")) return;
    active = true;
    opener = document.activeElement;
    document.body.append(root);
    window.addEventListener("scroll", schedule, true);
    window.addEventListener("resize", schedule);
    document.addEventListener("keydown", onKey, true);
    if ("ResizeObserver" in window) { ro = new ResizeObserver(schedule); ro.observe(document.body); }
    show(0);
  }
  // Start once the page (and its charts) have drawn.
  const go = () => setTimeout(start, 450);
  if (document.readyState === "complete") go(); else window.addEventListener("load", go, { once: true });
})();

// Small dependency-free SVG line chart: thin 2px lines, recessive grid, crosshair + tooltip, direct end labels.
(function () {
  const NS = "http://www.w3.org/2000/svg";
  const el = (tag, attrs, parent) => {
    const n = document.createElementNS(NS, tag);
    for (const [k, v] of Object.entries(attrs || {})) n.setAttribute(k, v);
    if (parent) parent.appendChild(n);
    return n;
  };
  // One resize listener per chart host, always redrawing the latest data (charts are re-rendered when filters change).
  function onResize(host, draw) {
    host._chartDraw = draw;
    if (host._chartResize) return;
    let t;
    host._chartResize = () => { clearTimeout(t); t = setTimeout(() => host._chartDraw && host._chartDraw(), 150); };
    window.addEventListener("resize", host._chartResize);
  }
  function niceStep(v) {
    const pow = Math.pow(10, Math.floor(Math.log10(v)));
    for (const m of [1, 2, 2.5, 5, 10]) if (m * pow >= v) return m * pow;
    return 10 * pow;
  }
  function niceMax(v) {
    if (v <= 4) return 4;
    const pow = Math.pow(10, Math.floor(Math.log10(v)));
    for (const m of [1, 2, 2.5, 5, 10]) if (m * pow >= v) return m * pow;
    return 10 * pow;
  }

  window.lineChart = function lineChart(host, rows, opts) {
    if (!host || !rows || !rows.length) return;
    const series = opts.series;
    const yFormat = opts.yFormat || ((v) => String(v));
    const xLabel = opts.xLabel || ((r, i) => String(i + 1));
    const H = opts.height || 260;

    function draw() {
      host.replaceChildren();
      const W = host.clientWidth || 700;
      const M = { top: 14, right: 86, bottom: 30, left: 44 };
      const iw = W - M.left - M.right, ih = H - M.top - M.bottom;
      const vals = rows.flatMap((r) => series.map((s) => r[s.key]));
      const dataMax = Math.max(1, ...vals);
      let minY = 0;
      let maxY = opts.yMax ? Math.min(opts.yMax, niceMax(dataMax * 1.1)) : niceMax(dataMax);
      if (opts.fitY) {  // lines may zoom to the data (bars never do): 4 even steps around the range
        const lo = Math.min(...vals), hi = Math.max(...vals);
        let step = niceStep(Math.max(1, (hi - lo) / 3));
        for (let guard = 0; guard < 8; guard++) {
          minY = Math.max(0, Math.floor(lo / step) * step - step);
          maxY = minY + 4 * step;
          if (maxY >= hi) break;
          step = niceStep(step * 1.5);
        }
      }
      const x = (i) => M.left + (rows.length === 1 ? iw / 2 : (i / (rows.length - 1)) * iw);
      const y = (v) => M.top + ih - ((v - minY) / (maxY - minY)) * ih;
      const svg = el("svg", { width: W, height: H, viewBox: `0 0 ${W} ${H}` }, host);

      for (let t = 0; t <= 4; t++) {
        const v = minY + ((maxY - minY) / 4) * t, yy = y(v);
        el("line", { x1: M.left, x2: M.left + iw, y1: yy, y2: yy, class: t ? "grid" : "axis" }, svg);
        const lbl = el("text", { x: M.left - 10, y: yy + 4, "text-anchor": "end", class: "tick" }, svg);
        lbl.textContent = yFormat(Number.isInteger(v) ? v : +v.toFixed(1));
      }
      const maxTicks = Math.max(2, Math.floor(iw / 90));
      const step = Math.max(1, Math.ceil(rows.length / maxTicks));
      rows.forEach((r, i) => {
        if (i % step) return;
        const t = el("text", { x: x(i), y: H - 8, "text-anchor": "middle", class: "tick" }, svg);
        t.textContent = xLabel(r, i);
      });

      // Direct end labels, nudged apart so they never overlap.
      const last = rows[rows.length - 1];
      const ly = series.map((s) => y(last[s.key]) + 4);
      for (let pass = 0; pass < 3; pass++) {
        for (let a = 0; a < ly.length; a++) for (let b = a + 1; b < ly.length; b++) {
          if (Math.abs(ly[a] - ly[b]) < 15) {
            const mid = (ly[a] + ly[b]) / 2, up = ly[a] <= ly[b] ? a : b, down = up === a ? b : a;
            ly[up] = mid - 7.5; ly[down] = mid + 7.5;
          }
        }
      }
      series.forEach((s, si) => {
        const d = rows.map((r, i) => `${i ? "L" : "M"}${x(i).toFixed(1)},${y(r[s.key]).toFixed(1)}`).join("");
        el("path", { d, fill: "none", stroke: s.color, "stroke-width": 2, "stroke-linejoin": "round", "stroke-linecap": "round" }, svg);
        if (opts.points) rows.forEach((r, i) => el("circle", { cx: x(i), cy: y(r[s.key]), r: 4, fill: s.color, stroke: "var(--surface)", "stroke-width": 2 }, svg));
        const lbl = el("text", { x: M.left + iw + 10, y: ly[si], class: "series-label" }, svg);
        lbl.textContent = s.label;
      });

      const cross = el("line", { y1: M.top, y2: M.top + ih, class: "crosshair", visibility: "hidden" }, svg);
      const dots = series.map((s) => el("circle", { r: 5, fill: s.color, stroke: "var(--surface)", "stroke-width": 2, visibility: "hidden" }, svg));
      const tip = document.createElement("div");
      tip.className = "chart-tip";
      tip.hidden = true;
      host.appendChild(tip);
      const hit = el("rect", { x: M.left - 10, y: M.top, width: iw + 20, height: ih, fill: "transparent" }, svg);

      function show(clientX) {
        const box = svg.getBoundingClientRect();
        const i = Math.max(0, Math.min(rows.length - 1, Math.round(((clientX - box.left - M.left) / iw) * (rows.length - 1))));
        const r = rows[i], cx = x(i);
        cross.setAttribute("x1", cx); cross.setAttribute("x2", cx); cross.setAttribute("visibility", "visible");
        series.forEach((s, si) => { dots[si].setAttribute("cx", cx); dots[si].setAttribute("cy", y(r[s.key])); dots[si].setAttribute("visibility", "visible"); });
        tip.replaceChildren();
        const head = document.createElement("div");
        head.className = "chart-tip-head";
        head.textContent = opts.tipTitle ? opts.tipTitle(r, i) : xLabel(r, i);
        tip.appendChild(head);
        if (opts.tipSub) { const sub = document.createElement("div"); sub.className = "muted small"; sub.textContent = opts.tipSub(r, i); tip.appendChild(sub); }
        series.forEach((s) => {
          const line = document.createElement("div");
          const sw = document.createElement("i");
          sw.className = "swatch"; sw.style.background = s.color;
          line.append(sw, document.createTextNode(`${s.label}: ${yFormat(r[s.key])}`));
          tip.appendChild(line);
        });
        tip.hidden = false;
        const right = cx + 14 + tip.offsetWidth > W;
        tip.style.left = `${right ? cx - tip.offsetWidth - 14 : cx + 14}px`;
        tip.style.top = `${M.top}px`;
      }
      function hide() {
        cross.setAttribute("visibility", "hidden");
        dots.forEach((d) => d.setAttribute("visibility", "hidden"));
        tip.hidden = true;
      }
      hit.addEventListener("pointermove", (e) => show(e.clientX));
      hit.addEventListener("pointerleave", hide);
    }
    draw();
    onResize(host, draw);
  };

  // Single-series bar chart. rows: [{label, value, highlight}]. Highlighted bars use the full series color,
  // the rest a lighter tint of the same hue; an optional bracket labels the highlighted run.
  window.barChart = function barChart(host, rows, opts) {
    if (!host || !rows || !rows.length) return;
    const H = opts.height || 220;
    const color = opts.color || "var(--series-1)";
    const yFormat = opts.yFormat || ((v) => String(v));

    function draw() {
      host.replaceChildren();
      const W = host.clientWidth || 600;
      const M = { top: opts.annotation ? 26 : 12, right: 6, bottom: 26, left: 36 };
      const iw = W - M.left - M.right, ih = H - M.top - M.bottom;
      const maxY = niceMax(Math.max(1, ...rows.map((r) => r.value)));
      const band = iw / rows.length;
      const bw = Math.max(3, Math.min(22, band - 2)); // 2px surface gap between neighbours
      const x = (i) => M.left + i * band + (band - bw) / 2;
      const y = (v) => M.top + ih - (v / maxY) * ih;
      const svg = el("svg", { width: W, height: H, viewBox: `0 0 ${W} ${H}` }, host);

      for (let t = 0; t <= 4; t++) {
        const v = (maxY / 4) * t, yy = y(v);
        el("line", { x1: M.left, x2: M.left + iw, y1: yy, y2: yy, class: t ? "grid" : "axis" }, svg);
        const lbl = el("text", { x: M.left - 8, y: yy + 4, "text-anchor": "end", class: "tick" }, svg);
        lbl.textContent = yFormat(Number.isInteger(v) ? v : +v.toFixed(1));
      }
      const every = Math.max(1, Math.ceil(rows.length / Math.max(2, Math.floor(iw / 46))));
      rows.forEach((r, i) => {
        if (i % every) return;
        const t = el("text", { x: M.left + i * band + band / 2, y: H - 8, "text-anchor": "middle", class: "tick" }, svg);
        t.textContent = opts.xLabel ? opts.xLabel(r, i) : r.label;
      });

      // Bars: rounded 4px data end, square at the baseline.
      const bars = rows.map((r, i) => {
        const top = y(r.value), base = y(0), rad = Math.min(4, (base - top) / 2, bw / 2);
        const x0 = x(i), x1 = x0 + bw;
        const d = r.value <= 0 ? "" :
          `M${x0},${base}V${top + rad}Q${x0},${top} ${x0 + rad},${top}H${x1 - rad}Q${x1},${top} ${x1},${top + rad}V${base}Z`;
        return el("path", { d, fill: color, "fill-opacity": r.highlight ? 1 : 0.38, class: "bar" }, svg);
      });

      if (opts.annotation) {
        const idx = rows.map((r, i) => (r.highlight ? i : -1)).filter((i) => i >= 0);
        if (idx.length) {
          const x0 = x(idx[0]), x1 = x(idx[idx.length - 1]) + bw;
          const top = Math.min(...idx.map((i) => y(rows[i].value))) - 8;
          el("path", { d: `M${x0},${top + 4}V${top}H${x1}V${top + 4}`, fill: "none", stroke: "var(--text-2)", "stroke-width": 1 }, svg);
          const lbl = el("text", { x: (x0 + x1) / 2, y: top - 5, "text-anchor": "middle", class: "series-label" }, svg);
          lbl.textContent = opts.annotation;
        }
      }

      const tip = document.createElement("div");
      tip.className = "chart-tip";
      tip.hidden = true;
      host.appendChild(tip);
      rows.forEach((r, i) => {
        const hit = el("rect", { x: M.left + i * band, y: M.top, width: band, height: ih, fill: "transparent" }, svg);
        hit.addEventListener("pointerenter", () => {
          bars.forEach((b, j) => b.setAttribute("fill-opacity", j === i ? 1 : rows[j].highlight ? 0.8 : 0.3));
          tip.replaceChildren();
          const head = document.createElement("div");
          head.className = "chart-tip-head";
          head.textContent = opts.tipTitle ? opts.tipTitle(r, i) : r.label;
          tip.appendChild(head);
          for (const line of opts.tipLines ? opts.tipLines(r, i) : [yFormat(r.value)]) {
            const d = document.createElement("div");
            d.textContent = line;
            tip.appendChild(d);
          }
          tip.hidden = false;
          const cx = M.left + i * band + band / 2;
          const right = cx + 12 + tip.offsetWidth > W;
          tip.style.left = `${right ? cx - tip.offsetWidth - 12 : cx + 12}px`;
          tip.style.top = `${M.top}px`;
        });
        hit.addEventListener("pointerleave", () => {
          bars.forEach((b, j) => b.setAttribute("fill-opacity", rows[j].highlight ? 1 : 0.38));
          tip.hidden = true;
        });
      });
    }
    draw();
    onResize(host, draw);
  };
  // Grouped columns: rows [{label, <key>: number}], opts.series [{key, label, color}]. Legend is drawn by the caller.
  window.columnChart = function columnChart(host, rows, opts) {
    if (!host || !rows || !rows.length) return;
    const series = opts.series;
    const H = opts.height || 240;
    function draw() {
      host.replaceChildren();
      const W = host.clientWidth || 600;
      const M = { top: 12, right: 6, bottom: 26, left: 36 };
      const iw = W - M.left - M.right, ih = H - M.top - M.bottom;
      const maxY = niceMax(Math.max(1, ...rows.flatMap((r) => series.map((s) => r[s.key]))));
      const band = iw / rows.length;
      const bw = Math.max(3, Math.min(14, (band - 8) / series.length - 2));
      const groupW = series.length * bw + (series.length - 1) * 2;  // 2px surface gap between bars
      const y = (v) => M.top + ih - (v / maxY) * ih;
      const svg = el("svg", { width: W, height: H, viewBox: `0 0 ${W} ${H}` }, host);
      for (let t = 0; t <= 4; t++) {
        const v = (maxY / 4) * t, yy = y(v);
        el("line", { x1: M.left, x2: M.left + iw, y1: yy, y2: yy, class: t ? "grid" : "axis" }, svg);
        const lbl = el("text", { x: M.left - 8, y: yy + 4, "text-anchor": "end", class: "tick" }, svg);
        lbl.textContent = Number.isInteger(v) ? v : +v.toFixed(1);
      }
      const every = Math.max(1, Math.ceil(rows.length / Math.max(2, Math.floor(iw / 52))));
      const groups = rows.map((r, i) => {
        const x0 = M.left + i * band + (band - groupW) / 2;
        if (!(i % every)) {
          const t = el("text", { x: M.left + i * band + band / 2, y: H - 8, "text-anchor": "middle", class: "tick" }, svg);
          t.textContent = r.label;
        }
        return series.map((s, si) => {
          const v = r[s.key] || 0, top = y(v), base = y(0), rad = Math.min(4, (base - top) / 2, bw / 2);
          const x = x0 + si * (bw + 2), x1 = x + bw;
          const d = v <= 0 ? "" : `M${x},${base}V${top + rad}Q${x},${top} ${x + rad},${top}H${x1 - rad}Q${x1},${top} ${x1},${top + rad}V${base}Z`;
          return el("path", { d, fill: s.color, class: "bar" }, svg);
        });
      });
      const tip = document.createElement("div");
      tip.className = "chart-tip";
      tip.hidden = true;
      host.appendChild(tip);
      rows.forEach((r, i) => {
        const hit = el("rect", { x: M.left + i * band, y: M.top, width: band, height: ih, fill: "transparent" }, svg);
        hit.addEventListener("pointerenter", () => {
          groups.forEach((g, gi) => g.forEach((b) => b.setAttribute("fill-opacity", gi === i ? 1 : 0.35)));
          tip.replaceChildren();
          const head = document.createElement("div");
          head.className = "chart-tip-head";
          head.textContent = opts.tipTitle ? opts.tipTitle(r) : r.label;
          tip.appendChild(head);
          series.forEach((s) => {
            const line = document.createElement("div");
            const sw = document.createElement("i");
            sw.className = "swatch"; sw.style.background = s.color;
            line.append(sw, document.createTextNode(`${s.label}: ${r[s.key]}`));
            tip.appendChild(line);
          });
          tip.hidden = false;
          const cx = M.left + i * band + band / 2;
          tip.style.left = `${cx + 12 + tip.offsetWidth > W ? cx - tip.offsetWidth - 12 : cx + 12}px`;
          tip.style.top = `${M.top}px`;
        });
        hit.addEventListener("pointerleave", () => {
          groups.forEach((g) => g.forEach((b) => b.setAttribute("fill-opacity", 1)));
          tip.hidden = true;
        });
      });
    }
    draw();
    onResize(host, draw);
  };

  // Donut (pie) chart: items [{label, value, color}]. 2px surface gaps between slices; the caller draws the legend table.
  window.donutChart = function donutChart(host, items, opts = {}) {
    if (!host) return;
    host.replaceChildren();
    const size = opts.size || 170, R = size / 2 - 4, r0 = R * 0.62, cx = size / 2, cy = size / 2;
    const total = items.reduce((a, it) => a + it.value, 0);
    const svg = el("svg", { width: size, height: size, viewBox: `0 0 ${size} ${size}`, class: "donut" }, host);
    const pt = (rad, a) => `${(cx + rad * Math.cos(a)).toFixed(2)},${(cy + rad * Math.sin(a)).toFixed(2)}`;
    const tip = document.createElement("div");
    tip.className = "chart-tip";
    tip.hidden = true;
    host.appendChild(tip);
    if (!total) {
      el("circle", { cx, cy, r: (R + r0) / 2, fill: "none", stroke: "var(--grid-line)", "stroke-width": R - r0 }, svg);
    } else {
      let a = -Math.PI / 2;
      const slices = [];
      items.forEach((it) => {
        if (!it.value) return;
        const frac = it.value / total;
        const parts = frac > 0.999 ? [[a, a + Math.PI], [a + Math.PI, a + 2 * Math.PI]] : [[a, a + frac * 2 * Math.PI]];
        const paths = parts.map(([a0, a1]) => {
          const large = a1 - a0 > Math.PI ? 1 : 0;
          const d = `M${pt(R, a0)}A${R},${R} 0 ${large} 1 ${pt(R, a1)}L${pt(r0, a1)}A${r0},${r0} 0 ${large} 0 ${pt(r0, a0)}Z`;
          return el("path", { d, fill: it.color, stroke: "var(--surface)", "stroke-width": frac > 0.999 ? 0 : 2, class: "slice" }, svg);
        });
        a += frac * 2 * Math.PI;
        slices.push({ it, paths, frac });
      });
      slices.forEach(({ it, paths, frac }) => paths.forEach((p) => {
        p.addEventListener("pointerenter", () => {
          slices.forEach((s) => s.paths.forEach((x) => x.setAttribute("fill-opacity", s.it === it ? 1 : 0.35)));
          tip.textContent = `${it.label}: ${it.value.toLocaleString()} (${(frac * 100).toFixed(1)}%)`;
          tip.hidden = false;
          tip.style.left = `${size / 2 - tip.offsetWidth / 2}px`;
          tip.style.top = `${size + 4}px`;
        });
        p.addEventListener("pointerleave", () => {
          slices.forEach((s) => s.paths.forEach((x) => x.setAttribute("fill-opacity", 1)));
          tip.hidden = true;
        });
      }));
    }
    const value = el("text", { x: cx, y: cy + 2, "text-anchor": "middle", class: "donut-value" }, svg);
    value.textContent = opts.centerValue ?? total.toLocaleString();
    const label = el("text", { x: cx, y: cy + 20, "text-anchor": "middle", class: "donut-label" }, svg);
    label.textContent = opts.centerLabel || "total";
  };
})();

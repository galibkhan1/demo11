// Employees table at the bottom of the dashboards: first 10 people for the current filters, Download CSV for all.
(function () {
  "use strict";
  const card = document.getElementById("emp-card");
  if (!card) return;
  const urls = JSON.parse(document.getElementById("emp-urls").textContent);
  const table = document.getElementById("emp-table");
  const COLS = [["Employee", null], ["ID", "code"], ["Designation", "designation"], ["Department", "department"],
    ["Business unit", "bu"], ["Location", "location"], ["Manager", "manager"], ["Joined", "joined"], ["Status", null]];
  let seq = 0;

  function el(tag, cls, text) {
    const n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text !== undefined) n.textContent = text;
    return n;
  }
  function render(res) {
    const head = el("thead");
    const tr = el("tr");
    COLS.forEach(([label]) => tr.append(el("th", "", label)));
    head.append(tr);
    const body = el("tbody");
    if (!res.rows.length) {
      const row = el("tr");
      const td = el("td", "muted", "No employees match these filters.");
      td.colSpan = COLS.length;
      row.append(td);
      body.append(row);
    }
    res.rows.forEach((p) => {
      const row = el("tr");
      const who = el("td");
      const link = el("a", "emp-name", p.name);
      link.href = urls.people + "?" + new URLSearchParams({ q: p.email });
      link.title = "Open in Employees";
      who.append(link, el("div", "muted small", p.email));
      row.append(who);
      COLS.slice(1, -1).forEach(([, key]) => row.append(el("td", key === "joined" ? "nowrap" : "", p[key] || "–")));
      const st = el("td", "nowrap");
      const badge = el("span", "badge " + (p.status === "Serving notice" ? "badge-scheduled" : "badge-sent"), p.status);
      st.append(badge);
      if (p.paused) st.append(el("div", "muted small", "newsletters paused"));
      row.append(st);
      body.append(row);
    });
    table.replaceChildren(head, body);
    document.getElementById("emp-sub").textContent = res.total
      ? `${res.total.toLocaleString()} ${res.total === 1 ? "person" : "people"} employed today match the filters`
        + (res.total > res.rows.length ? ` · showing the first ${res.rows.length}. Download CSV for all of them.` : ".")
      : "Nobody employed today matches these filters.";
  }
  async function load(qs) {
    const mine = ++seq;
    document.getElementById("emp-download").href = urls.csv + (qs ? "?" + qs : "");
    try {
      const res = await api(urls.api + (qs ? "?" + qs : ""), undefined, "GET");
      if (mine === seq) render(res);
    } catch (e) {
      if (mine === seq) table.replaceChildren(el("tbody", "", ""), el("caption", "muted", "Couldn't load employees: " + e.message));
    }
  }
  document.addEventListener("dash-filters", (e) => load(e.detail));
})();

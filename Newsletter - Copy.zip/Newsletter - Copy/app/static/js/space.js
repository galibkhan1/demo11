// Dashboard for the DEI, Performance and Goals spaces: KPI groups and panels (donut, bars, columns, tables)
// rendered from the report the server sends. One request per filter change refreshes everything.
(function () {
  "use strict";
  const dataEl = document.getElementById("sp-data");
  if (!dataEl) return;
  const urls = JSON.parse(document.getElementById("sp-urls").textContent);
  const form = document.getElementById("sp-filters");
  const $ = (id) => document.getElementById(id);
  const root = $("space-dash");
  const KEY = "ns-space-filters-" + root.dataset.space;
  // Categorical slots in fixed order (validated palette); a category keeps its colour whatever the filter.
  const SLOT = ["var(--series-1)", "var(--series-2)", "var(--series-3)", "var(--series-4)"];
  const COLOR_OF = { Female: SLOT[0], Male: SLOT[1], "Non-binary": SLOT[2] };
  // Goal status uses the reserved status colours, always with a label beside them.
  const STATUS = { Completed: "var(--success)", "On track": "var(--series-1)", "At risk": "var(--warning)",
    Behind: "var(--danger)", "Not started": "var(--faint)" };
  let state = JSON.parse(dataEl.textContent);
  let seq = 0;
  let pending = [];  // charts are drawn once their card is on the page, so they can measure their width
  const sorts = {};

  function h(tag, attrs = {}, ...children) {
    const el = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs)) {
      if (v === null || v === undefined || v === false) continue;
      if (k === "class") el.className = v;
      else if (k === "style" && typeof v === "object") {
        for (const [prop, val] of Object.entries(v)) {
          if (prop.startsWith("--")) el.style.setProperty(prop, val);  // custom properties need setProperty
          else el.style[prop] = val;
        }
      }
      else if (k.startsWith("on")) el.addEventListener(k.slice(2), v);
      else el.setAttribute(k, v === true ? "" : v);
    }
    for (const c of children.flat()) if (c !== null && c !== undefined) el.append(c);
    return el;
  }
  const icon = (name, size = 15) => window.svgIcon(name, size);

  // ---------------- filters ----------------
  function fillSelect(name, items, keepValue) {
    const sel = form.elements[name];
    const value = keepValue ?? sel.value;
    sel.replaceChildren(...[["", "All"]].concat(items.map((i) => (typeof i === "string" ? [i, i] : [i.value, i.label])))
      .map(([v, l]) => h("option", { value: v }, l)));
    sel.value = [...sel.options].some((o) => o.value === value) ? value : "";
  }
  function fillOptions(o, f) {
    fillSelect("leader", o.leader, f.leader);
    fillSelect("bu", o.bu, f.bu);
    fillSelect("department", f.bu && o.dept_by_bu[f.bu] ? o.dept_by_bu[f.bu] : o.department, f.department);
    fillSelect("location", o.location, f.location);
    fillSelect("gender", o.gender, f.gender);
    fillSelect("grade", o.grade, f.grade);
    fillSelect("type", o.type, f.type);
  }

  // ---------------- KPI groups ----------------
  function card(c) {
    const link = c.link ? urls.people + "?" + new URLSearchParams(c.link) : null;
    const el = h(link ? "a" : "div", { class: "kpi", href: link, title: c.definition + (link ? " · Click to see these people" : "") },
      h("div", { class: "kpi-label" }, c.label), h("div", { class: "kpi-value" }, c.display));
    const row = h("div", { class: "kpi-row" });
    if (c.delta) {
      row.append(h("span", { class: "kpi-delta " + (c.good === true ? "good" : c.good === false ? "bad" : "neutral"),
        "aria-label": `Change ${c.delta} compared with ${state.compare_label}` },
      (c.trend === "up" ? "▲ " : c.trend === "down" ? "▼ " : "") + c.delta));
    }
    if (c.note) row.append(h("span", { class: "kpi-note", title: c.note }, c.note));
    el.append(row);
    return el;
  }
  function renderGroups() {
    $("sp-sub").textContent = `${state.scope} · ${state.label}`;
    $("sp-groups").replaceChildren(...state.groups.map((g) => h("section", {},
      h("h2", { class: "kpi-group-title" }, icon(g.icon || "chart"), g.title, g.note ? h("span", {}, g.note) : null),
      h("div", { class: "kpi-strip", style: { "--n": String(g.cards.length) } }, ...g.cards.map(card)))));
    const active = Object.values(state.filters).filter(Boolean).length;
    $("sp-foot").textContent = `${state.population.toLocaleString()} ${state.population === 1 ? "person" : "people"} employed`
      + `${active ? " match the filters" : " in scope"}. `
      + (state.compare_label ? `▲/▼ compare with ${state.compare_label}; green is better, red is worse. ` : "")
      + "Hover a number for its definition.";
    form.classList.toggle("filtered", active > 0);
    [...form.elements].forEach((el) => { if (el.tagName === "SELECT") el.classList.toggle("set", !!el.value); });
  }

  // ---------------- panels ----------------
  function colorFor(p, label, i) {
    if (p.palette === "status") return STATUS[label] || "var(--faint)";
    return COLOR_OF[label] || SLOT[i] || "var(--faint)";
  }
  function donutPanel(p, body) {
    const total = p.items.reduce((a, it) => a + it.value, 0);
    const items = p.items.map((it, i) => ({ ...it, color: colorFor(p, it.label, i) }));
    const host = h("div", { class: "donut-host", role: "img", "aria-label": `Donut chart: ${p.title}` });
    const legend = h("table", { class: "legend-table" }, h("tbody", {}, ...items.map((it) => h("tr", {},
      h("td", {}, h("i", { class: "swatch", style: { background: it.color } })),
      h("td", {}, it.label),
      h("td", { class: "num" }, it.value.toLocaleString()),
      h("td", { class: "num muted" }, total ? `${((it.value / total) * 100).toFixed(1)}%` : "–")))));
    body.append(h("div", { class: "donut-wrap" }, host, legend));
    pending.push(() => donutChart(host, items, { centerLabel: p.center || "" }));
  }
  function hbarsPanel(p, body) {
    if (!p.items.length) { body.append(h("p", { class: "muted small" }, p.empty || "No data for these filters.")); return; }
    const max = Math.max(...p.items.map((it) => it.value)) || 1;
    body.append(h("div", { class: "hbars" }, ...p.items.map((it) => h("div", { class: "hbar", title: `${it.label}: ${it.display}${it.sub ? " · " + it.sub : ""}` },
      h("span", { class: "hbar-label" }, it.label),
      h("span", { class: "meter" }, h("span", { style: { width: `${(it.value / max) * 100}%` } })),
      h("span", { class: "hbar-value" }, it.display, it.sub ? h("small", {}, it.sub) : null)))));
  }
  function columnsPanel(p, body, head) {
    const series = p.series.map((s, i) => ({ ...s, color: colorFor(p, s.label, i) }));
    if (series.length > 1) {
      head.append(h("div", { class: "legend", "aria-hidden": "true" }, ...series.map((s) =>
        h("span", {}, h("i", { class: "swatch", style: { background: s.color } }), s.label))));
    }
    const host = h("div", { class: "chart", role: "img", "aria-label": `Column chart: ${p.title}` });
    body.append(host);
    pending.push(() => columnChart(host, p.rows, { series, tipTitle: (r) => r.full || r.label, height: 230 }));
  }
  function tablePanel(p, body) {
    const sort = sorts[p.id] || { col: null, dir: -1 };
    let order = p.rows.map((_, i) => i);
    if (sort.col !== null) {
      order.sort((a, b) => {
        const av = p.sort[a][sort.col], bv = p.sort[b][sort.col];
        if (av === null || av === undefined) return 1;
        if (bv === null || bv === undefined) return -1;
        return (typeof av === "string" ? av.localeCompare(bv) : av - bv) * sort.dir;
      });
    }
    const table = h("table", { class: "table compact wf-table" },
      h("thead", {}, h("tr", {}, ...p.columns.map((c, i) => h("th", {
        class: (c.num ? "num " : "") + "sortable" + (sort.col === i ? " sorted" : ""), scope: "col",
        "aria-sort": sort.col === i ? (sort.dir > 0 ? "ascending" : "descending") : "none",
        onclick: () => { sorts[p.id] = { col: i, dir: sort.col === i ? -sort.dir : (c.num ? -1 : 1) }; renderPanels(); },
      }, c.label, sort.col === i ? (sort.dir > 0 ? " ↑" : " ↓") : "")))),
      h("tbody", {}, ...(order.length ? order.map((ri) => h("tr", {}, ...p.rows[ri].map((cell, ci) =>
        h("td", { class: p.columns[ci].num ? "num" : "" }, ci === 0 ? h("strong", {}, cell) : cell))))
        : [h("tr", {}, h("td", { colspan: p.columns.length, class: "muted" }, "Nothing to show for these filters."))])));
    body.append(h("div", { class: "table-wrap" }, table));
  }
  function renderPanels() {
    pending = [];
    $("sp-panels").replaceChildren(...state.panels.map((p) => {
      const head = h("div", { class: "card-head" }, h("div", {}, h("h2", {}, p.title), p.sub ? h("p", {}, p.sub) : null));
      const body = h("div", {});
      const cardEl = h("section", { class: `card span-${p.size || "half"}${p.type === "table" ? " card-flush" : ""}` }, head, body);
      ({ donut: donutPanel, hbars: hbarsPanel, columns: columnsPanel, table: tablePanel }[p.type] || (() => {}))(p, body, head);
      return cardEl;
    }));
    pending.forEach((draw) => draw());
    pending = [];
  }

  async function load() {
    const params = new URLSearchParams(new FormData(form));
    document.dispatchEvent(new CustomEvent("dash-filters", { detail: params.toString() }));  // Employees table
    try { localStorage.setItem(KEY, JSON.stringify(Object.fromEntries(params))); } catch (_) { /* optional */ }
    const mine = ++seq;
    root.classList.add("loading");
    try {
      const res = await api(urls.api + "?" + params, undefined, "GET");
      if (mine !== seq) return;
      state = res;
      fillOptions(state.options, state.filters);
      renderGroups();
      renderPanels();
    } catch (e) {
      toast("Couldn't update the dashboard: " + e.message, "error");
    } finally {
      if (mine === seq) root.classList.remove("loading");
    }
  }
  form.addEventListener("change", (e) => {
    if (e.target.name === "bu") form.elements.department.value = "";
    load();
  });
  $("sp-reset").addEventListener("click", () => {
    [...form.elements].forEach((el) => { if (el.tagName === "SELECT") el.value = ""; });
    load();
  });

  fillOptions(state.options, state.filters);
  renderGroups();
  renderPanels();
  document.dispatchEvent(new CustomEvent("dash-filters", { detail: new URLSearchParams(new FormData(form)).toString() }));
  try {  // reopen with the filters used last time in this space
    const saved = JSON.parse(localStorage.getItem(KEY) || "null");
    if (saved && Object.values(saved).some(Boolean)) {
      fillOptions(state.options, saved);
      load();
    }
  } catch (_) { /* optional */ }
})();

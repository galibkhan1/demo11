// Newsletter Studio — drag-and-drop block editor with AI generation.
(function () {
  "use strict";

  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));
  const cfg = JSON.parse($("#editor-config").textContent);
  const state = JSON.parse($("#campaign-data").textContent);
  state.content = state.content && state.content.blocks ? state.content : { theme: {}, blocks: [] };
  state.content.theme = Object.assign({}, cfg.defaultTheme, state.content.theme);
  state.audience = state.audience || { departments: [] };
  const editable = state.editable;

  const canvas = $("#canvas");
  const props = $("#props");
  let selectedId = null;
  let changeSeq = 0;
  let savedSeq = 0;
  let saving = false;
  let autosaveTimer = null;
  const history = [];

  const FONTS = {
    system: "-apple-system, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif",
    georgia: "Georgia, 'Times New Roman', serif",
    verdana: "Verdana, Geneva, sans-serif",
    trebuchet: "'Trebuchet MS', Helvetica, sans-serif",
  };
  const LABELS = {
    header: "Header", heading: "Heading", text: "Text", image: "Image", button: "Button",
    columns: "2 columns", divider: "Divider", spacer: "Spacer", footer: "Footer", stats: "Stats",
    insight: "Callout", bars: "Bar chart", table: "Table", share: "Share bar",
  };
  // Property panel definitions: [field, kind, label, extra]
  const FIELDS = {
    header: [["eyebrow", "text", "Small label above the title (optional)"], ["title", "text", "Title"], ["subtitle", "text", "Subtitle"],
      ["bg_color", "color?", "Background", "Brand color"], ["text_color", "color", "Text color"]],
    heading: [["text", "text", "Text"], ["level", "select", "Size", [[1, "Large"], [2, "Medium"], [3, "Small"]]],
      ["align", "align", "Alignment"]],
    text: [["align", "align", "Alignment"]],
    image: [["src", "url", "Image URL", "https://…/photo.jpg"], ["alt", "text", "Alt text (describe the image)"],
      ["href", "url", "Link when clicked (optional)", "https://…"], ["width", "range", "Width (%)", [10, 100]]],
    button: [["label", "text", "Label"], ["href", "url", "Link URL", "https://…"], ["align", "align", "Alignment"],
      ["color", "color?", "Button color", "Brand color"], ["text_color", "color", "Label color"]],
    columns: [],
    divider: [],
    spacer: [["height", "range", "Height (px)", [4, 120]]],
    footer: [["style", "select", "Style", [["light", "Light"], ["dark", "Dark"]]]],
    stats: [["title", "text", "Section title (optional)"], ["subtitle", "text", "Subtitle (optional)"],
      ["columns", "select", "Cards per row", [[0, "Automatic"], [2, "2"], [3, "3"], [4, "4"]]],
      ["align", "select", "Card style", [["center", "Centered"], ["left", "Dashboard (tinted, left-aligned)"]]],
      ["color", "color?", "Number color", "Brand color"]],
    insight: [["label", "text", "Label"]],
    bars: [["title", "text", "Title"], ["subtitle", "text", "Subtitle"], ["color", "color?", "Bar color", "Brand color"]],
    table: [["title", "text", "Title"], ["subtitle", "text", "Subtitle"]],
    share: [["title", "text", "Title"], ["subtitle", "text", "Subtitle"]],
  };
  const MAX_STATS = 8;
  const DATA_TYPES = new Set(["bars", "table", "share"]);
  const RICH = new Set(["text", "columns", "footer", "insight"]);
  const BLOCK_ICONS = {
    header: "panel-top", heading: "heading", text: "text", image: "image", button: "button",
    columns: "columns", divider: "minus", spacer: "move-vertical", footer: "panel-bottom", stats: "hash",
    insight: "lightbulb", bars: "chart", table: "list", share: "chart",
  };
  const ic = (name, size = 16) => window.svgIcon(name, size);

  // ---------- helpers ----------
  const uid = () => "b" + Math.random().toString(16).slice(2, 12);
  const clone = (o) => JSON.parse(JSON.stringify(o));
  const blocks = () => state.content.blocks;
  const findIndex = (id) => blocks().findIndex((b) => b.id === id);
  const getPath = (obj, path) => path.split(".").reduce((o, k) => (o == null ? o : o[k]), obj);
  function setPath(obj, path, value) {
    const keys = path.split(".");
    const last = keys.pop();
    keys.reduce((o, k) => o[k], obj)[last] = value;
  }
  function h(tag, attrs = {}, ...children) {
    const el = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs)) {
      if (v === null || v === undefined || v === false) continue;
      if (k === "class") el.className = v;
      else if (k === "style" && typeof v === "object") Object.assign(el.style, v);
      else if (k.startsWith("on")) el.addEventListener(k.slice(2), v);
      else el.setAttribute(k, v === true ? "" : v);
    }
    for (const c of children.flat()) if (c !== null && c !== undefined) el.append(c);
    return el;
  }

  // ---------- dirty tracking / save ----------
  function setSaveState(text, kind = "") {
    const el = $("#save-state");
    const name = { error: "alert", saving: "undo", dirty: "pencil", readonly: "lock" }[kind] || "cloud-check";
    const label = document.createElement("span");
    label.textContent = text;
    el.replaceChildren(ic(name, 15), label);
    el.className = "save-state" + (kind === "error" ? " error-text" : kind === "saving" ? " saving" : "");
    el.title = text;
  }
  function markDirty() {
    if (!editable) return;
    scheduleReview();
    changeSeq++;
    setSaveState("Unsaved changes", "dirty");
    clearTimeout(autosaveTimer);
    autosaveTimer = setTimeout(save, 2500);
  }
  const isDirty = () => changeSeq !== savedSeq;

  function payload() {
    return {
      name: state.name, subject: state.subject, preheader: state.preheader,
      content: state.content, audience: state.audience, ai_prompt: $("#ai-prompt").value,
      cc: state.cc, bcc: state.bcc,
    };
  }

  async function save() {
    if (!editable) return true;
    if (saving) { clearTimeout(autosaveTimer); autosaveTimer = setTimeout(save, 800); return false; }
    clearTimeout(autosaveTimer);
    saving = true;
    const seq = changeSeq;
    setSaveState("Saving…", "saving");
    try {
      await api(cfg.urls.save, payload());
      savedSeq = seq;
      if (isDirty()) setSaveState("Unsaved changes", "dirty");
      else setSaveState("Saved " + new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }));
      return true;
    } catch (e) {
      setSaveState("Save failed", "error");
      toast("Couldn't save: " + e.message, "error");
      return false;
    } finally {
      saving = false;
    }
  }
  window.addEventListener("beforeunload", (e) => { if (isDirty()) { e.preventDefault(); e.returnValue = ""; } });

  // ---------- undo ----------
  // One undo step per structural change, and one per field edit session (consecutive edits of the
  // same field collapse into a single step; switching to another field starts a new one).
  let lastHistoryKey = null;
  function pushHistory(key = null) {
    if (key && key === lastHistoryKey) return;
    lastHistoryKey = key;
    history.push(JSON.stringify({ subject: state.subject, preheader: state.preheader, content: state.content }));
    if (history.length > 50) history.shift();
    $("#btn-undo").disabled = false;
  }
  function undo() {
    const snap = history.pop();
    if (!snap) return;
    Object.assign(state, JSON.parse(snap));
    $("#btn-undo").disabled = history.length === 0;
    if (selectedId && findIndex(selectedId) < 0) selectedId = null;
    renderAll();
    markDirty();
  }

  // ---------- block operations ----------
  function makeBlock(type) {
    return Object.assign({ id: uid(), type }, clone(cfg.blockDefaults[type] || {}));
  }
  function insertBlock(type, index, fields) {
    pushHistory();
    const block = Object.assign(makeBlock(type), fields || {});
    const list = blocks();
    if (index === undefined) {
      const sel = findIndex(selectedId);
      index = sel >= 0 ? sel + 1 : list.length;
    }
    list.splice(index, 0, block);
    selectedId = block.id;
    renderCanvas();
    renderProps();
    markDirty();
    const el = canvas.querySelector(`[data-id="${block.id}"]`);
    el && el.scrollIntoView({ block: "nearest", behavior: "smooth" });
  }
  function moveBlock(id, toIndex) {
    const list = blocks();
    const from = findIndex(id);
    if (from < 0) return;
    if (toIndex > from) toIndex--;
    if (toIndex === from) return;
    pushHistory();
    const [b] = list.splice(from, 1);
    list.splice(Math.max(0, Math.min(list.length, toIndex)), 0, b);
    renderCanvas();
    markDirty();
  }
  function duplicateBlock(id) {
    const i = findIndex(id);
    if (i < 0) return;
    pushHistory();
    const copy = Object.assign(clone(blocks()[i]), { id: uid() });
    blocks().splice(i + 1, 0, copy);
    selectedId = copy.id;
    renderCanvas();
    renderProps();
    markDirty();
  }
  function deleteBlock(id) {
    const i = findIndex(id);
    if (i < 0) return;
    pushHistory();
    blocks().splice(i, 1);
    if (selectedId === id) selectedId = null;
    renderCanvas();
    renderProps();
    markDirty();
  }
  function select(id) {
    if (selectedId === id) return;
    selectedId = id;
    $$(".blk", canvas).forEach((el) => el.classList.toggle("selected", el.dataset.id === id));
    renderProps();
  }

  // ---------- canvas rendering ----------
  function applyTheme() {
    const t = state.content.theme;
    const wrap = $(".ed-canvas-wrap");
    wrap.style.setProperty("--e-bg", t.background);
    canvas.style.setProperty("--e-brand", t.brand_color);
    canvas.style.setProperty("--e-content-bg", t.content_bg);
    canvas.style.setProperty("--e-text", t.text_color);
    canvas.style.setProperty("--e-font", FONTS[t.font] || FONTS.system);
  }

  function editableField(tag, block, field, { rich = false, cls = "", placeholder = "", style = null } = {}) {
    const el = h(tag, { class: `${cls} ${rich ? "rte" : "plain"}`.trim(), "data-field": field, "data-placeholder": placeholder, style });
    if (rich) el.innerHTML = getPath(block, field) || "";
    else el.textContent = getPath(block, field) || "";
    if (editable) el.contentEditable = "true";
    return el;
  }

  function blockBody(b) {
    switch (b.type) {
      case "header":
        return h("div", { class: "b-header", style: { background: b.bg_color || "var(--e-brand)", color: b.text_color } },
          editableField("div", b, "eyebrow", { cls: "b-header-eyebrow", placeholder: "LABEL (optional)" }),
          editableField("div", b, "title", { cls: "b-header-title", placeholder: "Newsletter title" }),
          editableField("div", b, "subtitle", { cls: "b-header-sub", placeholder: "Subtitle (optional)" }));
      case "heading":
        return h("div", { class: "b-pad", style: { textAlign: b.align } },
          editableField("div", b, "text", { cls: `b-h${b.level}`, placeholder: "Heading" }));
      case "text":
        return h("div", { class: "b-pad", style: { textAlign: b.align } },
          editableField("div", b, "html", { rich: true, placeholder: "Write text…" }));
      case "image":
        return h("div", { class: "b-pad b-center" },
          b.src
            ? h("img", { src: b.src, alt: b.alt, style: { width: b.width + "%" }, class: "b-img" })
            : h("div", { class: "b-img-ph" }, ic("image", 26), h("strong", {}, b.alt || "Image"),
                h("small", {}, "Add the image URL in the properties panel")));
      case "button":
        return h("div", { class: "b-pad", style: { textAlign: b.align } },
          h("span", { class: "b-btn" + (b.href ? "" : " needs-link"), style: { background: b.color || "var(--e-brand)", color: b.text_color } },
            editableField("span", b, "label", { placeholder: "Button" })));
      case "columns":
        return h("div", { class: "b-pad b-cols" },
          editableField("div", b, "left_html", { rich: true, cls: "b-col", placeholder: "Left column…" }),
          editableField("div", b, "right_html", { rich: true, cls: "b-col", placeholder: "Right column…" }));
      case "divider":
        return h("div", { class: "b-pad" }, h("hr", { class: "b-hr" }));
      case "spacer":
        return h("div", { class: "b-spacer", style: { height: b.height + "px" } });
      case "footer":
        return h("div", { class: "b-footer" + (b.style === "dark" ? " dark" : "") },
          editableField("div", b, "html", { rich: true, placeholder: "Footer text…" }));
      case "stats": {
        const color = b.color || "var(--e-brand)";
        const cols = b.columns || Math.min(b.items.length, 4);
        const left = b.align === "left";
        const cards = b.items.map((it, i) => {
          const label = editableField("div", b, `items.${i}.label`, { cls: "b-stat-label", placeholder: "What it measures" });
          const value = editableField("div", b, `items.${i}.value`, { cls: "b-stat-value", placeholder: "00", style: { color } });
          const note = editableField("div", b, `items.${i}.note`, { cls: "b-stat-note", placeholder: "Note (optional)" });
          const delta = it.delta ? h("div", { class: "b-stat-delta" + (it.good === true ? " good" : it.good === false ? " bad" : "") },
            (it.trend === "up" ? "▲ " : it.trend === "down" ? "▼ " : "• ") + it.delta) : null;
          return h("div", { class: "b-stat" + (left ? " left" : "") + (b.size === "large" ? " large" : ""), style: { borderTopColor: color } },
            ...(left ? [label, value, delta, note] : [value, delta, label, note]));
        });
        return h("div", { class: "b-pad b-stats-wrap" }, sectionTitle(b),
          h("div", { class: `b-stats c${cols}`, style: { gridTemplateColumns: `repeat(${cols}, minmax(0, 1fr))` } }, ...cards));
      }
      case "insight":
        return h("div", { class: "b-pad" }, h("div", { class: "b-insight" },
          editableField("div", b, "label", { cls: "b-insight-label", placeholder: "LABEL" }),
          editableField("div", b, "html", { rich: true, placeholder: "Write the key takeaway…" })));
      case "bars": {
        const max = Math.max(0, ...b.items.map((it) => it.value)) || 1;
        const color = b.color || "var(--e-brand)";
        return h("div", { class: "b-pad b-data" }, sectionTitle(b), h("div", { class: "b-bars" }, ...b.items.map((it) =>
          h("div", { class: "b-bar-row" }, h("span", { class: "b-bar-label" }, it.label),
            h("span", { class: "b-bar-track" }, h("span", { class: "b-bar-fill", style: { width: `${(it.value / max) * 100}%`, background: color } })),
            h("span", { class: "b-bar-val" }, it.display)))));
      }
      case "share": {
        const total = b.items.reduce((a, it) => a + it.value, 0) || 1;
        const shade = (i) => ["var(--e-brand)", "color-mix(in srgb, var(--e-brand) 50%, var(--e-content-bg))", "color-mix(in srgb, var(--e-text) 18%, var(--e-content-bg))"][i] || "#cbd5e1";
        return h("div", { class: "b-pad b-data" }, sectionTitle(b),
          h("div", { class: "b-share-bar" }, ...b.items.filter((it) => it.value > 0).map((it, i) =>
            h("span", { style: { width: `${(it.value / total) * 100}%`, background: shade(i) } }))),
          h("div", { class: "b-share-legend" }, ...b.items.map((it, i) => h("div", { class: "b-share-row" },
            h("i", { style: { background: shade(b.items.filter((x) => x.value > 0).indexOf(it)) } }),
            h("span", {}, it.label), h("strong", {}, `${((it.value / total) * 100).toFixed(1)}%`), h("small", {}, it.display)))));
      }
      case "table":
        return h("div", { class: "b-pad b-data" }, sectionTitle(b), h("div", { class: "b-table-wrap" }, h("table", { class: "b-table" },
          h("thead", {}, h("tr", {}, ...b.columns.map((c) => h("th", {}, c)))),
          h("tbody", {}, ...b.rows.map((row, ri) => h("tr", {}, ...row.map((cell, ci) => h("td", {}, cell,
            ci === 0 && b.bars && b.bars.length ? h("span", { class: "b-cell-bar" }, h("span", { style: { width: `${b.bars[ri] * 100}%` } })) : null))))))));
    }
    return h("div", {}, "Unknown block");
  }

  // Title + subtitle above stats and data blocks (editable in place; empty ones hide unless the block is selected).
  function sectionTitle(b) {
    return h("div", { class: "b-sec" }, h("div", { class: "b-sec-accent" }),
      editableField("div", b, "title", { cls: "b-sec-title", placeholder: "Section title (optional)" }),
      editableField("div", b, "subtitle", { cls: "b-sec-sub", placeholder: "Subtitle (optional)" }));
  }

  function blockToolbar(b) {
    const btn = (icon, title, fn) => h("button", {
      type: "button", title, "aria-label": title, class: "blk-tool",
      onclick: (e) => { e.stopPropagation(); fn(); },
    }, ic(icon, 15));
    return h("div", { class: "blk-tools" },
      h("span", { class: "blk-handle", title: "Drag to move" }, ic("grip", 14), LABELS[b.type]),
      btn("chevron-up", "Move up", () => moveBlock(b.id, findIndex(b.id) - 1)),
      btn("chevron-down", "Move down", () => moveBlock(b.id, findIndex(b.id) + 2)),
      btn("copy", "Duplicate", () => duplicateBlock(b.id)),
      btn("trash", "Delete", () => deleteBlock(b.id)));
  }

  function renderCanvas() {
    applyTheme();
    canvas.replaceChildren();
    const sheet = h("div", { class: "ed-sheet" + (editable ? "" : " readonly") });
    if (!blocks().length) {
      sheet.append(h("div", { class: "ed-empty" },
        h("div", { class: "empty-art" }, ic("sparkles", 30)),
        h("strong", {}, editable ? "Your newsletter starts here" : "This newsletter is empty"),
        h("p", {}, editable ? "Describe your update to the AI writer, or drag blocks in from the Blocks tab." : ""),
        editable ? h("div", { class: "ed-empty-actions" },
          h("button", { type: "button", class: "btn btn-gradient btn-sm", onclick: () => { showTab("ai"); aiPrompt.focus(); } }, ic("sparkles", 15), "Write with AI"),
          h("button", { type: "button", class: "btn btn-sm", onclick: () => showTab("blocks") }, ic("grid", 15), "Add blocks")) : null));
    }
    for (const b of blocks()) {
      const wrapper = h("div", { class: "blk" + (b.id === selectedId ? " selected" : ""), "data-id": b.id });
      if (editable) wrapper.append(blockToolbar(b));
      wrapper.append(blockBody(b));
      sheet.append(wrapper);
    }
    sheet.append(h("div", { class: "drop-line", hidden: true }));
    canvas.append(sheet);
  }

  // ---------- properties panel ----------
  function field(label, input, hint) {
    return h("div", { class: "field" }, h("label", {}, label), input,
      hint ? h("div", { class: "field-hint warn" }, ic("alert", 13), hint) : null);
  }

  function refreshBlock(b) {
    const el = canvas.querySelector(`[data-id="${b.id}"]`);
    if (el) el.replaceChild(blockBody(b), el.lastElementChild);
  }
  function updateBlock(b, key, value, rerender = true) {
    setPath(b, key, value);
    if (rerender) refreshBlock(b);
    markDirty();
  }

  // Stats block: one row of inputs per figure, plus add / remove / fill from studio numbers.
  function statsEditor(b) {
    const wrap = h("div", { class: "stats-edit" });
    const TRENDS = [["", "No arrow"], ["up:good", "▲ up, good"], ["up:bad", "▲ up, bad"], ["down:good", "▼ down, good"],
      ["down:bad", "▼ down, bad"], ["flat:", "• no change"]];
    const trendSelect = (it, i) => {
      const now = it.trend ? `${it.trend}:${it.good === true ? "good" : it.good === false ? "bad" : ""}` : "";
      const sel = h("select", { disabled: !editable, "aria-label": `Arrow for figure ${i + 1}` },
        ...TRENDS.map(([v, l]) => h("option", { value: v, selected: v === now }, l)));
      sel.addEventListener("change", () => {
        pushHistory();
        const [trend, mood] = sel.value.split(":");
        it.trend = trend || "";
        it.good = mood === "good" ? true : mood === "bad" ? false : null;
        refreshBlock(b);
        markDirty();
      });
      return sel;
    };
    b.items.forEach((it, i) => {
      const input = (key, placeholder, max) => {
        const el = h("input", { type: "text", value: it[key] || "", placeholder, maxlength: max, "data-prop": `items.${i}.${key}`, disabled: !editable });
        el.addEventListener("focus", () => pushHistory(`prop:${b.id}:items.${i}.${key}`));
        el.addEventListener("input", () => updateBlock(b, `items.${i}.${key}`, el.value));
        return el;
      };
      wrap.append(h("div", { class: "stat-row" },
        h("div", { class: "stat-row-head" }, h("span", { class: "stat-dot", style: { background: b.color || state.content.theme.brand_color } }),
          h("strong", {}, `Figure ${i + 1}`),
          editable && b.items.length > 1 ? h("button", { type: "button", class: "btn btn-ghost btn-icon btn-xs", title: "Remove figure", "aria-label": `Remove figure ${i + 1}`,
            onclick: () => { pushHistory(); b.items.splice(i, 1); refreshBlock(b); renderProps(); markDirty(); } }, ic("trash", 13)) : null),
        h("div", { class: "stat-row-fields" }, input("value", "12%", 24), input("label", "Revenue above target", 80)),
        input("note", "Note, e.g. up from 9% in Q2 (optional)", 100),
        h("div", { class: "stat-row-fields" }, input("delta", "Change, e.g. +3.2pp", 20), trendSelect(it, i))));
    });
    if (editable) {
      wrap.append(h("div", { class: "row wrap", style: { marginTop: "10px" } },
        b.items.length < MAX_STATS ? h("button", { type: "button", class: "btn btn-sm", onclick: () => {
          pushHistory(); b.items.push({ value: "", label: "", note: "" }); refreshBlock(b); renderProps(); markDirty();
        } }, ic("plus", 14), "Add figure") : null,
        h("button", { type: "button", class: "btn btn-soft btn-sm", onclick: () => openFacts(b.id) }, ic("database", 14), "Fill from studio numbers")));
    }
    return wrap;
  }

  function renderProps() {
    props.replaceChildren();
    const i = findIndex(selectedId);
    if (i < 0) {
      props.append(h("div", { class: "props-empty" },
        h("div", { class: "empty-art" }, ic("pencil", 24)),
        h("h3", {}, "Nothing selected"),
        h("p", {}, "Click a block in the email to change its settings. Click any text to edit it in place.")));
      return;
    }
    const b = blocks()[i];
    props.append(h("div", { class: "props-head" },
      h("span", { class: "pi" }, ic(BLOCK_ICONS[b.type], 17)),
      h("div", {}, h("h3", {}, LABELS[b.type]), h("small", {}, `Block ${i + 1} of ${blocks().length}`))));
    for (const [key, kind, label, extra] of FIELDS[b.type]) {
      let input;
      if (kind === "text" || kind === "url") {
        input = h("input", { type: kind === "url" ? "url" : "text", value: b[key] || "", placeholder: extra || "", "data-prop": key, disabled: !editable });
        input.addEventListener("input", () => updateBlock(b, key, input.value));
        input.addEventListener("focus", () => pushHistory(`prop:${b.id}:${key}`));
      } else if (kind === "select") {
        const numeric = typeof extra[0][0] === "number";
        input = h("select", { disabled: !editable }, ...extra.map(([v, l]) => h("option", { value: v, selected: String(b[key] ?? "") === String(v) }, l)));
        input.addEventListener("change", () => { pushHistory(); updateBlock(b, key, numeric ? Number(input.value) : input.value); });
      } else if (kind === "align") {
        input = h("div", { class: "seg seg-sm" }, ...["left", "center", "right"].map((a) =>
          h("label", {}, h("input", { type: "radio", name: "align-" + b.id, value: a, checked: b[key] === a, disabled: !editable,
            onchange: () => { pushHistory(); updateBlock(b, key, a); } }), a[0].toUpperCase() + a.slice(1))));
      } else if (kind === "range") {
        const [min, max] = extra;
        const out = h("code", {}, String(b[key]));
        const r = h("input", { type: "range", min, max, value: b[key], disabled: !editable });
        r.addEventListener("input", () => { out.textContent = r.value; updateBlock(b, key, Number(r.value)); });
        input = h("div", { class: "row" }, r, out);
      } else if (kind === "color" || kind === "color?") {
        const c = h("input", { type: "color", value: b[key] || state.content.theme.brand_color, disabled: !editable });
        c.addEventListener("input", () => updateBlock(b, key, c.value));
        input = h("div", { class: "color-row" }, c);
        if (kind === "color?") {
          input.append(h("button", { type: "button", class: "btn btn-soft btn-xs", disabled: !editable,
            onclick: () => { updateBlock(b, key, ""); c.value = state.content.theme.brand_color; } }, "Use " + extra.toLowerCase()));
        }
      }
      props.append(field(label, input,
        key === "href" && b.type === "button" && !b.href ? "Required before sending." :
        key === "src" && !b.src ? "Paste a public image URL. Required before sending." : null));
    }
    if (DATA_TYPES.has(b.type) || b.from_data) {
      props.append(h("div", { class: "tip-box" }, ic("database", 15),
        h("span", {}, DATA_TYPES.has(b.type)
          ? "Built from your data, so the numbers can't be edited here. To refresh them, build it again in AI writer → Use your data."
          : "Built from your data. You can adjust the text; build it again in AI writer → Use your data to refresh the numbers.")));
    }
    if (b.type === "stats") {
      props.append(statsEditor(b));
      props.append(h("div", { class: "tip-box" }, ic("info", 15),
        h("span", {}, "Use real figures only. Keep values short (12%, 18, 4.7/5) so they fit side by side on phones.")));
    }
    if (RICH.has(b.type) || b.type === "heading" || b.type === "header") {
      props.append(h("div", { class: "tip-box" }, ic("info", 15),
        h("span", {}, "Edit the text directly in the email. Type {{first_name}} to greet each employee by name.")));
    }
    if (editable) {
      props.append(h("div", { class: "props-actions" },
        h("button", { type: "button", class: "btn btn-sm", onclick: () => duplicateBlock(b.id) }, ic("copy", 14), "Duplicate"),
        h("button", { type: "button", class: "btn btn-danger-ghost btn-sm", onclick: () => deleteBlock(b.id) }, ic("trash", 14), "Delete")));
    }
  }

  // ---------- inline editing ----------
  canvas.addEventListener("click", (e) => {
    const blk = e.target.closest(".blk");
    if (blk) select(blk.dataset.id);
  });
  canvas.addEventListener("focusin", (e) => {
    if (e.target.matches("[data-field]")) pushHistory(`field:${e.target.closest(".blk").dataset.id}:${e.target.dataset.field}`);
    $("#fmt-bar").classList.toggle("active", !!e.target.closest(".rte"));
  });
  canvas.addEventListener("focusout", () => setTimeout(() => {
    if (!document.activeElement?.closest?.(".rte")) $("#fmt-bar").classList.remove("active");
  }, 0));
  canvas.addEventListener("input", (e) => {
    const el = e.target.closest("[data-field]");
    if (!el) return;
    const b = blocks()[findIndex(el.closest(".blk").dataset.id)];
    const key = el.dataset.field;
    setPath(b, key, el.classList.contains("rte") ? el.innerHTML : el.textContent.replace(/\s+/g, " ").trim());
    const mirror = props.querySelector(`[data-prop="${key}"]`);
    if (mirror && b.id === selectedId) mirror.value = getPath(b, key);
    markDirty();
  });
  canvas.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && e.target.classList?.contains("plain")) e.preventDefault();
  });
  // Paste as plain text so formatting from Word/web pages doesn't leak into emails.
  canvas.addEventListener("paste", (e) => {
    if (!e.target.closest("[data-field]")) return;
    e.preventDefault();
    const text = (e.clipboardData || window.clipboardData).getData("text/plain");
    document.execCommand("insertText", false, text);
  });

  $$("#fmt-bar button").forEach((btn) => {
    btn.addEventListener("mousedown", (e) => e.preventDefault()); // keep the text selection
    btn.addEventListener("click", () => {
      if (!document.activeElement?.closest?.(".rte")) return;
      const cmd = btn.dataset.cmd;
      if (cmd === "createLink") {
        const url = window.prompt("Link URL (https://…)", "https://");
        if (!url || !/^(https?:\/\/|mailto:)/i.test(url)) return;
        document.execCommand("createLink", false, url);
      } else {
        document.execCommand(cmd, false, null);
      }
      document.activeElement.dispatchEvent(new Event("input", { bubbles: true }));
    });
  });

  // ---------- drag and drop ----------
  let drag = null; // {kind: "new", type} while a palette item is being dragged

  $$(".pal-item").forEach((item) => {
    item.addEventListener("dragstart", (e) => {
      drag = { kind: "new", type: item.dataset.type };
      e.dataTransfer.setData("text/plain", item.dataset.type);
      e.dataTransfer.effectAllowed = "copy";
    });
    item.addEventListener("dragend", endDrag);
    item.addEventListener("click", () => editable && insertBlock(item.dataset.type));
  });

  // Reordering existing blocks uses pointer events rather than native drag-and-drop: native drags
  // don't reliably start right after a contenteditable loses focus, and pointer events also work on touch.
  canvas.addEventListener("pointerdown", (e) => {
    const handle = e.target.closest(".blk-handle");
    if (!handle || !editable || e.button !== 0) return;
    e.preventDefault();
    if (document.activeElement && document.activeElement !== document.body) document.activeElement.blur();
    const blk = handle.closest(".blk");
    const startY = e.clientY;
    const wrap = $(".ed-canvas-wrap");
    let moved = false;
    handle.setPointerCapture(e.pointerId);

    const onMove = (ev) => {
      if (!moved) {
        if (Math.abs(ev.clientY - startY) < 4) return;
        moved = true;
        blk.classList.add("dragging");
        document.body.classList.add("reordering");
      }
      const r = wrap.getBoundingClientRect();
      if (ev.clientY < r.top + 48) wrap.scrollTop -= 14;
      else if (ev.clientY > r.bottom - 48) wrap.scrollTop += 14;
      showDropLine(dropIndex(ev.clientY));
    };
    const finish = (ev, commit) => {
      handle.removeEventListener("pointermove", onMove);
      handle.removeEventListener("pointerup", onUp);
      handle.removeEventListener("pointercancel", onCancel);
      document.body.classList.remove("reordering");
      endDrag();
      if (moved && commit) moveBlock(blk.dataset.id, dropIndex(ev.clientY));
    };
    const onUp = (ev) => finish(ev, true);
    const onCancel = (ev) => finish(ev, false);
    handle.addEventListener("pointermove", onMove);
    handle.addEventListener("pointerup", onUp);
    handle.addEventListener("pointercancel", onCancel);
  });

  function dropIndex(clientY) {
    const els = $$(".blk", canvas);
    for (let i = 0; i < els.length; i++) {
      const r = els[i].getBoundingClientRect();
      if (clientY < r.top + r.height / 2) return i;
    }
    return els.length;
  }
  function showDropLine(index) {
    const line = $(".drop-line", canvas);
    const els = $$(".blk", canvas);
    let top = 8;
    if (els.length) top = index < els.length ? els[index].offsetTop - 2 : els[els.length - 1].offsetTop + els[els.length - 1].offsetHeight + 2;
    line.style.top = top + "px";
    line.hidden = false;
  }
  function endDrag() {
    drag = null;
    const line = $(".drop-line", canvas);
    if (line) line.hidden = true;
    $$(".blk", canvas).forEach((b) => b.classList.remove("dragging"));
  }
  canvas.addEventListener("dragover", (e) => {
    if (!drag || !editable) return;
    e.preventDefault();
    e.dataTransfer.dropEffect = drag.kind === "new" ? "copy" : "move";
    showDropLine(dropIndex(e.clientY));
  });
  canvas.addEventListener("dragleave", (e) => {
    if (!canvas.contains(e.relatedTarget)) { const l = $(".drop-line", canvas); if (l) l.hidden = true; }
  });
  canvas.addEventListener("drop", (e) => {
    if (!drag || !editable) return;
    e.preventDefault();
    const index = dropIndex(e.clientY);
    const d = drag;
    endDrag();
    insertBlock(d.type, index);
  });

  // ---------- left panel: tabs, style ----------
  function showTab(name) {
    $$(".ed-tab").forEach((t) => t.classList.toggle("active", t.dataset.tab === name));
    $$(".ed-left .panel[data-panel]").forEach((p) => (p.hidden = p.dataset.panel !== name));
    if (name === "tips") runReview();
  }
  $$(".ed-tab").forEach((tab) => tab.addEventListener("click", () => showTab(tab.dataset.tab)));

  // Theme presets
  function markPreset() {
    const t = state.content.theme;
    $$(".preset").forEach((p) => {
      const v = JSON.parse(p.dataset.preset);
      p.classList.toggle("active", v.brand_color === t.brand_color && v.background === t.background);
    });
  }
  $$(".preset").forEach((p) => {
    p.disabled = !editable;
    p.addEventListener("click", () => {
      pushHistory();
      Object.assign(state.content.theme, JSON.parse(p.dataset.preset));
      $$("[data-theme-key]").forEach((input) => (input.value = state.content.theme[input.dataset.themeKey]));
      renderCanvas();
      markPreset();
      markDirty();
    });
  });

  // Desktop / mobile canvas
  $$('input[name="canvas-size"]').forEach((r) => r.addEventListener("change", () => {
    canvas.classList.toggle("mobile", r.checked && r.value === "mobile");
  }));

  $$("[data-theme-key]").forEach((input) => {
    input.value = state.content.theme[input.dataset.themeKey];
    input.disabled = !editable;
    input.addEventListener("focus", () => pushHistory(`theme:${input.dataset.themeKey}`));
    input.addEventListener("input", () => {
      state.content.theme[input.dataset.themeKey] = input.value;
      if (input.dataset.themeKey === "font") renderCanvas(); else applyTheme();
      markPreset();
      markDirty();
    });
  });

  // ---------- meta fields ----------
  [["#f-name", "name"], ["#f-subject", "subject"], ["#f-preheader", "preheader"]].forEach(([sel, key]) => {
    const input = $(sel);
    input.value = state[key] || "";
    input.disabled = !editable;
    if (key !== "name") input.addEventListener("focus", () => pushHistory(`meta:${key}`)); // part of undo snapshots
    input.addEventListener("input", () => { state[key] = input.value; markDirty(); });
  });
  function syncMetaInputs() {
    $("#f-subject").value = state.subject || "";
    $("#f-preheader").value = state.preheader || "";
  }

  // ---------- AI generation ----------
  const aiPrompt = $("#ai-prompt");
  aiPrompt.value = state.ai_prompt || "";
  if (!editable) { aiPrompt.disabled = true; $("#ai-generate").disabled = true; }
  if (blocks().length) $('input[name="ai-mode"][value="revise"]').checked = true;

  const useData = $("#ai-use-data");
  try { useData.checked = localStorage.getItem("ns-ai-data") === "1"; } catch (_) { /* storage unavailable */ }
  useData.disabled = !editable;
  useData.addEventListener("change", () => { try { localStorage.setItem("ns-ai-data", useData.checked ? "1" : "0"); } catch (_) { /* ignore */ } });

  $$("#rec-starters .chip").forEach((chip) => chip.addEventListener("click", () => {
    aiPrompt.value = chip.dataset.prompt;
    $(`input[name="ai-mode"][value="${chip.dataset.mode}"]`).checked = true;
    if (chip.dataset.data) { useData.checked = true; useData.dispatchEvent(new Event("change")); }
    aiPrompt.focus();
  }));
  // "Refine the current draft" chips
  $$('.panel[data-panel="ai"] .chip[data-mode="revise"]').forEach((chip) => chip.addEventListener("click", () => {
    aiPrompt.value = chip.dataset.prompt;
    $('input[name="ai-mode"][value="revise"]').checked = true;
    aiPrompt.focus();
  }));

  // Studio numbers (shared by the AI writer's "What's included?" list and the Stats block filler)
  let factsCache = null;
  async function loadFacts() {
    if (!factsCache) factsCache = (await api(cfg.urls.facts, undefined, "GET")).facts;
    return factsCache;
  }
  $("#ai-data-what").addEventListener("click", async () => {
    const box = $("#ai-data-list");
    const btn = $("#ai-data-what");
    if (!box.hidden) { box.hidden = true; btn.setAttribute("aria-expanded", "false"); return; }
    btn.setAttribute("aria-expanded", "true");
    box.hidden = false;
    box.textContent = "Loading…";
    try {
      const facts = await loadFacts();
      const depts = facts.filter((f) => f.key.startsWith("dept:"));
      const lines = facts.filter((f) => !f.key.startsWith("dept:")).map((f) => `${f.label}: ${f.value}${f.note ? ` (${f.note})` : ""}`);
      if (depts.length) lines.push("Headcount: " + depts.map((f) => `${f.label.replace(/ team members$/, "")} ${f.value}`).join(", "));
      box.replaceChildren(h("p", { class: "muted small" }, "Real figures the AI may use. Only these totals are sent, never names or email addresses."),
        h("ul", {}, ...lines.map((l) => h("li", {}, l))));
    } catch (e) {
      box.textContent = "Couldn't load the studio numbers: " + e.message;
    }
  });

  async function generate() {
    const prompt = aiPrompt.value.trim();
    const status = $("#ai-status");
    if (!prompt) { status.className = "ai-status error-text"; status.textContent = "Describe what the newsletter should say first."; return; }
    const mode = $('input[name="ai-mode"]:checked').value;
    const btn = $("#ai-generate");
    btn.disabled = true;
    const btnHtml = btn.innerHTML;
    btn.textContent = "Writing…";
    status.className = "ai-status working";
    status.textContent = mode === "revise" ? "Revising your newsletter…" : "Writing your newsletter… this usually takes 20–60 seconds.";
    try {
      const res = await api(cfg.urls.generate, {
        prompt, mode, subject: state.subject, preheader: state.preheader, content: state.content,
        use_data: useData.checked,
      });
      pushHistory();
      state.subject = res.subject;
      state.preheader = res.preheader;
      state.content = res.content;
      if (mode !== "revise") state.from_data = false;
      selectedId = null;
      renderAll();
      markDirty();
      $('input[name="ai-mode"][value="revise"]').checked = true;
      status.className = "ai-status ok";
      status.textContent = "Done. Review it, fill any [placeholders], and edit freely. Undo restores the previous version.";
      toast("Draft ready. Review it and fill any [placeholders].", "success");
    } catch (e) {
      status.className = "ai-status error-text";
      status.textContent = e.message;
    } finally {
      btn.disabled = false;
      btn.innerHTML = btnHtml;
    }
  }
  $("#ai-generate").addEventListener("click", generate);
  aiPrompt.addEventListener("keydown", (e) => { if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) generate(); });

  // ---------- dialogs ----------
  $$("dialog [data-close]").forEach((b) => b.addEventListener("click", () => b.closest("dialog").close()));

  async function openPreview() {
    const dlg = $("#dlg-preview");
    $("#pv-subject").textContent = state.subject || "(no subject)";
    $("#pv-preheader").textContent = state.preheader ? "— " + state.preheader : "";
    try {
      const res = await api(cfg.urls.preview, { subject: state.subject, preheader: state.preheader, content: state.content });
      $("#pv-frame").srcdoc = res.html;
      dlg.showModal();
    } catch (e) {
      toast("Preview failed: " + e.message, "error");
    }
  }
  $$('input[name="pv-size"]').forEach((r) => r.addEventListener("change", () => {
    $(".pv-frame-wrap").classList.toggle("mobile", r.value === "mobile" && r.checked);
  }));
  $("#btn-preview").addEventListener("click", openPreview);

  // ---------- recipients: To (audience) / Cc / Bcc ----------
  state.cc = state.cc || [];
  state.bcc = state.bcc || [];
  const ccInput = chipInput($("#cc-input"), {
    values: state.cc, placeholder: "Add Cc…", disabled: !editable,
    onChange: (v) => { state.cc = v; markDirty(); },
  });
  const bccInput = chipInput($("#bcc-input"), {
    values: state.bcc, placeholder: "Add Bcc…", disabled: !editable,
    onChange: (v) => { state.bcc = v; markDirty(); },
  });
  $("#aud-pill").disabled = !editable;

  // Audience: {mode: "all"} | {mode: "departments", departments} | {mode: "employees", employee_ids}
  let audienceCount = null;
  if (!state.audience || !state.audience.mode) state.audience = { mode: "all" };
  let audiencePeople = state.audience_people || []; // details of hand-picked employees
  const plural = (n) => `${n} employee${n === 1 ? "" : "s"}`;
  const personName = (p) => (p.name || p.email) + (p.active === false ? " (paused)" : "");
  const hueOf = (s) => [...String(s || "")].reduce((a, c, i) => a + c.charCodeAt(0) * (i + 7), 0) % 360;
  const initialsOf = (s) => (String(s || "").replace(/\./g, " ").split(/\s+/)
    .filter((w) => /^[\p{L}\p{N}]/u.test(w)).slice(0, 2).map((w) => w[0]).join("") || "?").toUpperCase();
  function audienceText(aud = state.audience, people = audiencePeople) {
    if (aud.mode === "departments") return (aud.departments || []).join(", ") || "No departments selected";
    if (aud.mode === "employees") {
      const names = people.map((x) => x.name || x.email);
      if (!names.length) return "No one selected";
      return names.length <= 2 ? names.join(", ") : `${names.slice(0, 2).join(", ")} +${names.length - 2} more`;
    }
    return "All active employees";
  }
  async function fetchCount(aud) {
    return (await api(cfg.urls.count, { audience: aud })).count;
  }
  async function refreshAudiencePill() {
    $("#aud-summary").textContent = audienceText();
    try {
      audienceCount = await fetchCount(state.audience);
      $("#aud-num").textContent = audienceCount;
      $("#aud-pill").title = `To: ${audienceText()} (${plural(audienceCount)})`;
    } catch (_) { $("#aud-num").textContent = "?"; }
  }

  // Audience dialog ("To")
  const deptList = $("#dept-list");
  const empPicker = $("#emp-picker");
  let picked = new Map(); // working copy while the dialog is open: id -> person
  let empLoaded = false;
  let empResults = [];
  let searchTimer = null;
  let searchSeq = 0;
  let countSeq = 0;
  const dialogMode = () => $('input[name="aud"]:checked').value;
  function dialogAudience() {
    const mode = dialogMode();
    if (mode === "departments") return { mode, departments: $$('input[name="dept"]:checked').map((c) => c.value) };
    if (mode === "employees") return { mode, employee_ids: [...picked.keys()] };
    return { mode: "all" };
  }
  function syncModePanels() {
    const mode = dialogMode();
    deptList.hidden = mode !== "departments";
    empPicker.hidden = mode !== "employees";
    if (mode === "employees") {
      if (!empLoaded) searchPeople();
      setTimeout(() => $("#emp-search").focus(), 0);
    }
  }
  async function refreshDialogCount() {
    const el = $("#aud-count");
    const seq = ++countSeq;
    try {
      const n = await fetchCount(dialogAudience());
      if (seq !== countSeq) return;
      el.replaceChildren(ic("users", 15), document.createTextNode(`${plural(n)} will receive this newsletter`));
      el.hidden = false;
    } catch (_) { el.hidden = true; }
  }

  // Specific-employee picker
  function renderPicked() {
    $("#emp-selected").replaceChildren(...[...picked.values()].map((person) => h("span", { class: "chip-addr", title: person.email },
      personName(person),
      h("button", { type: "button", class: "chip-x", "aria-label": `Remove ${person.name || person.email}`,
        onclick: (e) => { e.stopPropagation(); togglePerson(person, false); } }, ic("x", 12)))));
  }
  // Email addresses typed (or pasted) in the search box that aren't in the list yet: offer to add them.
  const ONE_EMAIL = /^[^@\s,;<>"]+@[^@\s,;<>"]+\.[^@\s,;<>"]+$/;
  function newAddresses() {
    if (!cfg.canAddPeople) return [];  // only admins add employees
    const text = $("#emp-search").value.trim();
    if (!text.includes("@")) return [];
    const parts = text.split(/[\s,;]+/).filter(Boolean).map((p) => p.replace(/^<|>$/g, "").toLowerCase());
    if (!parts.length || !parts.every((p) => ONE_EMAIL.test(p))) return [];
    const known = new Set(empResults.map((p) => p.email.toLowerCase()));
    return [...new Set(parts)].filter((e) => !known.has(e));
  }
  function addRow(fresh) {
    return h("button", { type: "button", class: "emp-row emp-add", onclick: () => addAddresses(fresh) },
      h("span", { class: "emp-add-ico" }, ic("user-plus", 15)),
      h("span", { class: "person-text" },
        h("strong", {}, fresh.length === 1 ? `Add ${fresh[0]}` : `Add ${fresh.length} email addresses`),
        h("span", {}, "Not on the Employees page yet. Press Enter or click to add and select.")));
  }
  async function addAddresses(emails) {
    const st = $("#audience-status");
    try {
      const res = await api(cfg.urls.quickAdd, { emails });
      res.people.forEach((person) => picked.set(person.id, person));
      renderPicked();
      refreshDialogCount();
      $("#emp-search").value = "";
      await searchPeople();
      st.className = "status-box ok-text";
      st.textContent = (res.added ? `Added ${res.added} new employee${res.added === 1 ? "" : "s"} to the Employees page and selected ` : "Selected ")
        + `${res.people.length === 1 ? res.people[0].email : res.people.length + " people"}.` + (res.problems.length ? " " + res.problems.join(" ") : "");
      $("#emp-search").focus();
    } catch (e) {
      st.className = "status-box error-text";
      st.textContent = e.message;
    }
  }
  function renderResults() {
    const list = $("#emp-list");
    const fresh = newAddresses();
    if (!empResults.length) {
      list.replaceChildren(fresh.length ? addRow(fresh) : h("div", { class: "emp-empty" }, cfg.canAddPeople ? "No active employees match your search. Type their email address to add them."
        : "No active employees match your search. Ask an admin to add them, or use Cc / Bcc for a one-off copy."));
      return;
    }
    list.replaceChildren(...(fresh.length ? [addRow(fresh)] : []), ...empResults.map((person) => h("button", {
      type: "button", class: "emp-row", role: "option", "aria-selected": String(picked.has(person.id)), "data-id": person.id,
      onclick: () => togglePerson(person, !picked.has(person.id)),
    },
    h("span", { class: "box" }, ic("check", 13)),
    h("span", { class: "avatar avatar-sm", style: `--h: ${hueOf(person.email)}` }, initialsOf(person.name || person.email)),
    h("span", { class: "person-text" }, h("strong", {}, person.name || person.email), h("span", {}, person.email)),
    person.department ? h("span", { class: "chip-dept", style: `--h: ${hueOf(person.department)}` }, person.department) : null)));
  }
  function togglePerson(person, on) {
    if (on) picked.set(person.id, person); else picked.delete(person.id);
    const row = $(`#emp-list .emp-row[data-id="${person.id}"]`);
    if (row) row.setAttribute("aria-selected", String(on));
    renderPicked();
    refreshDialogCount();
  }
  async function searchPeople() {
    const seq = ++searchSeq;
    const params = new URLSearchParams({ q: $("#emp-search").value.trim(), department: $("#emp-dept").value, limit: 200 });
    try {
      const res = await api(cfg.urls.people + "?" + params, undefined, "GET");
      if (seq !== searchSeq) return;
      empLoaded = true;
      empResults = res.people;
      renderResults();
      $("#emp-found").textContent = res.total > res.people.length
        ? `Showing ${res.people.length} of ${res.total}. Search to narrow down.`
        : `${res.total} found`;
    } catch (e) {
      $("#emp-list").replaceChildren(h("div", { class: "emp-empty" }, "Couldn't load employees: " + e.message));
    }
  }
  $("#emp-search").addEventListener("input", () => { clearTimeout(searchTimer); searchTimer = setTimeout(searchPeople, 200); });
  $("#emp-search").addEventListener("keydown", (e) => {
    if (e.key !== "Enter") return;
    e.preventDefault();  // don't submit the dialog; Enter adds a typed email address that isn't in the list
    const fresh = newAddresses();
    if (fresh.length) addAddresses(fresh);
  });
  $("#emp-dept").addEventListener("change", searchPeople);
  $("#emp-select-shown").addEventListener("click", () => {
    empResults.forEach((person) => picked.set(person.id, person));
    renderResults(); renderPicked(); refreshDialogCount();
  });
  $("#emp-clear").addEventListener("click", () => { picked.clear(); renderResults(); renderPicked(); refreshDialogCount(); });

  function openAudience() {
    const aud = state.audience;
    $(`input[name="aud"][value="${aud.mode}"]`).checked = true;
    $$('input[name="dept"]').forEach((c) => (c.checked = (aud.departments || []).includes(c.value)));
    picked = new Map(audiencePeople.map((person) => [person.id, person]));
    renderPicked();
    $("#emp-search").value = "";
    $("#emp-dept").value = "";
    empLoaded = false;
    const st = $("#audience-status");
    st.className = "status-box";
    st.textContent = "";
    syncModePanels();
    refreshDialogCount();
    $("#dlg-audience").showModal();
  }
  $("#aud-pill").addEventListener("click", () => { if (editable) openAudience(); });
  $$('input[name="aud"]').forEach((r) => r.addEventListener("change", () => { syncModePanels(); refreshDialogCount(); }));
  $$('input[name="dept"]').forEach((c) => c.addEventListener("change", refreshDialogCount));
  $("#audience-form").addEventListener("submit", (e) => {
    e.preventDefault();
    const aud = dialogAudience();
    const st = $("#audience-status");
    const fail = (msg) => { st.className = "status-box error-text"; st.textContent = msg; };
    if (aud.mode === "departments" && !aud.departments.length) return fail("Pick at least one department.");
    if (aud.mode === "employees" && !aud.employee_ids.length) return fail("Pick at least one employee.");
    state.audience = aud;
    audiencePeople = aud.mode === "employees" ? [...picked.values()] : [];
    markDirty();
    refreshAudiencePill().then(renderScheduleSummary);
    $("#dlg-audience").close();
  });

  // Test email (To + optional Cc / Bcc, not saved with the newsletter)
  const testCc = chipInput($("#test-cc"), { placeholder: "Add Cc…" });
  const testBcc = chipInput($("#test-bcc"), { placeholder: "Add Bcc…" });
  $("#btn-test").addEventListener("click", () => { $("#test-status").textContent = ""; $("#test-status").className = "status-box"; $("#dlg-test").showModal(); });
  $("#test-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    const status = $("#test-status");
    if (!testCc.flush() || !testBcc.flush()) {
      status.className = "status-box error-text";
      status.textContent = "Fix the highlighted address first.";
      return;
    }
    const btn = $("#test-send");
    btn.disabled = true;
    status.className = "status-box";
    status.textContent = "Sending…";
    try {
      if (editable && isDirty() && !(await save())) throw new Error("Could not save the latest changes first.");
      const res = await api(cfg.urls.test, { email: $("#test-email").value, cc: testCc.get(), bcc: testBcc.get() });
      status.textContent = "";
      status.className = "status-box";
      $("#dlg-test").close();
      toast(res.message, "success");
    } catch (err) {
      status.className = "status-box error-text";
      status.textContent = err.message;
    } finally {
      btn.disabled = false;
    }
  });

  // Schedule dialog
  function addressChips(list) {
    if (!list.length) return [h("span", { class: "muted" }, "None")];
    return list.map((a) => h("span", { class: "chip-addr no-x", title: a }, a));
  }
  function audienceSummaryNodes() {
    const count = audienceCount == null ? null : h("span", { class: "muted" }, `· ${plural(audienceCount)}`);
    if (state.audience.mode !== "employees") return [audienceText(), count];
    const shown = audiencePeople.slice(0, 8).map((person) => h("span", { class: "chip-addr no-x", title: person.email }, personName(person)));
    const more = audiencePeople.length > 8 ? h("span", { class: "muted" }, `+${audiencePeople.length - 8} more`) : null;
    return [...shown, more, count];
  }
  function renderScheduleSummary() {
    $("#sched-summary").replaceChildren(
      h("dt", {}, "To"),
      h("dd", {}, ...audienceSummaryNodes()),
      h("dt", {}, "Cc"), h("dd", {}, ...addressChips(state.cc)),
      h("dt", {}, "Bcc"), h("dd", {}, ...addressChips(state.bcc)),
    );
  }
  $("#btn-schedule")?.addEventListener("click", () => {
    if (!ccInput.flush() || !bccInput.flush()) {
      toast("Fix the highlighted Cc/Bcc address before sending.", "error");
      return;
    }
    if (state.scheduled_at && new Date(state.scheduled_at) > new Date()) {
      $(`input[name="when"][value="${state.repeat ? "repeat" : "later"}"]`).checked = true;
      const d = new Date(state.scheduled_at);
      $("#send-at").value = new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 16);
    }
    if (state.repeat) $("#repeat-every").value = state.repeat;
    $("#repeat-until").value = state.repeat_until || "";
    $("#repeat-refresh-wrap").hidden = !state.from_data;
    if (state.from_data) $("#repeat-refresh").checked = state.repeat ? state.repeat_refresh : true;
    syncWhen();
    $("#schedule-status").textContent = "";
    $("#schedule-status").className = "status-box";
    renderScheduleSummary();
    refreshAudiencePill().then(renderScheduleSummary);
    $("#dlg-schedule").showModal();
  });
  $("#sched-edit-aud").addEventListener("click", openAudience);
  const toLocalInput = (d) => new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 16);
  function applyBestTime() {
    if (!cfg.bestTime) return;
    if ($('input[name="when"]:checked').value === "now") $('input[name="when"][value="later"]').checked = true;
    $("#send-at").value = toLocalInput(new Date(cfg.bestTime.at));
    syncWhen();
  }
  const ordinal = (n) => n + (n % 100 >= 11 && n % 100 <= 13 ? "th" : ({ 1: "st", 2: "nd", 3: "rd" }[n % 10] || "th"));
  function repeatSummary() {
    const v = $("#send-at").value;
    if (!v) return "Pick when the first one goes out.";
    const d = new Date(v);
    const time = d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    const every = $("#repeat-every").value;
    let text = every === "daily" ? `Every day at ${time}`
      : every === "weekly" ? `Every ${d.toLocaleDateString(undefined, { weekday: "long" })} at ${time}`
        : `Every month on the ${ordinal(d.getDate())} at ${time}` + (d.getDate() > 28 ? " (or the month's last day)" : "");
    text += `, starting ${d.toLocaleDateString(undefined, { day: "2-digit", month: "short", year: "numeric" })}`;
    const until = $("#repeat-until").value;
    text += until ? `, until ${new Date(until + "T00:00").toLocaleDateString(undefined, { day: "2-digit", month: "short", year: "numeric" })}.` : ", until you stop it.";
    return text;
  }
  function syncWhen() {
    const when = $('input[name="when"]:checked').value;
    $("#send-at-wrap").hidden = when === "now";
    $("#repeat-box").hidden = when !== "repeat";
    $("#send-at-label").textContent = when === "repeat" ? "First send" : "Send on";
    if (when !== "now" && !$("#send-at").value) {
      const d = new Date(Date.now() + 3600e3);
      d.setMinutes(0, 0, 0);
      $("#send-at").value = toLocalInput(d);
    }
    $("#repeat-summary").textContent = when === "repeat" ? repeatSummary() : "";
    $("#schedule-go").replaceChildren(ic(when === "repeat" ? "refresh" : "check", 15), document.createTextNode(when === "repeat" ? " Start repeating" : " Confirm"));
  }
  ["#send-at", "#repeat-every", "#repeat-until"].forEach((sel) => $(sel).addEventListener("input", syncWhen));
  $("#sched-use-best")?.addEventListener("click", applyBestTime);
  $$('input[name="when"]').forEach((r) => r.addEventListener("change", syncWhen));
  $("#schedule-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    const status = $("#schedule-status");
    const when = $('input[name="when"]:checked').value;
    const later = when !== "now";
    let sendAt = null;
    if (later) {
      const v = $("#send-at").value;
      if (!v) { status.className = "status-box error-text"; status.textContent = "Pick a date and time."; return; }
      sendAt = new Date(v).toISOString(); // datetime-local is interpreted in the browser's time zone
    }
    const repeat = when === "repeat" ? $("#repeat-every").value : "";
    const btn = $("#schedule-go");
    btn.disabled = true;
    status.className = "status-box";
    status.textContent = "Saving…";
    try {
      markDirty();
      if (!(await save())) throw new Error("Could not save the latest changes.");
      await api(cfg.urls.schedule, { send_at: sendAt, audience: state.audience, cc: state.cc, bcc: state.bcc, repeat,
        repeat_until: repeat ? $("#repeat-until").value || null : null,
        refresh: repeat && state.from_data && $("#repeat-refresh").checked });
      status.className = "status-box ok-text";
      status.textContent = repeat ? `Repeating: ${repeatSummary()} Reloading…` : later ? "Scheduled! Reloading…" : "Queued. Sending starts within a few seconds.";
      setTimeout(() => window.location.reload(), 900);
    } catch (err) {
      status.className = "status-box error-text";
      status.replaceChildren(document.createTextNode(err.message));
      if (err.problems?.length) status.append(h("ul", {}, ...err.problems.map((p) => h("li", {}, p))));
    } finally {
      btn.disabled = false;
    }
  });

  // ---------- studio numbers dialog (Stats block) ----------
  let factsTarget = null; // block id to fill, or null to insert a new Stats block
  function factsSelected() { return $$('#facts-pick input[type="checkbox"]:checked'); }
  function syncFactsCount() {
    const n = factsSelected().length;
    $("#facts-count").textContent = `${n} of ${MAX_STATS} selected`;
    $$('#facts-pick input[type="checkbox"]').forEach((c) => { c.disabled = !c.checked && n >= MAX_STATS; });
    $("#facts-insert").disabled = n === 0;
  }
  async function openFacts(blockId = null) {
    if (!editable) return;
    factsTarget = blockId;
    const pick = $("#facts-pick");
    $("#facts-status").textContent = "";
    $("#facts-status").className = "status-box";
    $("#dlg-facts").showModal();
    try {
      const facts = await loadFacts();
      if (!facts.length) { pick.replaceChildren(h("div", { class: "emp-empty" }, "No studio numbers yet. Add employees and send a newsletter first.")); return; }
      const groups = [...new Set(facts.map((f) => f.group))];
      pick.replaceChildren(...groups.flatMap((g) => [
        h("div", { class: "facts-group" }, g),
        ...facts.filter((f) => f.group === g).map((f, i) => h("label", { class: "fact-pick" },
          h("input", { type: "checkbox", value: f.key, onchange: syncFactsCount }),
          h("strong", {}, f.value),
          h("span", {}, f.label, f.note ? h("small", {}, f.note) : null))),
      ]));
      syncFactsCount();
    } catch (e) {
      pick.replaceChildren(h("div", { class: "emp-empty" }, "Couldn't load the studio numbers: " + e.message));
    }
  }
  $("#btn-insert-facts")?.addEventListener("click", () => openFacts(null));
  $("#facts-form").addEventListener("submit", (e) => {
    e.preventDefault();
    const keys = factsSelected().map((c) => c.value);
    if (!keys.length) return;
    const items = keys.map((k) => factsCache.find((f) => f.key === k)).filter(Boolean)
      .map((f) => ({ value: f.value.slice(0, 24), label: f.label.slice(0, 80), note: (f.note || "").slice(0, 100) }));
    const b = factsTarget ? blocks()[findIndex(factsTarget)] : null;
    if (b) {
      pushHistory();
      b.items = items;
      refreshBlock(b);
      renderProps();
      markDirty();
    } else {
      insertBlock("stats", undefined, { items });
    }
    $("#dlg-facts").close();
    toast("Studio numbers added. Edit the labels to fit your story.", "success");
  });

  // ---------- Tips: draft check against past results ----------
  let reviewTimer = null;
  let reviewSeq = 0;
  function scheduleReview(delay = 1500) {
    clearTimeout(reviewTimer);
    reviewTimer = setTimeout(runReview, delay);
  }
  const TIP_ICONS = { good: "check-circle", warn: "alert", tip: "lightbulb" };
  function tipAction(a) {
    if (!a) return null;
    if (a.type === "select") {
      return h("button", { type: "button", class: "btn btn-soft btn-xs", onclick: () => {
        select(a.block);
        const el = canvas.querySelector(`[data-id="${a.block}"]`);
        if (el) { el.scrollIntoView({ block: "center", behavior: "smooth" }); el.classList.add("flash"); setTimeout(() => el.classList.remove("flash"), 1200); }
      } }, ic("eye", 13), a.label);
    }
    if (a.type === "ai" && editable) {
      return h("button", { type: "button", class: "btn btn-soft btn-xs", onclick: () => {
        aiPrompt.value = a.prompt;
        $('input[name="ai-mode"][value="revise"]').checked = true;
        showTab("ai");
        aiPrompt.focus();
        const st = $("#ai-status");
        st.className = "ai-status";
        st.textContent = "Instruction ready. Check it, then click Generate.";
      } }, ic("sparkles", 13), a.label);
    }
    if (a.type === "time" && editable && cfg.bestTime) {
      return h("button", { type: "button", class: "btn btn-soft btn-xs", onclick: () => { $("#btn-schedule").click(); applyBestTime(); } }, ic("calendar", 13), a.label);
    }
    return null;
  }
  function renderTips(res) {
    $("#tips-basis").textContent = res.based_on
      ? `Compared with your ${res.based_on} sent newsletter${res.based_on === 1 ? "" : "s"}.`
      : "General checks. After your first send, tips compare with your own results.";
    $("#tips-score").hidden = !res.total;
    $("#tips-good").textContent = res.good;
    $("#tips-total").textContent = res.total;
    $("#tips-meter").style.width = (res.total ? Math.round((res.good / res.total) * 100) : 0) + "%";
    $("#tips-list").replaceChildren(...res.checks.map((c) => h("div", { class: `tip tip-${c.status}` },
      h("span", { class: "tip-ico" }, ic(TIP_ICONS[c.status], 15)),
      h("div", { class: "tip-text" }, h("strong", {}, c.title), c.detail ? h("p", {}, c.detail) : null, tipAction(c.action)))));
    const badge = $("#tips-badge");
    badge.hidden = !res.warnings;
    badge.textContent = res.warnings || "";
    badge.title = `${res.warnings} thing${res.warnings === 1 ? "" : "s"} to fix`;
  }
  async function runReview() {
    clearTimeout(reviewTimer);
    const seq = ++reviewSeq;
    try {
      const res = await api(cfg.urls.review, {
        subject: state.subject, preheader: state.preheader, content: state.content, audience: state.audience,
      });
      if (seq === reviewSeq) renderTips(res);
    } catch (e) {
      if (seq === reviewSeq) $("#tips-list").replaceChildren(h("div", { class: "emp-empty" }, "Couldn't check the draft: " + e.message));
    }
  }
  $("#tips-refresh").addEventListener("click", runReview);

  // ---------- top bar ----------
  $("#btn-save")?.addEventListener("click", save);
  $("#btn-undo").addEventListener("click", undo);
  document.addEventListener("keydown", (e) => {
    const mod = e.ctrlKey || e.metaKey;
    if (mod && e.key.toLowerCase() === "s") { e.preventDefault(); save(); }
    const inText = e.target.closest?.("input, textarea, [contenteditable=true], select");
    if (mod && e.key.toLowerCase() === "z" && !e.shiftKey && !inText && history.length) { e.preventDefault(); undo(); }
  });

  function renderAll() {
    syncMetaInputs();
    $$("[data-theme-key]").forEach((input) => (input.value = state.content.theme[input.dataset.themeKey]));
    renderCanvas();
    renderProps();
  }

  if (!editable) document.body.classList.add("readonly");
  renderAll();
  refreshAudiencePill();
  markPreset();
  scheduleReview(600);
  setSaveState(editable ? "All changes saved" : "Read only", editable ? "" : "readonly");

  // ---------- AI writer: "Write a prompt" or "Use your data" ----------
  function setWriteMode(mode) {
    $$(".write-mode [data-write]").forEach((b) => {
      const on = b.dataset.write === mode;
      b.classList.toggle("active", on);
      b.setAttribute("aria-selected", on ? "true" : "false");
    });
    $$("[data-write-pane]").forEach((pane) => { pane.hidden = pane.dataset.writePane !== mode; });
    // To / Cc / Bcc / Subject / Preview follow the open side: above "Refine the current draft", or under the data card.
    const slot = $(`[data-compose-slot="${mode}"]`);
    if (slot && !slot.contains($(".ed-compose"))) slot.append($(".ed-compose"));
  }
  $$(".write-mode [data-write]").forEach((b) => b.addEventListener("click", () => setWriteMode(b.dataset.write)));

  // ---------- newsletter built from your data (no prompt) ----------
  async function buildStoryboard() {
    const st = $("#story-status");
    const btn = $("#story-build");
    btn.disabled = true;
    st.className = "ai-status working";
    st.textContent = "Building the newsletter from your data" + (cfg.aiEnabled === false ? "…" : " and writing the summary… this can take up to a minute.");
    try {
      const kind = $("#story-kind").value;
      const res = await api(cfg.urls.storyboard, kind !== "engagement"
        ? { kind, period: kind === "hr" ? $("#story-hr-period").value : undefined, gender: $("#story-gender").value, ...orgScope(),
          focus: $("#story-focus").value, content: state.content }
        : { period: $("#story-period").value, department: $("#story-dept").value, focus: $("#story-focus").value,
          content: state.content });
      pushHistory();
      state.subject = res.subject;
      state.preheader = res.preheader;
      state.content = res.content;
      state.from_data = true;  // built from data: a repeating schedule can rebuild it with new numbers
      selectedId = null;
      renderAll();
      markDirty();
      $('input[name="ai-mode"][value="revise"]').checked = true;
      st.className = "ai-status ok";
      st.textContent = "Newsletter ready. Every number comes from your data. " + (res.notice ? res.notice + " " : "")
        + "To change the wording, switch to Write a prompt and use Revise. Undo restores the previous version.";
      toast("Newsletter ready.", "success");
    } catch (e) {
      st.className = "ai-status error-text";
      st.textContent = e.message;
    } finally {
      btn.disabled = !editable;
    }
  }
  $("#story-build").disabled = !editable;
  $("#story-build").addEventListener("click", buildStoryboard);

  // Which numbers: headcount & attrition from employee profiles, or newsletter engagement.
  const hrAvailable = !!$("#story-org");
  function orgScope() {
    const [kind, value] = ($("#story-org")?.value || "").split(/:(.*)/s);
    return kind ? { [kind]: value } : {};
  }
  const STORY_TEXT = {
    hr: ["No prompt needed. Pick the period and the team, and the newsletter is built for you: headcount, joiners, exits and attrition with change vs last year, by department, plus a short AI summary.",
      "Focus (optional), e.g. department-wise attrition and where to act"],
    dei: ["No prompt needed. Pick the team, and the newsletter is built for you: gender balance, women by level and department, hiring and attrition by gender and age groups, plus a short AI summary.",
      "Focus (optional), e.g. women in leadership and one practical step"],
    performance: ["No prompt needed. Pick the team, and the newsletter is built for you: the rating spread, ratings by department, level and tenure, and attrition of high and low performers, plus a short AI summary.",
      "Focus (optional), e.g. keeping our high performers"],
    goals: ["No prompt needed. Pick the team, and the newsletter is built for you: goal progress and completion, goals at risk or behind, and progress by department and category, plus a short AI summary.",
      "Focus (optional), e.g. the teams with the most goals at risk"],
    engagement: ["No prompt needed. Pick the period and audience, and the newsletter is built for you: opens, clicks and engagement by team as KPI cards, charts and tables, plus a short AI summary.",
      "Focus (optional), e.g. which teams read least and what to do about it"],
  };
  function syncStoryKind() {
    const kind = $("#story-kind").value;
    const emp = kind !== "engagement";
    $$(".story-hr").forEach((el) => (el.hidden = !emp));
    $$(".story-hr-only").forEach((el) => (el.hidden = kind !== "hr"));
    $$(".story-eng").forEach((el) => (el.hidden = emp));
    const [hint, placeholder] = STORY_TEXT[kind] || STORY_TEXT.engagement;
    $("#story-hint").textContent = hint;
    $("#story-focus").placeholder = placeholder;
  }
  function setScope(sc) {
    const kind = (sc && sc.kind) || cfg.storySpace;
    if (!hrAvailable || !sc || !kind || ![...$("#story-kind").options].some((o) => o.value === kind)) return;
    const switched = $("#story-kind").value !== kind;
    $("#story-kind").value = kind;
    syncStoryKind();
    if (switched) loadPromptIdeas();  // show this space's focus suggestions
    if (sc.period && kind === "hr") $("#story-hr-period").value = sc.period;
    const org = sc.leader ? `leader:${sc.leader}` : sc.bu ? `bu:${sc.bu}` : sc.department ? `department:${sc.department}` : "";
    $("#story-org").value = org;
    if ($("#story-org").value !== org) $("#story-org").value = "";
    $("#story-gender").value = sc.gender || "";
  }
  $("#story-kind").addEventListener("change", () => { syncStoryKind(); loadPromptIdeas(); });
  syncStoryKind();

  // ---------- prompt suggestions worked out from the data ----------
  function suggestionChip(item, onPick) {
    return h("button", { type: "button", class: "chip chip-data", title: item.prompt, disabled: !editable,
      onclick: () => onPick(item) }, ic(item.use_data ? "database" : "sparkles", 13), item.label);
  }
  function renderLetterIdeas(list) {
    $("#rec-prompts").replaceChildren(...list.map((item) => suggestionChip(item, (it) => {
      aiPrompt.value = it.prompt;
      $('input[name="ai-mode"][value="new"]').checked = true;
      if (it.use_data) { useData.checked = true; useData.dispatchEvent(new Event("change")); }
      const st = $("#ai-status");
      st.className = "ai-status";
      st.textContent = "Fill in the [brackets], then click Generate."
        + (it.departments && it.departments.length ? ` To send it only to ${it.departments.join(", ")}, set To → Specific departments.` : "");
      aiPrompt.focus();
    })));
    $("#rec-prompts").hidden = !list.length;
  }
  function renderFocusIdeas(list) {
    $("#story-focus-chips").replaceChildren(...list.map((item) => suggestionChip(item, (it) => {
      if (it.scope) setScope(it.scope);
      $("#story-focus").value = it.prompt;
      $("#story-focus").focus();
      const st = $("#story-status");
      st.className = "ai-status";
      st.textContent = "Team and focus are set. Click Build newsletter.";
    })));
    $("#story-suggest").hidden = !list.length;
  }
  let promptSeq = 0;
  async function loadPromptIdeas(withLetters = false) {
    const seq = ++promptSeq;
    try {
      const q = new URLSearchParams({ period: $("#story-period").value, department: $("#story-dept").value });
      const res = await api(cfg.urls.prompts + "?" + q, undefined, "GET");
      if (seq !== promptSeq) return;
      renderFocusIdeas($("#story-kind").value !== "engagement" ? (res.space || res.hr || []) : res.focus);
      if (withLetters) renderLetterIdeas(res.writer || res.newsletter);
    } catch (_) { /* suggestions are optional */ }
  }
  $("#story-period").addEventListener("change", () => loadPromptIdeas());
  $("#story-dept").addEventListener("change", () => loadPromptIdeas());
  loadPromptIdeas(true);

  // Started from the dashboard prompt box: generate the first draft right away.
  const params = new URLSearchParams(location.search);
  if (params.has("storyboard")) {
    window.history.replaceState(null, "", location.pathname);
    setWriteMode("data");
    if (params.get("period")) $("#story-period").value = params.get("period");
    if (params.get("kind") && params.get("kind") !== "engagement") {
      setScope({ kind: params.get("kind"), ...Object.fromEntries(["period", "leader", "bu", "department", "gender"].map((k) => [k, params.get(k) || ""])) });
    } else if (params.get("department")) $("#story-dept").value = params.get("department");
    if (params.get("focus")) $("#story-focus").value = params.get("focus");
    if (editable && !blocks().length) buildStoryboard();
  } else if (params.has("autogen")) {
    window.history.replaceState(null, "", location.pathname);
    if (params.get("data") === "1") useData.checked = true;
    if (editable && !blocks().length && aiPrompt.value.trim()) {
      $('input[name="ai-mode"][value="new"]').checked = true;
      generate();
    }
  } else if (!blocks().length && editable) {
    aiPrompt.focus();
  }
})();

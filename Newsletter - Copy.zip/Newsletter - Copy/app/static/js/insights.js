// Insights page: reading-time chart and AI topic ideas.
(function () {
  "use strict";
  const $ = (sel) => document.querySelector(sel);
  const ic = (name, size = 16) => window.svgIcon(name, size);
  function h(tag, attrs = {}, ...children) {
    const el = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs)) {
      if (v === null || v === undefined || v === false) continue;
      if (k === "class") el.className = v;
      else if (k.startsWith("on")) el.addEventListener(k.slice(2), v);
      else el.setAttribute(k, v === true ? "" : v);
    }
    for (const c of children.flat()) if (c !== null && c !== undefined) el.append(c);
    return el;
  }
  const hh = (n) => String(n % 24).padStart(2, "0") + ":00";

  // ---------- engagement by newsletter (moved from the dashboard) ----------
  const trendEl = $("#trend-data");
  if (trendEl) {
    const dateFmt = new Intl.DateTimeFormat(undefined, { month: "short", day: "numeric" });
    lineChart($("#trend-chart"), JSON.parse(trendEl.textContent), {
      series: [
        { key: "open", label: "Open rate", color: "var(--series-1)" },
        { key: "click", label: "Click rate", color: "var(--series-2)" },
      ],
      xLabel: (r) => dateFmt.format(new Date(r.t)),
      tipTitle: (r) => r.label,
      tipSub: (r) => dateFmt.format(new Date(r.t)),
      yFormat: (v) => v + "%",
      yMax: 100,
      points: true,
    });
  }

  // ---------- opens by hour ----------
  const hourData = $("#hour-data");
  if (hourData) {
    const { rows, peak } = JSON.parse(hourData.textContent);
    let start = -1;
    if (peak) start = Number(peak.slice(0, 2));
    barChart($("#hour-chart"), rows.map((r) => ({
      label: hh(r.hour), value: r.opens, share: r.share, hour: r.hour,
      highlight: start >= 0 && (r.hour === start || r.hour === (start + 1) % 24),
    })), {
      height: 230,
      annotation: start >= 0 ? "Peak reading" : null,
      xLabel: (r) => hh(r.hour),
      tipTitle: (r) => `${hh(r.hour)} to ${hh(r.hour + 1)}`,
      tipLines: (r) => [`${r.value} open${r.value === 1 ? "" : "s"}`, `${Math.round(r.share * 100)}% of all opens`],
    });
  }

  // ---------- AI topic ideas ----------
  const cfgEl = $("#ideas-config");
  if (!cfgEl) return;
  const cfg = JSON.parse(cfgEl.textContent);
  const list = $("#ideas-list");
  const status = $("#ideas-status");
  const empty = $("#ideas-empty");
  const btn = $("#ideas-btn");
  const csrf = document.querySelector('meta[name="csrf-token"]').content;
  const KEY = "ns-ideas";

  function draftForm(idea) {
    const form = h("form", { method: "post", action: cfg.new });
    const field = (name, value) => form.append(h("input", { type: "hidden", name, value }));
    field("csrf_token", csrf);
    field("name", idea.title);
    field("prompt", idea.subject ? `${idea.prompt}\n\nSuggested subject: ${idea.subject}` : idea.prompt);
    (idea.departments || []).forEach((d) => field("departments", d));
    form.append(h("button", { type: "submit", class: "btn btn-primary btn-sm" }, ic("wand", 14), "Create draft"));
    return form;
  }

  function render(ideas, at) {
    empty.hidden = ideas.length > 0;
    list.replaceChildren(...ideas.map((idea, i) => h("article", { class: "idea" },
      h("div", { class: "idea-num" }, String(i + 1)),
      h("div", { class: "idea-main" },
        h("h3", {}, idea.title),
        h("p", {}, idea.why),
        h("div", { class: "idea-meta" },
          h("span", { title: "Suggested subject" }, ic("mail", 13), idea.subject),
          h("span", {}, ic("users", 13), idea.departments.length ? idea.departments.join(", ") : "All employees")),
        h("details", { class: "idea-brief" }, h("summary", {}, "Brief for the AI writer"), h("p", {}, idea.prompt)),
        draftForm(idea)))));
    if (at) {
      const when = new Date(at);
      status.className = "ai-status";
      status.textContent = "";
      list.append(h("p", { class: "muted small" }, `Suggested ${when.toLocaleString([], { dateStyle: "medium", timeStyle: "short" })}. Click “Suggest topics” for fresh ideas.`));
    }
  }

  try {
    const saved = JSON.parse(localStorage.getItem(KEY) || "null");
    if (saved && Array.isArray(saved.ideas) && saved.ideas.length) render(saved.ideas, saved.at);
  } catch (_) { /* storage unavailable */ }

  btn?.addEventListener("click", async () => {
    btn.disabled = true;
    const label = btn.querySelector("span");
    const old = label.textContent;
    label.textContent = "Thinking…";
    status.className = "ai-status working";
    status.textContent = "Reading your engagement data and drafting ideas… this usually takes 20 to 60 seconds.";
    try {
      const res = await api(cfg.url, {});
      const at = new Date().toISOString();
      try { localStorage.setItem(KEY, JSON.stringify({ ideas: res.ideas, at })); } catch (_) { /* ignore */ }
      status.className = "ai-status";
      status.textContent = "";
      render(res.ideas, at);
      toast(`${res.ideas.length} ideas ready.`, "success");
    } catch (e) {
      status.className = "ai-status error-text";
      status.textContent = e.message;
    } finally {
      btn.disabled = false;
      label.textContent = old;
    }
  });
})();

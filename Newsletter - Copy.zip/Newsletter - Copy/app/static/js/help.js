// Help assistant: a small chat in the corner of every page. It answers how-to questions about the studio and writes
// prompts for the AI writer; POST /help/chat streams each answer back as it's written (one JSON object per line).
// The conversation stays in this browser tab only (sessionStorage), separately for each signed-in user.
(function () {
  const cfgEl = document.getElementById("help-config");
  if (!cfgEl) return;
  let cfg;
  try { cfg = JSON.parse(cfgEl.textContent); } catch (_) { return; }

  const csrf = document.querySelector('meta[name="csrf-token"]')?.content || "";
  const KEY = `ns-help:${cfg.user}`;
  const HANDOFF = "ns-help-prompt";
  const MAX_KEPT = 30;

  // ---------------------------------------------------------------- state (kept for this tab)
  let state = { open: false, messages: [] }; // messages: {role, content, error?, note?, failed?}
  try {
    const saved = JSON.parse(sessionStorage.getItem(KEY) || "null");
    if (saved && Array.isArray(saved.messages)) state = { open: !!saved.open, messages: saved.messages.slice(-MAX_KEPT) };
  } catch (_) { /* storage unavailable: start fresh */ }
  function save() {
    try { sessionStorage.setItem(KEY, JSON.stringify({ open: state.open, messages: state.messages.slice(-MAX_KEPT) })); } catch (_) { /* optional */ }
  }

  // ---------------------------------------------------------------- small DOM helpers
  function el(tag, attrs, ...kids) {
    const n = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs || {})) {
      if (v == null || v === false) continue;
      if (k === "class") n.className = v;
      else if (k === "text") n.textContent = v;
      else if (k.startsWith("on")) n.addEventListener(k.slice(2), v);
      else n.setAttribute(k, v === true ? "" : v);
    }
    for (const kid of kids.flat()) if (kid != null && kid !== false) n.append(kid);
    return n;
  }
  const icon = (name, size = 16) => svgIcon(name, size);

  // ---------------------------------------------------------------- answer rendering (a safe subset of Markdown)
  // **bold**, `code`, [text](/studio-path) links, bulleted and numbered lists, and ```prompt blocks shown as prompt
  // cards with Copy / Use buttons. Everything is built as DOM nodes, never as HTML strings.
  function inline(parent, text) {
    const re = /\*\*([^*]+)\*\*|`([^`]+)`|\[([^\]]+)\]\(([^)\s]+)\)/g;
    let last = 0, m;
    while ((m = re.exec(text))) {
      if (m.index > last) parent.append(text.slice(last, m.index));
      if (m[1] != null) parent.append(el("strong", { text: m[1] }));
      else if (m[2] != null) parent.append(el("code", { text: m[2] }));
      else if (/^\/(?!\/)/.test(m[4])) parent.append(el("a", { href: m[4], text: m[3] })); // links inside the studio only
      else parent.append(m[3]);
      last = re.lastIndex;
    }
    if (last < text.length) parent.append(text.slice(last));
  }
  function blocks(frag, text) {
    let para = [], list = null, type = null;
    const flushPara = () => {
      if (!para.length) return;
      const p = el("p");
      inline(p, para.join(" "));
      frag.append(p);
      para = [];
    };
    const flushList = () => { if (list) frag.append(list); list = null; type = null; };
    for (const raw of text.replace(/\r/g, "").split("\n")) {
      const line = raw.trim();
      if (!line) { flushPara(); flushList(); continue; }
      const ul = /^[-*•]\s+(.*)$/.exec(line), ol = /^(\d+)[.)]\s+(.*)$/.exec(line), head = /^#{1,6}\s+(.*)$/.exec(line);
      if (ul || ol) {
        flushPara();
        const t = ul ? "ul" : "ol";
        if (type !== t) {
          flushList();
          list = el(t);
          type = t;
          if (ol && ol[1] !== "1") list.start = Number(ol[1]);
        }
        const li = el("li");
        inline(li, ul ? ul[1] : ol[2]);
        list.append(li);
      } else if (list && /^\s{2,}/.test(raw)) {
        inline(list.lastElementChild, " " + line); // a wrapped list item
      } else if (head) {
        flushPara(); flushList();
        const p = el("p");
        p.append(el("strong", { text: head[1] }));
        frag.append(p);
      } else {
        flushList();
        para.push(line);
      }
    }
    flushPara();
    flushList();
  }
  function render(text, streaming) {
    const frag = document.createDocumentFragment();
    const re = /```([^\n`]*)\n([\s\S]*?)(```|$)/g; // an unclosed block (still being written) runs to the end
    let last = 0, m;
    while ((m = re.exec(text)) && m[0]) {
      if (m.index > last) blocks(frag, text.slice(last, m.index));
      const info = m[1].trim().toLowerCase();
      const body = m[2].replace(/\s+$/, "");
      const done = m[3] === "```" || !streaming;
      frag.append(info.startsWith("prompt") ? promptCard(body, /\bdata\b/.test(info), done) : el("pre", { text: body }));
      last = re.lastIndex;
    }
    if (last < text.length) blocks(frag, text.slice(last));
    return frag;
  }

  // ---------------------------------------------------------------- prompt cards
  function promptCard(text, data, done) {
    const card = el("div", { class: "help-prompt" },
      el("div", { class: "help-prompt-head" }, icon("sparkles", 14), "Prompt",
        data ? el("span", { class: "help-prompt-tag", title: "Tick Include studio data in the AI writer", text: "uses studio data" }) : null),
      el("div", { class: "help-prompt-text", text }));
    if (done && text) {
      const editorBox = editorPromptBox();
      let action;
      if (editorBox) action = el("button", { type: "button", class: "btn btn-primary btn-xs", onclick: () => fillEditor(text, data) }, icon("wand", 13), "Use this prompt");
      else if (cfg.canStart) action = el("button", { type: "button", class: "btn btn-primary btn-xs", onclick: () => startNewsletter(text, data) }, icon("plus", 13), "Start a newsletter with it");
      else action = el("span", { class: "help-prompt-hint", text: "Pick a space first to start a newsletter with it." });
      card.append(el("div", { class: "help-prompt-actions" },
        action.tagName === "SPAN" ? action : null,
        el("button", { type: "button", class: "btn btn-xs", onclick: () => copy(text) }, icon("copy", 13), "Copy"),
        action.tagName === "SPAN" ? null : action));
    }
    return card;
  }
  async function copy(text) {
    try {
      await navigator.clipboard.writeText(text);
    } catch (_) {
      const t = el("textarea", { class: "help-copy-buffer" });
      t.value = text;
      document.body.append(t);
      t.select();
      document.execCommand("copy");
      t.remove();
    }
    window.toast?.("Prompt copied.", "success", 2500);
  }
  function editorPromptBox() {
    const box = document.getElementById("ai-prompt");
    return box && !box.disabled && !document.body.classList.contains("readonly") ? box : null;
  }
  function fillEditor(text, data) {
    const box = editorPromptBox();
    if (!box) return startNewsletter(text, data);
    document.querySelector('.ed-tab[data-tab="ai"]')?.click();
    document.querySelector('[data-write="prompt"]')?.click();
    box.value = text;
    box.dispatchEvent(new Event("input", { bubbles: true }));
    const useData = document.getElementById("ai-use-data");
    if (useData && data && !useData.checked && !useData.disabled) { useData.checked = true; useData.dispatchEvent(new Event("change")); }
    const revising = document.querySelector('input[name="ai-mode"][value="revise"]')?.checked;
    box.scrollIntoView({ block: "center", behavior: "smooth" });
    box.focus({ preventScroll: true });
    window.toast?.(revising
      ? "Prompt added. Choose New draft to start over or Revise to change this draft, fill in any [brackets], then Generate."
      : "Prompt added to the AI writer. Fill in any [brackets], then click Generate.", "success", 7000);
  }
  function startNewsletter(text, data) {
    try { sessionStorage.setItem(HANDOFF, JSON.stringify({ text, data })); } catch (_) { return copy(text); }
    const form = el("form", { method: "post", action: cfg.urls.new, hidden: true },
      el("input", { type: "hidden", name: "csrf_token", value: csrf }));
    document.body.append(form);
    form.submit();
  }
  // A prompt handed over from another page: put it in this new newsletter's AI writer once the editor is ready.
  if (cfg.editor) {
    let handed = null;
    try { handed = JSON.parse(sessionStorage.getItem(HANDOFF) || "null"); sessionStorage.removeItem(HANDOFF); } catch (_) { /* none */ }
    if (handed && handed.text) {
      const apply = () => setTimeout(() => fillEditor(String(handed.text), !!handed.data), 300);
      if (document.readyState === "complete") apply(); else window.addEventListener("load", apply, { once: true });
    }
  }

  // ---------------------------------------------------------------- the widget
  const fab = el("button", {
    type: "button", class: "help-fab", id: "help-fab", "aria-expanded": "false", "aria-controls": "help-panel",
    "aria-label": "Open the help assistant", title: "Questions? Ask the help assistant",
  }, el("span", { class: "help-fab-open" }, icon("message", 22)), el("span", { class: "help-fab-close" }, icon("x", 22)));

  const log = el("div", { class: "help-log", role: "log", "aria-label": "Conversation" });
  const live = el("div", { class: "sr-only", "aria-live": "polite" });
  const input = el("textarea", {
    rows: "1", maxlength: "2000", "aria-label": "Your question",
    placeholder: cfg.ai ? "Ask how to do something…" : "The assistant is off", disabled: !cfg.ai,
  });
  const sendBtn = el("button", { type: "submit", class: "help-send", "aria-label": "Send", title: "Send (Enter)", disabled: !cfg.ai }, icon("send", 17));
  const form = el("form", { class: "help-form" }, input, sendBtn);
  const newBtn = el("button", { type: "button", class: "btn btn-ghost btn-icon btn-sm", title: "New chat", "aria-label": "Start a new chat" }, icon("refresh", 16));
  const closeBtn = el("button", { type: "button", class: "btn btn-ghost btn-icon btn-sm", title: "Close", "aria-label": "Close the help assistant" }, icon("x", 17));
  const panel = el("section", { class: "help-panel", id: "help-panel", role: "dialog", "aria-label": "Help assistant", hidden: true },
    el("header", { class: "help-head" },
      el("span", { class: "help-ava" }, icon("sparkles", 17)),
      el("div", { class: "help-title" }, el("strong", { text: "Help assistant" }), el("span", { text: "How-to answers and ready-made prompts" })),
      newBtn, closeBtn),
    log, live, form,
    el("p", { class: "help-note", text: "AI answers can be wrong. Your questions go to Claude; no employee data is sent." }));
  document.body.append(panel, fab);
  document.body.classList.add("has-help");

  // ---------------------------------------------------------------- conversation view
  const views = new Map(); // message -> its element
  let busy = false, ctrl = null, frame = 0;

  function intro() {
    const box = el("div", { class: "help-msg bot" });
    const body = el("div", { class: "help-bubble" });
    if (!cfg.ai) {
      body.append(el("p", { text: "The help assistant is off because the AI key isn't set up. Ask an admin to add ANTHROPIC_API_KEY to .env and restart the app." }));
    } else {
      body.append(el("p", { text: `Hi${cfg.first ? " " + cfg.first : ""}! Ask me how to do anything in the studio, or ask for a prompt and I'll write one you can use straight away.` }));
      body.append(el("div", { class: "help-suggest" },
        cfg.suggestions.map((q) => el("button", { type: "button", class: "chip", onclick: () => send(q) }, q))));
    }
    box.append(body);
    return box;
  }
  function messageView(m, i) {
    const wrap = el("div", { class: `help-msg ${m.role === "user" ? "user" : "bot"}` });
    const bubble = el("div", { class: "help-bubble" });
    wrap.append(bubble);
    fill(m, bubble, i);
    return wrap;
  }
  function fill(m, bubble, i) {
    bubble.replaceChildren();
    const last = i === state.messages.length - 1;
    if (m.role === "user") { bubble.textContent = m.content; return; }
    if (!m.content && busy && last) {
      bubble.append(el("span", { class: "help-typing", "aria-label": "Writing an answer" }, el("i"), el("i"), el("i")));
      return;
    }
    if (m.content) bubble.append(render(m.content, busy && last));
    if (m.note) bubble.append(el("p", { class: "help-muted", text: m.note }));
    if (m.error) {
      bubble.classList.add("is-error");
      bubble.append(el("p", { class: "help-error" }, icon("alert", 14), m.error));
      const question = state.messages[i - 1];
      if (question && question.role === "user" && last) {
        bubble.append(el("button", { type: "button", class: "btn btn-xs", onclick: () => retry(i) }, icon("refresh", 13), "Try again"));
      }
    }
  }
  function nearBottom() { return log.scrollHeight - log.scrollTop - log.clientHeight < 80; }
  function renderAll() {
    views.clear();
    log.replaceChildren(intro(), ...state.messages.map((m, i) => {
      const v = messageView(m, i);
      views.set(m, v.firstChild);
      return v;
    }));
    log.scrollTop = log.scrollHeight;
  }
  function renderOne(m) {
    cancelAnimationFrame(frame);
    frame = requestAnimationFrame(() => {
      const stick = nearBottom();
      const bubble = views.get(m);
      if (bubble) fill(m, bubble, state.messages.indexOf(m));
      if (stick) log.scrollTop = log.scrollHeight;
    });
  }
  function setBusy(on) {
    busy = on;
    sendBtn.replaceChildren(icon(on ? "stop" : "send", 17));
    sendBtn.setAttribute("aria-label", on ? "Stop the answer" : "Send");
    sendBtn.title = on ? "Stop" : "Send (Enter)";
    sendBtn.classList.toggle("is-stop", on);
  }

  // ---------------------------------------------------------------- asking
  async function send(text) {
    text = String(text || "").trim();
    if (!text || busy || !cfg.ai) return;
    const question = { role: "user", content: text };
    const answer = { role: "assistant", content: "" };
    const history = state.messages.filter((m) => !m.failed && m.content).map(({ role, content }) => ({ role, content }));
    history.push({ role: "user", content: text });
    state.messages.push(question, answer);
    input.value = "";
    autosize();
    setBusy(true);
    renderAll();
    save();
    ctrl = new AbortController();
    try {
      const res = await fetch(cfg.urls.chat, {
        method: "POST", signal: ctrl.signal, credentials: "same-origin",
        headers: { "Content-Type": "application/json", "X-CSRFToken": csrf, Accept: "application/x-ndjson" },
        body: JSON.stringify({ messages: history.slice(-12), page: cfg.page }),
      });
      if (!res.ok) {
        let msg = "";
        try { msg = (await res.json()).error; } catch (_) { /* not JSON */ }
        throw new Error(msg || `Something went wrong (${res.status}). Try again.`);
      }
      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let buf = "";
      for (;;) {
        const { value, done } = await reader.read();
        if (done) break;
        buf += decoder.decode(value, { stream: true });
        let nl;
        while ((nl = buf.indexOf("\n")) >= 0) {
          const line = buf.slice(0, nl).trim();
          buf = buf.slice(nl + 1);
          if (!line) continue;
          const ev = JSON.parse(line);
          if (ev.t) { answer.content += ev.t; renderOne(answer); }
          else if (ev.error) throw new Error(ev.error);
          else if (ev.done && ev.cut) answer.note = "The answer was cut short. Ask me to continue.";
        }
      }
      if (!answer.content) throw new Error("No answer came back. Try again.");
      live.textContent = "Answer ready.";
    } catch (e) {
      if (e.name === "AbortError") {
        answer.note = "Stopped.";
        if (!answer.content) { question.failed = answer.failed = true; answer.note = ""; answer.error = "Stopped before an answer was written."; }
      } else {
        answer.error = e.message || "Something went wrong. Try again.";
        if (!answer.content) question.failed = answer.failed = true;
        live.textContent = answer.error;
      }
    } finally {
      ctrl = null;
      setBusy(false);
      renderAll();
      save();
    }
  }
  function retry(i) {
    const question = state.messages[i - 1];
    state.messages.splice(i - 1, 2);
    send(question.content);
  }

  // ---------------------------------------------------------------- open / close / input
  function setOpen(open, { focus = true } = {}) {
    state.open = open;
    panel.hidden = !open;
    document.body.classList.toggle("help-open", open); // moves notifications clear of the chat
    fab.classList.toggle("is-open", open);
    fab.setAttribute("aria-expanded", String(open));
    fab.setAttribute("aria-label", open ? "Close the help assistant" : "Open the help assistant");
    if (open) {
      renderAll();
      if (focus && cfg.ai) input.focus();
    } else if (focus) {
      fab.focus();
    }
    save();
  }
  function autosize() {
    input.style.height = "auto";
    input.style.height = Math.min(input.scrollHeight, 130) + "px";
  }
  fab.addEventListener("click", () => setOpen(!state.open));
  closeBtn.addEventListener("click", () => setOpen(false));
  newBtn.addEventListener("click", () => {
    if (ctrl) ctrl.abort();
    state.messages = [];
    renderAll();
    save();
    if (cfg.ai) input.focus();
  });
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    if (busy) { ctrl?.abort(); return; }
    send(input.value);
  });
  input.addEventListener("input", autosize);
  input.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !e.shiftKey && !e.isComposing) { e.preventDefault(); form.requestSubmit(); }
  });
  panel.addEventListener("keydown", (e) => { if (e.key === "Escape") { e.stopPropagation(); setOpen(false); } });
  // Signing out forgets the conversation in this tab.
  document.addEventListener("submit", (e) => {
    if (!/\/logout$/.test(new URL(e.target.action, location.href).pathname)) return;
    try { Object.keys(sessionStorage).filter((k) => k.startsWith("ns-help")).forEach((k) => sessionStorage.removeItem(k)); } catch (_) { /* optional */ }
  });

  if (state.open) setOpen(true, { focus: false });
})();

// Workforce dashboard: KPI cards, charts and tables. One request per filter change refreshes everything.
(function () {
  "use strict";
  const dataEl = document.getElementById("wf-data");
  if (!dataEl) return;
  const urls = JSON.parse(document.getElementById("wf-urls").textContent);
  const form = document.getElementById("wf-filters");
  const $ = (id) => document.getElementById(id);
  // The 12 KPI cards in three groups.
  const STRIPS = {
    people: ["headcount", "joiners", "exits", "retention"],
    attrition: ["attrition", "voluntary", "involuntary", "regrettable"],
    quality: ["early", "female", "tenure", "notice"],
  };
  // Categorical slots in fixed order (validated palette); a category keeps its colour whatever the filter.
  const SLOT = ["var(--series-1)", "var(--series-2)", "var(--series-3)", "var(--series-4)"];
  const COLOR_OF = { Female: SLOT[0], Male: SLOT[1], "Non-binary": SLOT[2], Permanent: SLOT[0], Contract: SLOT[1], Intern: SLOT[2],
    Voluntary: SLOT[0], Involuntary: SLOT[1] };
  const KEY = "ns-workforce-filters";
  let state = JSON.parse(dataEl.textContent);
  let seq = 0;
  let deptSort = { key: "headcount", dir: -1 };

  function h(tag, attrs = {}, ...children) {
    const el = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs)) {
      if (v === null || v === undefined || v === false) continue;
      if (k === "class") el.className = v;
      else if (k === "style" && typeof v === "object") Object.assign(el.style, v);
      else if (k.startsWith("on")) el.addEventListener(k.slice(2), v);
      else el.setAttribute(k, v === true ? "" : v);
    }
    for (const c of children.flat()) if (c !== null && c !== undefined) el.append(c);
    return el;
  }
  const pct = (x) => (x === null || x === undefined ? "–" : `${(x * 100).toFixed(1)}%`);
  const fmtDate = (s) => (s ? new Date(s + "T00:00:00").toLocaleDateString(undefined, { day: "2-digit", month: "short", year: "numeric" }) : "–");
  const personLink = (p) => h("a", { href: `${urls.people}?q=${encodeURIComponent(p.name)}`, title: "Open in Employees" }, p.name);

  // ---------------- filters ----------------
  function fillSelect(name, items, keepValue) {
    const sel = form.elements[name];
    const value = keepValue ?? sel.value;
    const first = name === "period" ? [] : [["", "All"]];
    sel.replaceChildren(...first.concat(items.map((i) => (typeof i === "string" ? [i, i] : [i.value, i.label])))
      .map(([v, l]) => h("option", { value: v }, l)));
    sel.value = [...sel.options].some((o) => o.value === value) ? value : sel.options[0].value;
  }
  function fillOptions(o, f, period) {
    fillSelect("period", o.periods, period);
    fillSelect("leader", o.leader, f.leader);
    fillSelect("bu", o.bu, f.bu);
    fillSelect("department", f.bu && o.dept_by_bu[f.bu] ? o.dept_by_bu[f.bu] : o.department, f.department);
    fillSelect("location", o.location, f.location);
    fillSelect("gender", o.gender, f.gender);
    fillSelect("grade", o.grade, f.grade);
    fillSelect("type", o.type, f.type);
  }

  // ---------------- KPI strips ----------------
  function card(c) {
    const link = c.link ? urls.people + "?" + new URLSearchParams(c.link) : null;
    const el = h(link ? "a" : "div", { class: "kpi", href: link, title: c.definition + (link ? " · Click to see these people" : "") },
      h("div", { class: "kpi-label" }, c.label), h("div", { class: "kpi-value" }, c.display));
    const row = h("div", { class: "kpi-row" });
    if (c.delta) {
      row.append(h("span", { class: "kpi-delta " + (c.good === true ? "good" : c.good === false ? "bad" : "neutral"),
        "aria-label": `Change ${c.delta} compared with ${state.compare_label}` },
      (c.trend === "up" ? "▲ " : c.trend === "down" ? "▼ " : "") + c.delta));
    }
    if (c.note) row.append(h("span", { class: "kpi-note", title: c.note }, c.note));
    el.append(row);
    return el;
  }
  function renderCards() {
    $("wf-sub").textContent = `${state.label} · ${state.range} · compared with ${state.compare_label}`;
    const byKey = Object.fromEntries(state.cards.map((c) => [c.key, c]));
    for (const [tab, keys] of Object.entries(STRIPS)) {
      const host = $("wf-kpi-" + tab);
      if (host) host.replaceChildren(...keys.filter((k) => byKey[k]).map((k) => card(byKey[k])));
    }
    const active = Object.values(state.filters).filter(Boolean).length;
    $("wf-foot").textContent = `${state.population.toLocaleString()} employee profile${state.population === 1 ? "" : "s"}`
      + `${active ? " match the filters" : ""}. ▲/▼ compare with ${state.compare_label} (${state.compare_range}); `
      + "green is better, red is worse. Hover a number for its definition; click it to see the people.";
    form.classList.toggle("filtered", active > 0);
    // Highlight filters that are set.
    [...form.elements].forEach((el) => { if (el.tagName === "SELECT") el.classList.toggle("set", el.name !== "period" && !!el.value); });
  }

  // ---------------- charts ----------------
  function donut(hostId, legendId, items, centerLabel) {
    const total = items.reduce((a, it) => a + it.value, 0);
    const colored = items.map((it, i) => ({ ...it, color: COLOR_OF[it.label] || SLOT[i] || "var(--faint)" }));
    donutChart($(hostId), colored, { centerLabel });
    $(legendId).replaceChildren(h("tbody", {}, ...colored.map((it) => h("tr", {},
      h("td", {}, h("i", { class: "swatch", style: { background: it.color } })),
      h("td", {}, it.label),
      h("td", { class: "num" }, it.value.toLocaleString()),
      h("td", { class: "num muted" }, total ? `${((it.value / total) * 100).toFixed(1)}%` : "–")))));
  }
  function hbars(hostId, items, { value = (it) => it.value, display = (it) => it.value.toLocaleString(), sub = null, empty = "No data for these filters." } = {}) {
    const host = $(hostId);
    if (!items.length) { host.replaceChildren(h("p", { class: "muted small" }, empty)); return; }
    const max = Math.max(...items.map(value)) || 1;
    host.replaceChildren(...items.map((it) => h("div", { class: "hbar", title: `${it.label ?? it.name}: ${display(it)}${sub ? " · " + sub(it) : ""}` },
      h("span", { class: "hbar-label" }, it.label ?? it.name),
      h("span", { class: "meter" }, h("span", { style: { width: `${(value(it) / max) * 100}%` } })),
      h("span", { class: "hbar-value" }, display(it), sub ? h("small", {}, sub(it)) : null))));
  }
  function renderCharts() {
    const ch = state.charts;
    const monthFmt = new Intl.DateTimeFormat(undefined, { month: "short", year: "2-digit" });
    lineChart($("ch-trend"), ch.trend, {
      series: [{ key: "headcount", label: "Headcount", color: "var(--series-1)" }],
      xLabel: (r) => monthFmt.format(new Date(r.t + "T00:00:00")),
      tipTitle: (r) => new Date(r.t + "T00:00:00").toLocaleDateString(undefined, { month: "long", year: "numeric" }),
      tipSub: (r) => `${r.joiners} joined · ${r.exits} left`,
      points: true, height: 240, fitY: true,  // axis fitted to the data so month-to-month movement is visible
    });
    columnChart($("ch-flow"), ch.trend.map((r) => ({ ...r, label: monthFmt.format(new Date(r.t + "T00:00:00")) })), {
      series: [{ key: "joiners", label: "Joiners", color: "var(--series-1)" }, { key: "exits", label: "Exits", color: "var(--series-2)" }],
      tipTitle: (r) => new Date(r.t + "T00:00:00").toLocaleDateString(undefined, { month: "long", year: "numeric" }),
      height: 240,
    });
    donut("ch-gender", "lg-gender", ch.gender, "employees");
    donut("ch-type", "lg-type", ch.employment_type, "employees");
    hbars("ch-bu", ch.by_bu, { value: (r) => r.headcount, display: (r) => r.headcount.toLocaleString(), sub: (r) => `${pct(r.attrition)} attrition` });
    const split = ch.exit_type.map((x) => `${x.value} ${x.label.toLowerCase()}`).join(" · ");
    $("ch-reasons-sub").textContent = ch.exits_total ? `${ch.exits_total} exits in the period: ${split}` : "No exits in the period";
    hbars("ch-reasons", ch.exit_reasons, { empty: "Nobody left in this period." });
    hbars("ch-tenure", ch.tenure);
    hbars("ch-location", ch.location);
  }

  // ---------------- tables ----------------
  const DEPT_COLS = [["name", "Department"], ["headcount", "Headcount"], ["joiners", "Joiners"], ["exits", "Exits"],
    ["attrition", "Attrition"], ["voluntary", "Voluntary"], ["regrettable", "Regrettable"], ["female", "Women"]];
  function renderDeptTable() {
    const rows = [...state.charts.by_department].sort((a, b) => {
      const k = deptSort.key, av = a[k] ?? -1, bv = b[k] ?? -1;
      return (typeof av === "string" ? av.localeCompare(bv) : av - bv) * deptSort.dir;
    });
    const maxAttr = Math.max(0.0001, ...rows.map((r) => r.attrition || 0));
    $("tb-dept").replaceChildren(
      h("thead", {}, h("tr", {}, ...DEPT_COLS.map(([k, label], i) => h("th", {
        class: (i ? "num " : "") + "sortable" + (deptSort.key === k ? " sorted" : ""), scope: "col",
        "aria-sort": deptSort.key === k ? (deptSort.dir > 0 ? "ascending" : "descending") : "none",
        onclick: () => { deptSort = { key: k, dir: deptSort.key === k ? -deptSort.dir : (k === "name" ? 1 : -1) }; renderDeptTable(); },
      }, label, deptSort.key === k ? (deptSort.dir > 0 ? " ↑" : " ↓") : "")))),
      h("tbody", {}, ...(rows.length ? rows.map((r) => h("tr", {},
        h("td", {}, h("strong", {}, r.name), r.bu ? h("div", { class: "muted small" }, r.bu) : null),
        h("td", { class: "num" }, r.headcount.toLocaleString()),
        h("td", { class: "num" }, r.joiners.toLocaleString()),
        h("td", { class: "num" }, r.exits.toLocaleString()),
        h("td", { class: "num" }, h("span", { class: "cell-bar" }, h("span", { class: "meter" }, h("span", { style: { width: `${((r.attrition || 0) / maxAttr) * 100}%` } })), pct(r.attrition))),
        h("td", { class: "num" }, pct(r.voluntary)),
        h("td", { class: "num" }, pct(r.regrettable)),
        h("td", { class: "num" }, pct(r.female)))) : [h("tr", {}, h("td", { colspan: DEPT_COLS.length, class: "muted" }, "No employees match these filters."))])));
  }
  function personTable(id, people, cols, emptyText) {
    $(id).replaceChildren(
      h("thead", {}, h("tr", {}, ...cols.map(([label, , cls]) => h("th", { class: cls || "" }, label)))),
      h("tbody", {}, ...(people.length ? people.map((p) => h("tr", {}, ...cols.map(([, cell, cls]) => h("td", { class: cls || "" }, cell(p)))))
        : [h("tr", {}, h("td", { colspan: cols.length, class: "muted" }, emptyText))])));
  }
  function renderTables() {
    renderDeptTable();
    const ch = state.charts;
    const flag = (p) => (p.regrettable ? h("span", { class: "badge badge-failed badge-plain" }, "Regrettable") : "");
    $("tb-notice-sub").textContent = ch.notice_total ? `${ch.notice_total} people serving notice, soonest last day first` : "Nobody is serving notice";
    personTable("tb-notice", ch.notice, [
      ["Name", (p) => h("div", {}, personLink(p), h("div", { class: "muted small" }, p.designation))],
      ["Department", (p) => p.department],
      ["Last day", (p) => fmtDate(p.date), "nowrap"],
      ["", flag],
    ], "Nobody is serving notice.");
    $("tb-exits-sub").textContent = ch.exits_total ? `Latest ${Math.min(12, ch.exits_total)} of ${ch.exits_total} leavers in the period` : "No exits in the period";
    personTable("tb-exits", ch.recent_exits, [
      ["Name", (p) => h("div", {}, personLink(p), h("div", { class: "muted small" }, p.designation))],
      ["Left", (p) => fmtDate(p.date), "nowrap"],
      ["Type", (p) => p.type],
      ["Reason", (p) => h("div", {}, p.reason, p.regrettable ? h("div", {}, flag(p)) : null)],
    ], "Nobody left in this period.");
  }

  function renderAll() {
    renderCards();
    renderCharts();
    renderTables();
  }

  async function load() {
    const params = new URLSearchParams(new FormData(form));
    document.dispatchEvent(new CustomEvent("dash-filters", { detail: params.toString() }));  // Employees table
    try { localStorage.setItem(KEY, JSON.stringify(Object.fromEntries(params))); } catch (_) { /* optional */ }
    const mine = ++seq;
    document.getElementById("workforce").classList.add("loading");
    try {
      const res = await api(urls.api + "?" + params, undefined, "GET");
      if (mine !== seq) return;
      state = res;
      fillOptions(state.options, state.filters, state.period);
      renderAll();
    } catch (e) {
      toast("Couldn't update the dashboard: " + e.message, "error");
    } finally {
      if (mine === seq) document.getElementById("workforce").classList.remove("loading");
    }
  }
  form.addEventListener("change", (e) => {
    if (e.target.name === "bu") form.elements.department.value = "";  // department list depends on the BU
    load();
  });
  $("wf-reset").addEventListener("click", () => {
    [...form.elements].forEach((el) => { if (el.tagName === "SELECT") el.value = el.name === "period" ? "fytd" : ""; });
    load();
  });

  fillOptions(state.options, state.filters, state.period);
  renderAll();
  document.dispatchEvent(new CustomEvent("dash-filters", { detail: new URLSearchParams(new FormData(form)).toString() }));
  try {  // reopen with the filters used last time
    const saved = JSON.parse(localStorage.getItem(KEY) || "null");
    if (saved && Object.entries(saved).some(([k, v]) => (k === "period" ? v !== "fytd" : v))) {
      fillOptions(state.options, saved, saved.period);
      load();
    }
  } catch (_) { /* optional */ }
})();

// Shared helpers for every page.
(function () {
  const csrf = document.querySelector('meta[name="csrf-token"]')?.content || "";

  // Inline SVG icon from the server-provided set (window.ICONS).
  window.svgIcon = function (name, size = 16) {
    const ns = "http://www.w3.org/2000/svg";
    const svg = document.createElementNS(ns, "svg");
    for (const [k, v] of Object.entries({ class: "icon", width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: "currentColor",
      "stroke-width": 2, "stroke-linecap": "round", "stroke-linejoin": "round", "aria-hidden": "true" })) svg.setAttribute(k, v);
    svg.innerHTML = (window.ICONS || {})[name] || "";
    return svg;
  };

  // JSON fetch with CSRF header; throws Error(message) with server-provided details.
  window.api = async function api(url, body, method = "POST") {
    const res = await fetch(url, {
      method,
      headers: { "Content-Type": "application/json", "X-CSRFToken": csrf, Accept: "application/json" },
      body: body === undefined ? undefined : JSON.stringify(body),
    });
    let data = {};
    try { data = await res.json(); } catch (_) { /* non-JSON error page */ }
    if (!res.ok) {
      const err = new Error(data.error || `Request failed (${res.status})`);
      err.problems = data.problems || [];
      throw err;
    }
    return data;
  };

  // ---- toasts ----
  const toasts = document.getElementById("toasts");
  function arm(t, ms) {
    const close = () => { t.classList.add("hide"); setTimeout(() => t.remove(), 300); };
    t.querySelector(".t-close")?.addEventListener("click", close);
    if (ms) setTimeout(close, ms);
  }
  window.toast = function (message, type = "info", ms = 4500) {
    const t = document.createElement("div");
    t.className = `toast toast-${type}`;
    const text = document.createElement("span");
    text.textContent = message;
    const close = document.createElement("button");
    close.className = "t-close"; close.type = "button"; close.setAttribute("aria-label", "Dismiss");
    close.append(svgIcon("x", 15));
    t.append(svgIcon(type === "error" ? "alert" : type === "success" ? "check-circle" : "info", 18), text, close);
    toasts.append(t);
    arm(t, ms);
    return t;
  };
  toasts?.querySelectorAll(".toast").forEach((t) => arm(t, 6000));

  // ---- dates ----
  const fmt = new Intl.DateTimeFormat(undefined, { dateStyle: "medium", timeStyle: "short" });
  const rtf = new Intl.RelativeTimeFormat(undefined, { numeric: "auto" });
  window.formatLocal = (iso) => (iso ? fmt.format(new Date(iso)) : "");
  function relative(d) {
    const diff = (d - Date.now()) / 1000, abs = Math.abs(diff);
    const units = [["year", 31536000], ["month", 2592000], ["week", 604800], ["day", 86400], ["hour", 3600], ["minute", 60]];
    for (const [u, s] of units) if (abs >= s) return rtf.format(Math.round(diff / s), u);
    return diff > 0 ? "in a moment" : "just now";
  }
  window.localizeTimes = function (root = document) {
    root.querySelectorAll("time.js-local").forEach((el) => {
      const d = new Date(el.getAttribute("datetime"));
      if (!isNaN(d)) { el.textContent = fmt.format(d); el.title = d.toLocaleString(); }
    });
    root.querySelectorAll("time.js-relative").forEach((el) => {
      const d = new Date(el.getAttribute("datetime"));
      if (!isNaN(d)) { el.textContent = relative(d); el.title = fmt.format(d); }
    });
  };
  localizeTimes();

  // ---- dialogs ----
  document.addEventListener("click", (e) => {
    const opener = e.target.closest("[data-open]");
    if (opener) document.getElementById(opener.dataset.open)?.showModal();
    const closer = e.target.closest("dialog [data-close]");
    if (closer) closer.closest("dialog").close();
  });
  // Click on the backdrop closes a dialog.
  document.querySelectorAll("dialog.dlg").forEach((d) => d.addEventListener("click", (e) => { if (e.target === d) d.close(); }));

  // ---- file dropzone ----
  document.querySelectorAll(".dropzone").forEach((dz) => {
    const input = dz.querySelector("input[type=file]");
    const label = dz.querySelector("strong");
    ["dragenter", "dragover"].forEach((ev) => dz.addEventListener(ev, (e) => { e.preventDefault(); dz.classList.add("over"); }));
    ["dragleave", "drop"].forEach((ev) => dz.addEventListener(ev, () => dz.classList.remove("over")));
    dz.addEventListener("drop", (e) => {
      e.preventDefault();
      if (e.dataTransfer.files.length) { input.files = e.dataTransfer.files; input.dispatchEvent(new Event("change")); }
    });
    input.addEventListener("change", () => {
      const f = input.files[0];
      dz.classList.toggle("has-file", !!f);
      if (f && label) label.textContent = `${f.name} (${Math.max(1, Math.round(f.size / 1024))} KB) ready to import`;
    });
  });

  // ---- email address chip input (To / Cc / Bcc) ----
  const EMAIL_RE = /^[^@\s,;<>"]+@[^@\s,;<>"]+\.[^@\s,;<>"]+$/;
  window.chipInput = function (host, { values = [], placeholder = "Add email…", disabled = false, onChange } = {}) {
    let list = [...values];
    host.classList.add("chip-input");
    host.classList.toggle("disabled", disabled);
    const input = document.createElement("input");
    input.type = "text";
    input.autocomplete = "off";
    input.spellcheck = false;
    input.disabled = disabled;
    input.setAttribute("aria-label", host.dataset.label || placeholder);
    const changed = () => onChange && onChange([...list]);

    function render() {
      host.querySelectorAll(".chip-addr").forEach((c) => c.remove());
      list.forEach((addr, i) => {
        const chip = document.createElement("span");
        chip.className = "chip-addr" + (disabled ? " no-x" : "");
        chip.title = addr;
        chip.append(document.createTextNode(addr));
        if (!disabled) {
          const x = document.createElement("button");
          x.type = "button";
          x.className = "chip-x";
          x.setAttribute("aria-label", `Remove ${addr}`);
          x.append(svgIcon("x", 12));
          x.addEventListener("click", (e) => { e.stopPropagation(); list.splice(i, 1); render(); changed(); input.focus(); });
          chip.append(x);
        }
        host.insertBefore(chip, input);
      });
      input.placeholder = list.length || disabled ? "" : placeholder;
    }
    function commit(text) {
      const parts = text.split(/[,;\s]+/).map((s) => s.trim().replace(/^<|>$/g, "").toLowerCase()).filter(Boolean);
      const bad = [];
      let added = false;
      for (const p of parts) {
        if (!EMAIL_RE.test(p)) { bad.push(p); continue; }
        if (!list.includes(p)) { list.push(p); added = true; }
      }
      input.value = bad.join(", ");
      host.classList.toggle("invalid", bad.length > 0);
      host.title = bad.length ? `Not a valid email address: ${bad.join(", ")}` : "";
      if (added) { render(); changed(); }
      return bad.length === 0;
    }
    input.addEventListener("keydown", (e) => {
      if (["Enter", ",", ";", " "].includes(e.key) && input.value.trim()) { e.preventDefault(); commit(input.value); }
      else if (e.key === "Backspace" && !input.value && list.length) { list.pop(); render(); changed(); }
    });
    input.addEventListener("blur", () => { if (input.value.trim()) commit(input.value); });
    input.addEventListener("paste", (e) => {
      const t = (e.clipboardData || window.clipboardData).getData("text");
      if (/[,;\s]/.test(t.trim())) { e.preventDefault(); commit(`${input.value} ${t}`); }
    });
    input.addEventListener("input", () => host.classList.remove("invalid"));
    host.addEventListener("click", () => input.focus());
    host.append(input);
    render();
    return {
      get: () => [...list],
      set: (v) => { list = [...(v || [])]; render(); },
      clear: () => { list = []; input.value = ""; host.classList.remove("invalid"); render(); },
      flush: () => (input.value.trim() ? commit(input.value) : true), // false when an invalid address is left
      input,
    };
  };

  // ---- application themes ----
  // Any element with data-theme-choice="<key>" switches the whole app instantly and saves it to the account.
  let savingTheme = null;
  async function setTheme(key) {
    const root = document.documentElement;
    const previous = root.getAttribute("data-theme");
    if (key === previous) return;
    root.setAttribute("data-theme", key);
    try { localStorage.setItem("ns-theme", key); } catch (_) {}
    document.querySelectorAll("[data-theme-choice]").forEach((el) => {
      const on = el.dataset.themeChoice === key;
      el.classList.toggle("active", on);
      if (el.getAttribute("role") === "radio") el.setAttribute("aria-checked", String(on));
    });
    window.dispatchEvent(new Event("resize")); // redraw charts with the new palette
    const seq = (savingTheme = Symbol());
    try {
      const res = await api("/settings/theme", { theme: key });
      const label = document.getElementById("theme-pop-name");
      if (label) label.textContent = res.name;
      if (seq === savingTheme) toast(`Theme changed to ${res.name}`, "success", 2500);
    } catch (e) {
      root.setAttribute("data-theme", previous);
      toast("Couldn't save the theme: " + e.message, "error");
    }
  }
  document.addEventListener("click", (e) => {
    const choice = e.target.closest("[data-theme-choice]");
    if (choice) setTheme(choice.dataset.themeChoice);
  });
  const themeToggle = document.getElementById("theme-toggle");
  const themePop = document.getElementById("theme-pop");
  if (themeToggle && themePop) {
    themeToggle.addEventListener("click", (e) => {
      e.stopPropagation();
      themePop.hidden = !themePop.hidden;
      themeToggle.setAttribute("aria-expanded", String(!themePop.hidden));
    });
    document.addEventListener("click", (e) => {
      if (!themePop.hidden && !themePop.contains(e.target) && e.target !== themeToggle) {
        themePop.hidden = true;
        themeToggle.setAttribute("aria-expanded", "false");
      }
    });
    document.addEventListener("keydown", (e) => { if (e.key === "Escape") themePop.hidden = true; });
  }

  // ---- in-page confirmation (no blocking browser dialogs): first click arms, second click submits ----
  document.addEventListener("submit", (e) => {
    const form = e.target;
    if (!form.dataset.confirm || form.dataset.armed === "1") return;
    e.preventDefault();
    const btn = form.querySelector("button");
    const original = btn.innerHTML;
    form.dataset.armed = "1";
    btn.classList.add("armed");
    btn.style.width = "auto";
    btn.textContent = "Confirm?";
    btn.title = form.dataset.confirm;
    setTimeout(() => {
      form.dataset.armed = "";
      btn.innerHTML = original;
      btn.style.width = "";
      btn.classList.remove("armed");
    }, 4000);
  });

  // ---- tabs: <div class="tabs" data-tabs="group"> with [data-tab] buttons, panels [data-tabs-for="group"][data-tab-panel] ----
  // The open tab is kept in the URL (#name) and in this browser, and links to an element inside a panel open that panel.
  document.querySelectorAll("[data-tabs]").forEach((bar) => {
    const group = bar.dataset.tabs;
    const tabs = [...bar.querySelectorAll("[data-tab]")];
    const panels = [...document.querySelectorAll(`[data-tabs-for="${group}"]`)];
    const KEY = "ns-tab-" + group;
    if (!tabs.length || !panels.length) return;
    bar.setAttribute("role", "tablist");
    tabs.forEach((t) => {
      t.setAttribute("role", "tab");
      t.id = t.id || `tab-${group}-${t.dataset.tab}`;
    });
    panels.forEach((p) => {
      p.setAttribute("role", "tabpanel");
      p.setAttribute("aria-labelledby", `tab-${group}-${p.dataset.tabPanel}`);
    });
    function show(name, { save = true, url = false } = {}) {
      if (!tabs.some((t) => t.dataset.tab === name)) name = tabs[0].dataset.tab;
      tabs.forEach((t) => {
        const on = t.dataset.tab === name;
        t.classList.toggle("active", on);
        t.setAttribute("aria-selected", on ? "true" : "false");
        t.tabIndex = on ? 0 : -1;
      });
      let panel = null;
      panels.forEach((p) => { p.hidden = p.dataset.tabPanel !== name; if (!p.hidden) panel = p; });
      // Charts drawn while their tab was hidden had no width; draw them again now that they're visible.
      panel?.querySelectorAll(".chart, .donut-host").forEach((h) => h._chartDraw && h._chartDraw());
      document.dispatchEvent(new CustomEvent("tabshow", { detail: { group, name, panel } }));
      if (save) try { localStorage.setItem(KEY, name); } catch (_) { /* optional */ }
      if (url) history.replaceState(null, "", "#" + name);
    }
    tabs.forEach((t, i) => {
      t.addEventListener("click", () => show(t.dataset.tab, { url: true }));
      t.addEventListener("keydown", (e) => {
        const step = e.key === "ArrowRight" ? 1 : e.key === "ArrowLeft" ? -1 : 0;
        if (!step) return;
        e.preventDefault();
        const next = tabs[(i + step + tabs.length) % tabs.length];
        next.focus();
        show(next.dataset.tab, { url: true });
      });
    });
    function fromHash() {
      const id = decodeURIComponent(location.hash.slice(1));
      if (!id) return false;
      if (tabs.some((t) => t.dataset.tab === id)) { show(id, { save: false }); return true; }
      const target = document.getElementById(id);
      const panel = target && panels.find((p) => p.contains(target));
      if (!panel) return false;
      show(panel.dataset.tabPanel, { save: false });
      requestAnimationFrame(() => target.scrollIntoView({ block: "start", behavior: "smooth" }));
      return true;
    }
    window.addEventListener("hashchange", fromHash);
    if (!fromHash()) {
      let saved = null;
      try { saved = localStorage.getItem(KEY); } catch (_) { /* optional */ }
      show(saved || tabs[0].dataset.tab, { save: false });
    }
  });

  // ---- Ctrl+K (or /) jumps to the employee search in the top bar ----
  const quick = document.getElementById("tb-search");
  if (quick) {
    document.addEventListener("keydown", (e) => {
      const typing = /^(INPUT|TEXTAREA|SELECT)$/.test(document.activeElement?.tagName) || document.activeElement?.isContentEditable;
      if (((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "k") || (e.key === "/" && !typing)) {
        e.preventDefault();
        quick.focus();
        quick.select();
      } else if (e.key === "Escape" && document.activeElement === quick) {
        quick.blur();
      }
    });
  }
})();

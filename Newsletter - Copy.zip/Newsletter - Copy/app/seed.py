"""Demo data for local testing: employees, sent newsletters with realistic opens/clicks, a scheduled one and drafts.

Run with:  flask --app run seed-demo
Everything is fake (example.com addresses). Existing users and newsletters are left untouched.
"""

import random
import re
from datetime import timedelta

from . import db
from .models import Campaign, CampaignStatus, Delivery, DeliveryStatus, Event, Recipient, User, utcnow
from .services.blocks import DEFAULT_THEME, new_block_id, sanitize_content

# Realistic prompts shown in the editor's AI box for the demo newsletters.
DEMO_PROMPTS = {
    "September New Joiners": "Welcome newsletter for September's 9 new joiners. Highlight Ananya Iyer (Backend, Payments) and Daniel Thomas (Product Designer), list Sales & Support hires. Warm tone. Link: https://intranet.example.com/people/new-joiners",
    "October All-Hands Recap": "Recap of the October all-hands in 5 points: roadmap bets, office move on January 12, doubled learning budget. Link to recording https://intranet.example.com/all-hands/oct-2026",
    "Cybersecurity Awareness Month": "Cybersecurity awareness newsletter: 3 habits against phishing, a 5-minute quiz with a headphones prize draw (https://intranet.example.com/security/quiz), report to security@example.com.",
    "Engineering Monthly: November": "Engineering monthly for November: 99.98% uptime, CI build time 18 to 9 minutes, Reporting API v2 beta, hackathon winners Night Owls.",
    "Q3 Results & Wins": "Q3 results: revenue 12% above target, CSAT 4.7/5, biggest wins. Grateful, upbeat tone. Report: https://intranet.example.com/reports/q3-2026",
    "Festive Season Celebration": "Invite everyone to the festive celebration on Friday 6pm in the main cafeteria: food, music, team awards, families welcome. RSVP https://intranet.example.com/events/festive-2026",
    "Benefits Enrollment Reminder (draft)": "Reminder that benefits enrollment closes soon; explain how to review health cover and add dependents.",
    "December Newsletter (draft)": "",
}

DEPARTMENTS = {
    "Engineering": 18, "Product": 7, "Sales": 12, "Marketing": 8,
    "Customer Support": 10, "Finance": 6, "HR": 5, "Operations": 9,
}
FIRST = ["Aarav", "Aditi", "Akash", "Ananya", "Arjun", "Diya", "Farhan", "Fatima", "Gaurav", "Isha", "Kabir", "Kavya",
         "Meera", "Mohammed", "Neha", "Nikhil", "Pooja", "Priya", "Rahul", "Riya", "Rohan", "Sahil", "Sana", "Sara",
         "Shreya", "Siddharth", "Sneha", "Tanvi", "Varun", "Vikram", "Zoya", "Daniel", "Maria", "John", "Emily", "Omar",
         "Leah", "Chen", "Aisha", "Ravi", "Anjali", "Imran", "Kiran", "Lakshmi", "Manish", "Nisha", "Pranav", "Ritu"]
LAST = ["Sharma", "Verma", "Khan", "Patel", "Iyer", "Nair", "Reddy", "Gupta", "Singh", "Mehta", "Joshi", "Kapoor",
        "D'Souza", "Fernandes", "Ali", "Das", "Bose", "Chopra", "Malhotra", "Rao", "Menon", "Pillai", "Sheikh", "Thomas"]

# Engagement personality per department: (open probability, click probability given open)
ENGAGEMENT = {
    "Engineering": (0.58, 0.30), "Product": (0.72, 0.42), "Sales": (0.49, 0.22), "Marketing": (0.76, 0.45),
    "Customer Support": (0.55, 0.25), "Finance": (0.63, 0.28), "HR": (0.86, 0.50), "Operations": (0.45, 0.20),
}


def _b(type_, **fields):
    return {"id": new_block_id(), "type": type_, **fields}


def _content(brand, blocks):
    return sanitize_content({"theme": {**DEFAULT_THEME, "brand_color": brand}, "blocks": blocks})


def _footer():
    return _b("footer", html="<p>Internal Communications · Questions? Reply to this email or write to "
                             "<a href=\"mailto:comms@example.com\">comms@example.com</a></p>")


NEWSLETTERS = [
    {
        "name": "September New Joiners", "days_ago": 48, "audience": [],
        "subject": "Say hello to 9 new colleagues, {{first_name}}!",
        "preheader": "Meet the people who joined us in September.",
        "content": _content("#7c3aed", [
            _b("header", title="Welcome Aboard", subtitle="September 2026 new joiners"),
            _b("text", html="<p>Hi {{first_name}},</p><p>Nine new people joined us this month. If you see a new face "
                            "in the office or on a call, say hello and help them feel at home.</p>"),
            _b("heading", text="Engineering & Product", level=2),
            _b("columns", left_html="<p><strong>Ananya Iyer</strong><br>Backend Engineer, Payments team. "
                                    "Loves trekking and filter coffee.</p>",
                          right_html="<p><strong>Daniel Thomas</strong><br>Product Designer. Former architect "
                                     "who now designs dashboards instead of buildings.</p>"),
            _b("heading", text="Sales & Support", level=2),
            _b("text", html="<ul><li><strong>Farhan Ali</strong>, Account Executive, West region</li>"
                            "<li><strong>Sneha Rao</strong>, Customer Success Manager</li>"
                            "<li><strong>Kabir Mehta</strong>, Support Specialist</li></ul>"),
            _b("button", label="See the full welcome page", href="https://intranet.example.com/people/new-joiners"),
            _footer(),
        ]),
    },
    {
        "name": "October All-Hands Recap", "days_ago": 30, "audience": [],
        "subject": "October all-hands: the 5 things you need to know",
        "preheader": "Roadmap, office move, and a new learning budget.",
        "content": _content("#2563eb", [
            _b("header", title="All-Hands Recap", subtitle="October 2026"),
            _b("text", html="<p>Hi {{first_name}},</p><p>Missed the all-hands or want a refresher? Here are the "
                            "highlights in under two minutes.</p>"),
            _b("heading", text="1. Roadmap for the next two quarters", level=2),
            _b("text", html="<p>We are focusing on three bets: faster onboarding for customers, a self-serve "
                            "reporting module, and reliability work on the core platform.</p>"),
            _b("heading", text="2. Office move in January", level=2),
            _b("text", html="<p>Our new office in the Tech Park building opens on <strong>January 12</strong>. "
                            "Desk booking opens in December.</p>"),
            _b("heading", text="3. Learning budget doubled", level=2),
            _b("text", html="<p>Every employee now has an annual learning budget for courses, books and "
                            "conferences. <a href=\"https://intranet.example.com/hr/learning\">How to claim it</a>.</p>"),
            _b("divider"),
            _b("button", label="Watch the recording", href="https://intranet.example.com/all-hands/oct-2026"),
            _footer(),
        ]),
    },
    {
        "name": "Cybersecurity Awareness Month", "days_ago": 16, "audience": [],
        "subject": "{{first_name}}, can you spot a phishing email?",
        "preheader": "Three quick habits that keep the whole company safe.",
        "content": _content("#0f766e", [
            _b("header", title="Stay Safe Online", subtitle="Cybersecurity Awareness Month"),
            _b("text", html="<p>Hi {{first_name}},</p><p>Most security incidents start with a single click. "
                            "These three habits stop almost all of them:</p>"
                            "<ol><li>Check the sender address, not just the display name.</li>"
                            "<li>Hover over links before clicking.</li>"
                            "<li>Never share one-time passwords, not even with IT.</li></ol>"),
            _b("heading", text="Take the 5-minute quiz", level=2),
            _b("text", html="<p>Everyone who completes the phishing quiz this month enters a draw for "
                            "noise-cancelling headphones.</p>"),
            _b("button", label="Start the quiz", href="https://intranet.example.com/security/quiz"),
            _b("text", html="<p>Received something suspicious? Forward it to "
                            "<a href=\"mailto:security@example.com\">security@example.com</a>.</p>"),
            _footer(),
        ]),
    },
    {
        "name": "Engineering Monthly: November", "days_ago": 6, "audience": ["Engineering", "Product"],
        "subject": "Engineering Monthly: 99.98% uptime and a new CI pipeline",
        "preheader": "Releases, incidents, and the hackathon winners.",
        "content": _content("#ea580c", [
            _b("header", title="Engineering Monthly", subtitle="November 2026"),
            _b("text", html="<p>Hi {{first_name}},</p><p>A strong month: uptime of 99.98%, build times cut "
                            "in half, and a hackathon with 14 teams.</p>"),
            _b("heading", text="Shipped this month", level=2),
            _b("text", html="<ul><li>New CI pipeline: average build time down from 18 to 9 minutes</li>"
                            "<li>Reporting API v2 in beta with three customers</li>"
                            "<li>Dark mode for the admin console</li></ul>"),
            _b("heading", text="Hackathon winners", level=2),
            _b("text", html="<p>Team <strong>Night Owls</strong> won with an AI-assisted log search tool. "
                            "Demos are on the wiki.</p>"),
            _b("button", label="Read the hackathon write-up", href="https://wiki.example.com/eng/hackathon-2026"),
            _b("button", label="Incident review: Nov 3", href="https://wiki.example.com/eng/incidents/2026-11-03",
               color="#334155"),
            _footer(),
        ]),
    },
    {
        "name": "Q3 Results & Wins", "days_ago": 2, "audience": [],
        "subject": "Q3: we beat our target by 12%. Thank you, {{first_name}}",
        "preheader": "Results, the biggest customer wins, and what comes next.",
        "content": _content("#16a34a", [
            _b("header", title="Q3 Results", subtitle="July to September 2026"),
            _b("text", html="<p>Hi {{first_name}},</p><p>Thanks to every team, Q3 revenue came in "
                            "<strong>12% above target</strong>, and customer satisfaction reached its highest "
                            "level this year.</p>"),
            _b("columns", left_html="<p><strong>+12%</strong><br>Revenue vs. target</p>",
                          right_html="<p><strong>4.7 / 5</strong><br>Customer satisfaction</p>"),
            _b("heading", text="Biggest wins", level=2),
            _b("text", html="<ul><li>Signed our largest enterprise contract to date</li>"
                            "<li>Expanded into two new cities</li>"
                            "<li>Support response time down to under 2 hours</li></ul>"),
            _b("button", label="See the full Q3 report", href="https://intranet.example.com/reports/q3-2026"),
            _footer(),
        ]),
    },
]

SCHEDULED = {
    "name": "Festive Season Celebration", "days_ahead": 4, "audience": [],
    "subject": "You're invited: Festive celebration on Friday, {{first_name}}",
    "preheader": "Food, music and the annual awards. RSVP inside.",
    "content": _content("#db2777", [
        _b("header", title="Festive Celebration", subtitle="Friday, 6 pm · Main office cafeteria"),
        _b("text", html="<p>Hi {{first_name}},</p><p>Join us for an evening of food from around the country, "
                        "live music and the annual team awards. Families are welcome.</p>"),
        _b("heading", text="Schedule", level=2),
        _b("text", html="<ul><li>6:00 pm: Welcome and snacks</li><li>7:00 pm: Team awards</li>"
                        "<li>8:00 pm: Dinner and music</li></ul>"),
        _b("button", label="RSVP now", href="https://intranet.example.com/events/festive-2026"),
        _footer(),
    ]),
}

DRAFTS = [
    {
        "name": "Benefits Enrollment Reminder (draft)",
        "subject": "Benefits enrollment closes [date]",
        "preheader": "Review your health cover and add dependents.",
        "content": _content("#0891b2", [
            _b("header", title="Benefits Enrollment", subtitle="Open until [date]"),
            _b("text", html="<p>Hi {{first_name}},</p><p>It's time to review your benefits for next year. "
                            "You can update your health cover and add or remove dependents.</p>"),
            _b("button", label="Review my benefits", href=""),
            _footer(),
        ]),
    },
    {
        "name": "December Newsletter (draft)",
        "subject": "", "preheader": "",
        "content": _content("#2563eb", []),
    },
]


def _employees(rng):
    people, used = [], set()
    for dept, count in DEPARTMENTS.items():
        for _ in range(count):
            while True:
                first, last = rng.choice(FIRST), rng.choice(LAST)
                email = f"{first}.{last}".lower().replace("'", "") + "@example.com"
                if email not in used:
                    used.add(email)
                    break
            people.append(Recipient(email=email, name=f"{first} {last}", department=dept, active=rng.random() > 0.05))
    return people


def _links(content):
    urls = []
    for b in content["blocks"]:
        if b["type"] == "button" and b.get("href", "").startswith("http"):
            urls.append(b["href"])
        for key in ("html", "left_html", "right_html"):
            if key in b:
                urls += re.findall(r'href="(https?://[^"]+)"', b[key])
    return urls


def _simulate(rng, campaign, recipients, sent_at, now):
    """Create deliveries plus open/click events with a realistic time decay."""
    links = _links(campaign.content)
    for i, r in enumerate(recipients):
        failed = rng.random() < 0.015
        d = Delivery(
            campaign=campaign, recipient_id=r.id, email=r.email, name=r.name, attempts=3 if failed else 1,
            status=DeliveryStatus.FAILED if failed else DeliveryStatus.SENT,
            error="550 Mailbox unavailable" if failed else "",
            sent_at=None if failed else sent_at + timedelta(seconds=i // 2),
        )
        db.session.add(d)
        if failed:
            continue
        p_open, p_click = ENGAGEMENT.get(r.department, (0.55, 0.25))
        if rng.random() > p_open:
            continue
        first_open = sent_at + timedelta(minutes=rng.expovariate(1 / 240) + 2)  # most opens in the first hours
        if first_open > now:
            continue
        opens = [first_open] + [first_open + timedelta(hours=rng.uniform(1, 40)) for _ in range(rng.choice([0, 0, 1, 2]))]
        for t in opens:
            if t <= now:
                db.session.add(Event(campaign=campaign, delivery=d, type="open", user_agent="Microsoft Outlook 16.0", created_at=t))
        d.opened_at = first_open
        if links and rng.random() < p_click:
            click_at = first_open + timedelta(minutes=rng.uniform(0.3, 15))
            if click_at <= now:
                for url in rng.sample(links, k=min(len(links), rng.choice([1, 1, 1, 2]))):
                    db.session.add(Event(campaign=campaign, delivery=d, type="click", url=url,
                                         user_agent="Microsoft Outlook 16.0", created_at=click_at))
                d.clicked_at = click_at


def seed_demo(seed: int = 42) -> dict:
    if Campaign.query.filter(Campaign.name.in_(list(DEMO_PROMPTS))).count():
        return {"skipped": True}
    rng = random.Random(seed)
    now = utcnow()
    author = User.query.order_by(User.id).first()

    existing = {r.email for r in Recipient.query.all()}
    new_people = [p for p in _employees(rng) if p.email not in existing]
    db.session.add_all(new_people)
    db.session.flush()
    active = Recipient.query.filter_by(active=True).all()

    for spec in NEWSLETTERS:
        start = (now - timedelta(days=spec["days_ago"])).replace(hour=4, minute=30, second=0, microsecond=0)
        c = Campaign(
            name=spec["name"], subject=spec["subject"], preheader=spec["preheader"], content=spec["content"],
            audience={"departments": spec["audience"]}, ai_prompt=DEMO_PROMPTS.get(spec["name"], ""),
            status=CampaignStatus.SENT, scheduled_at=start, started_at=start,
            finished_at=start + timedelta(minutes=2), created_by_id=author.id if author else None,
            created_at=start - timedelta(days=2), updated_at=start,
        )
        db.session.add(c)
        targets = [r for r in active if not spec["audience"] or r.department in spec["audience"]]
        _simulate(rng, c, targets, start, now)
        failed = sum(1 for d in c.deliveries if d.status == DeliveryStatus.FAILED)
        if failed:
            c.last_error = f"{failed} email(s) could not be delivered."

    s = SCHEDULED
    when = (now + timedelta(days=s["days_ahead"])).replace(hour=4, minute=0, second=0, microsecond=0)
    db.session.add(Campaign(
        name=s["name"], subject=s["subject"], preheader=s["preheader"], content=s["content"],
        audience={"departments": s["audience"]}, ai_prompt=DEMO_PROMPTS.get(s["name"], ""),
        status=CampaignStatus.SCHEDULED, scheduled_at=when, created_by_id=author.id if author else None,
    ))
    for spec in DRAFTS:
        db.session.add(Campaign(
            name=spec["name"], subject=spec["subject"], preheader=spec["preheader"], content=spec["content"],
            audience={"departments": []}, ai_prompt=DEMO_PROMPTS.get(spec["name"], ""),
            status=CampaignStatus.DRAFT, created_by_id=author.id if author else None,
        ))
    db.session.commit()
    return {
        "skipped": False,
        "employees": len(new_people),
        "newsletters": len(NEWSLETTERS) + 1 + len(DRAFTS),
        "deliveries": Delivery.query.count(),
        "events": Event.query.count(),
    }

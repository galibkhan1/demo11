import click

from . import db
from .models import User


def register_cli(app):
    @app.cli.command("init-db")
    def init_db():
        """Create all database tables (safe to re-run)."""
        db.create_all()
        click.echo("Database tables are ready.")

    @app.cli.command("create-user")
    @click.argument("email")
    @click.option("--name", default="", help="Display name.")
    @click.password_option()
    def create_user(email, name, password):
        """Create (or reset the password of) a studio login."""
        email = email.strip().lower()
        user = User.query.filter_by(email=email).first() or User(email=email, role="admin")
        user.name = name or user.name or email.split("@")[0]
        user.session_version = (user.session_version or 0) + 1  # a reset password signs out old sessions
        user.set_password(password)
        db.session.add(user)
        db.session.commit()
        click.echo(f"User {email} saved.")

    @app.cli.command("seed-demo")
    def seed_demo_cmd():
        """Add fake employees, sent newsletters with opens/clicks, a scheduled one and drafts."""
        from .seed import seed_demo

        db.create_all()
        result = seed_demo()
        if result["skipped"]:
            click.echo("Demo data is already present; nothing added.")
        else:
            click.echo(
                f"Added {result['employees']} employees and {result['newsletters']} newsletters "
                f"({result['deliveries']} deliveries, {result['events']} open/click events)."
            )

    @app.cli.command("seed-employees")
    @click.option("--total", default=600, show_default=True, help="Number of demo employee profiles.")
    @click.option("--seed", default=11, show_default=True, help="Random seed (same seed, same data).")
    def seed_employees_cmd(total, seed):
        """Add demo employee profiles (@example.com): org chart, joiners, resignations and exits."""
        from .seed_employees import seed_employees

        db.create_all()
        result = seed_employees(total=total, seed=seed)
        if result["skipped"]:
            click.echo(f"There are already {total} or more employee profiles; nothing added.")
        else:
            click.echo(
                f"{result['profiles']} employee profiles ({result['added']} new, {result['updated_existing']} existing demo "
                f"employees updated) across {result['business_units']} business units and {result['departments']} departments: "
                f"{result['employed']} employed ({result['serving_notice']} serving notice), {result['exited']} exited."
            )

    @app.cli.command("seed-goals")
    @click.option("--seed", default=7, show_default=True, help="Random seed (same seed, same goals).")
    def seed_goals_cmd(seed):
        """Add demo goals for this financial year to employed demo employees (@example.com)."""
        from .seed_goals import seed_goals

        db.create_all()
        result = seed_goals(seed=seed)
        if not result["goals"]:
            click.echo(f"Demo employees already have goals for {result['cycle']}; nothing added ({result['total']} goals).")
        else:
            click.echo(f"Added {result['goals']} goals for {result['people']} people in {result['cycle']} "
                       f"({result['total']} goals in the cycle).")

    @app.cli.command("worker")
    def worker():
        """Run the sending worker as a standalone process."""
        import logging

        from .services.sender import run_forever

        logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
        run_forever(app)

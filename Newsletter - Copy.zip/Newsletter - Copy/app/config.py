import os
import secrets
from datetime import timedelta

from dotenv import load_dotenv

load_dotenv()


def _bool(name: str, default: bool) -> bool:
    value = os.environ.get(name)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


PROJECT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _database_url() -> str:
    url = os.environ.get("DATABASE_URL", "sqlite:///temp.db")
    # SQLite: resolve a relative file path against the project folder (e.g. sqlite:///temp.db -> <project>/temp.db).
    if url.startswith("sqlite:///") and not os.path.isabs(url[len("sqlite:///"):]):
        path = os.path.join(PROJECT_DIR, url[len("sqlite:///"):])
        return "sqlite:///" + path.replace("\\", "/")
    # Accept plain postgres:// URLs and point them at the psycopg (v3) driver.
    for prefix in ("postgres://", "postgresql://"):
        if url.startswith(prefix):
            return "postgresql+psycopg://" + url[len(prefix):]
    return url


# Known example values that must never sign sessions.
_WEAK_KEYS = {"", "dev-only-change-me", "change-me", "change-me-to-a-long-random-string", "secret", "changeme"}


def _secret_key() -> tuple[str, str]:
    """SECRET_KEY from the environment if it's strong; otherwise a random key kept in instance/secret_key.

    Returns (key, note). The note explains a fallback (logged at start-up, never the key itself).
    """
    env_key = (os.environ.get("SECRET_KEY") or "").strip()
    if len(env_key) >= 32 and env_key not in _WEAK_KEYS:
        return env_key, ""
    path = os.path.join(PROJECT_DIR, "instance", "secret_key")
    try:
        with open(path, encoding="utf-8") as fh:
            key = fh.read().strip()
    except FileNotFoundError:
        key = ""
    if len(key) < 32:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        key = secrets.token_urlsafe(48)
        with open(path, "w", encoding="utf-8") as fh:
            fh.write(key)
    why = "is missing" if not env_key else "is too short or a known example value"
    return key, f"SECRET_KEY in .env {why}, so a random key stored in instance/secret_key is used instead."


_SECRET_KEY, _SECRET_KEY_NOTE = _secret_key()


class Config:
    SECRET_KEY = _SECRET_KEY
    SECRET_KEY_NOTE = _SECRET_KEY_NOTE
    # Only to recognise click links in emails sent before the key changed (checked against the newsletter's own links).
    LEGACY_LINK_KEYS = [k for k in {(os.environ.get("SECRET_KEY") or "").strip(), "dev-only-change-me"} if k and k != _SECRET_KEY]
    SQLALCHEMY_DATABASE_URI = _database_url()
    SQLALCHEMY_ENGINE_OPTIONS = (
        # The web app and the sending worker share one SQLite file: wait for locks instead of failing.
        {"connect_args": {"timeout": 30}}
        if SQLALCHEMY_DATABASE_URI.startswith("sqlite")
        else {"pool_pre_ping": True}
    )
    MAX_CONTENT_LENGTH = 5 * 1024 * 1024  # CSV uploads / JSON payloads

    # Cookies: not readable by page scripts, not sent on cross-site requests, Secure when served over HTTPS.
    _HTTPS = os.environ.get("PUBLIC_BASE_URL", "").lower().startswith("https://")
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = "Lax"
    SESSION_COOKIE_SECURE = _bool("SESSION_COOKIE_SECURE", _HTTPS)
    REMEMBER_COOKIE_HTTPONLY = True
    REMEMBER_COOKIE_SAMESITE = "Lax"
    REMEMBER_COOKIE_SECURE = _bool("SESSION_COOKIE_SECURE", _HTTPS)
    REMEMBER_COOKIE_DURATION = timedelta(days=int(os.environ.get("REMEMBER_DAYS", "14")))
    PERMANENT_SESSION_LIFETIME = timedelta(hours=12)

    # Sign-in: this many failed attempts for one email (or from one address) lock it for this many minutes.
    LOGIN_MAX_ATTEMPTS = int(os.environ.get("LOGIN_MAX_ATTEMPTS", "5"))
    LOGIN_LOCK_MINUTES = int(os.environ.get("LOGIN_LOCK_MINUTES", "15"))
    # Behind a reverse proxy such as nginx: how many proxies to trust for the visitor's address and https.
    # 0 (the default) when people reach the app directly; deploy.sh sets 1. Only turn this on when the app can be
    # reached through the proxy alone, otherwise anyone could fake their address and dodge the sign-in lockout.
    BEHIND_PROXY = int(os.environ.get("BEHIND_PROXY", "0"))

    COMPANY_NAME = os.environ.get("COMPANY_NAME", "Our Company")
    # Absolute URL employees' mail clients use to reach this app (tracking pixel + click redirects).
    PUBLIC_BASE_URL = os.environ.get("PUBLIC_BASE_URL", "http://localhost:5000").rstrip("/")

    # Email delivery: "file" writes .eml files to OUTBOX_DIR (dev); "smtp" sends for real.
    MAIL_BACKEND = os.environ.get("MAIL_BACKEND", "file").lower()
    MAIL_FROM = os.environ.get("MAIL_FROM", "newsletter@example.com")
    MAIL_FROM_NAME = os.environ.get("MAIL_FROM_NAME", "Internal Newsletter")
    MAIL_REPLY_TO = os.environ.get("MAIL_REPLY_TO", "")
    OUTBOX_DIR = os.environ.get("OUTBOX_DIR", "outbox")
    SMTP_HOST = os.environ.get("SMTP_HOST", "localhost")
    SMTP_PORT = int(os.environ.get("SMTP_PORT", "587"))
    SMTP_USERNAME = os.environ.get("SMTP_USERNAME", "")
    SMTP_PASSWORD = os.environ.get("SMTP_PASSWORD", "")
    SMTP_USE_TLS = _bool("SMTP_USE_TLS", True)  # STARTTLS
    SMTP_USE_SSL = _bool("SMTP_USE_SSL", False)  # implicit TLS (port 465)
    SMTP_TIMEOUT = int(os.environ.get("SMTP_TIMEOUT", "30"))

    # Queue worker
    EMBEDDED_WORKER = _bool("EMBEDDED_WORKER", True)  # run the sender inside `python run.py`
    WORKER_INTERVAL_SECONDS = int(os.environ.get("WORKER_INTERVAL_SECONDS", "10"))
    SEND_RATE_PER_MINUTE = int(os.environ.get("SEND_RATE_PER_MINUTE", "120"))
    MAX_SEND_ATTEMPTS = int(os.environ.get("MAX_SEND_ATTEMPTS", "3"))

    # AI generation (Claude). Credentials come from ANTHROPIC_API_KEY.
    AI_MODEL = os.environ.get("AI_MODEL", "claude-opus-5-5")
    AI_EFFORT = os.environ.get("AI_EFFORT", "medium")  # low | medium | high | xhigh | max
    # Help assistant (chat in the corner): quick answers, and a cap on questions per person to keep costs predictable.
    HELP_EFFORT = os.environ.get("HELP_EFFORT", "low")
    HELP_MAX_QUESTIONS = int(os.environ.get("HELP_MAX_QUESTIONS", "30"))
    HELP_WINDOW_MINUTES = int(os.environ.get("HELP_WINDOW_MINUTES", "10"))

"""Spaces: the kinds of people data the studio works with (Headcount & Attrition, DEI, Performance, Goals).

After signing in, people choose a space; the dashboard, "Use your data" newsletters, recommended prompts and the
studio data sent to the AI then cover only that space. Admins open every space; everyone else only the spaces an
admin gives them (Settings → Users & access). Profile fields that belong to a space are hidden from people who
can't open it.
"""

from flask import session
from flask_login import current_user

SPACES = {
    "hr": {
        "name": "Headcount & Attrition", "icon": "users",
        "description": "Headcount, joiners, exits and attrition by team, leader and period.",
        "newsletter_title": "Headcount & Attrition Newsletter",
    },
    "dei": {
        "name": "DEI", "icon": "heart",
        "description": "Gender balance, women in leadership, hiring and attrition by gender, and age groups.",
        "newsletter_title": "DEI Newsletter",
    },
    "performance": {
        "name": "Performance", "icon": "trending-up",
        "description": "Ratings, high and low performers, and how performance relates to attrition.",
        "newsletter_title": "Performance Newsletter",
    },
    "goals": {
        "name": "Goals", "icon": "target",
        "description": "Goal progress and completion by team, and goals at risk or overdue.",
        "newsletter_title": "Goals Newsletter",
    },
}
SPACE_KEYS = tuple(SPACES)
ROLES = {"admin": "Admin", "member": "Member"}

# Employee profile fields that belong to one space: hidden from people who can't open that space.
FIELD_SPACE = {
    "date_of_resignation": "hr", "date_of_exit": "hr",
    "exit_type": "hr", "exit_reason": "hr", "regrettable": "hr",
    "performance_rating": "performance",
    "date_of_birth": "dei",
}


def user_spaces(user=None) -> list[str]:
    """The spaces this user may open, in display order."""
    user = user if user is not None else current_user
    if not user or not getattr(user, "is_authenticated", False):
        return []
    if getattr(user, "role", "admin") == "admin":
        return list(SPACE_KEYS)
    chosen = {s.strip() for s in (user.spaces or "").split(",")}
    return [k for k in SPACE_KEYS if k in chosen]


def can(space: str, user=None) -> bool:
    return space in user_spaces(user)


def current_space() -> str | None:
    """The space chosen in this session, if the user may still open it."""
    key = session.get("space")
    return key if key in SPACES and can(key) else None


def set_space(key: str) -> None:
    session["space"] = key


def clear_space() -> None:
    session.pop("space", None)


def hidden_fields(user=None) -> set[str]:
    allowed = set(user_spaces(user))
    return {field for field, space in FIELD_SPACE.items() if space not in allowed}


def clean_spaces(values) -> str:
    """Comma-separated list of valid space keys (stored on the user)."""
    keys = {str(v).strip() for v in (values or [])}
    return ",".join(k for k in SPACE_KEYS if k in keys)


def visible_status(r, hidden: set | None = None) -> str:
    """Employment status as this viewer may see it: 'Serving notice' (a resignation) is Headcount & Attrition data."""
    hidden = hidden_fields() if hidden is None else hidden
    status = r.employment_status
    return "Active" if status == "Serving notice" and "date_of_resignation" in hidden else status

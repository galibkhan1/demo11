import secrets
from datetime import date, datetime, timezone

from flask_login import UserMixin
from sqlalchemy.dialects.postgresql import JSONB
from werkzeug.security import check_password_hash, generate_password_hash

from . import db, login_manager

JSONType = db.JSON().with_variant(JSONB(), "postgresql")


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def new_token() -> str:
    return secrets.token_urlsafe(18)


class User(UserMixin, db.Model):
    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(255), unique=True, nullable=False)
    name = db.Column(db.String(255), nullable=False, default="")
    password_hash = db.Column(db.String(255), nullable=False)
    theme = db.Column(db.String(30), nullable=False, default="indigo", server_default="indigo")  # studio UI theme
    # Access: admins open every space; members only the spaces listed here (comma-separated keys, see app/spaces.py).
    role = db.Column(db.String(20), nullable=False, default="member", server_default="member")
    spaces = db.Column(db.String(200), nullable=False, default="", server_default="")
    # Changing the password bumps this, which signs out every other browser (sessions and "keep me signed in").
    session_version = db.Column(db.Integer, nullable=False, default=0, server_default="0")
    must_change_password = db.Column(db.Boolean, nullable=False, default=False, server_default=db.text("false"))
    # First-login guided tour: "" = not started, "spaces,dashboard" = the parts seen so far, "done" = finished or skipped.
    tour = db.Column(db.String(200), nullable=False, default="", server_default="")
    created_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utcnow)

    def set_password(self, password: str) -> None:
        self.password_hash = generate_password_hash(password)

    def check_password(self, password: str) -> bool:
        return check_password_hash(self.password_hash, password)

    def get_id(self) -> str:
        return f"{self.id}:{self.session_version or 0}"


@login_manager.user_loader
def load_user(user_id: str):
    raw_id, _, version = str(user_id).partition(":")
    try:
        user = db.session.get(User, int(raw_id))
    except ValueError:
        return None
    if user is None or int(version or 0) != (user.session_version or 0):
        return None  # signed out elsewhere (password changed)
    return user


class Recipient(db.Model):
    """An employee: newsletter recipient plus an optional HR profile.

    ``active`` controls whether newsletters go to them (paused / exited employees get none). The profile
    columns are optional so a plain email list still works.
    """

    __tablename__ = "recipients"

    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(255), unique=True, nullable=False)  # stored lowercase
    name = db.Column(db.String(255), nullable=False, default="")
    department = db.Column(db.String(120), nullable=False, default="", index=True)
    active = db.Column(db.Boolean, nullable=False, default=True)
    created_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utcnow)

    # HR profile (all optional)
    employee_code = db.Column(db.String(20), unique=True)
    gender = db.Column(db.String(20))
    designation = db.Column(db.String(120))
    grade = db.Column(db.String(10))
    business_unit = db.Column(db.String(120), index=True)
    location = db.Column(db.String(120))
    employment_type = db.Column(db.String(30))  # Permanent / Contract / Intern
    work_mode = db.Column(db.String(20))  # Office / Hybrid / Remote
    cost_center = db.Column(db.String(30))
    manager_id = db.Column(db.Integer, db.ForeignKey("recipients.id", ondelete="SET NULL"))
    hrbp_id = db.Column(db.Integer, db.ForeignKey("recipients.id", ondelete="SET NULL"))
    date_of_joining = db.Column(db.Date)
    date_of_resignation = db.Column(db.Date)
    date_of_exit = db.Column(db.Date)  # last working day
    exit_type = db.Column(db.String(20))  # Voluntary / Involuntary
    exit_reason = db.Column(db.String(120))
    regrettable = db.Column(db.Boolean)
    performance_rating = db.Column(db.Integer)  # 1 (low) to 5 (high)
    date_of_birth = db.Column(db.Date)
    phone = db.Column(db.String(30))

    # post_update: people can point at each other (a CFO's HRBP reports to the CFO), so links are saved in a 2nd step.
    manager = db.relationship("Recipient", remote_side=[id], foreign_keys=[manager_id], post_update=True)
    hrbp = db.relationship("Recipient", remote_side=[id], foreign_keys=[hrbp_id], post_update=True)

    @property
    def employment_status(self) -> str:
        """Active, Serving notice or Exited, from the resignation and exit dates."""
        today = date.today()
        if self.date_of_exit and self.date_of_exit <= today:
            return "Exited"
        if self.date_of_resignation and self.date_of_resignation <= today:
            return "Serving notice"
        return "Active"


class CampaignStatus:
    DRAFT = "draft"
    SCHEDULED = "scheduled"
    SENDING = "sending"
    SENT = "sent"
    FAILED = "failed"

    EDITABLE = {DRAFT, SCHEDULED}


class Campaign(db.Model):
    __tablename__ = "campaigns"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255), nullable=False, default="Untitled newsletter")
    subject = db.Column(db.String(255), nullable=False, default="")
    preheader = db.Column(db.String(255), nullable=False, default="")
    # {"theme": {...}, "blocks": [{...}, ...]} — see services/blocks.py
    content = db.Column(JSONType, nullable=False, default=dict)
    # {"departments": [...]}; an empty list means every active recipient.
    audience = db.Column(JSONType, nullable=False, default=dict)
    # Copies. Cc is shown on every employee's email; each Cc/Bcc address receives ONE untracked copy.
    cc = db.Column(JSONType, nullable=False, default=list, server_default=db.text("'[]'"))
    bcc = db.Column(JSONType, nullable=False, default=list, server_default=db.text("'[]'"))
    copy_status = db.Column(db.String(20), nullable=False, default="", server_default="")  # "", pending, sent, failed
    copy_error = db.Column(db.Text, nullable=False, default="", server_default="")
    copy_attempts = db.Column(db.Integer, nullable=False, default=0, server_default="0")
    ai_prompt = db.Column(db.Text, nullable=False, default="")
    status = db.Column(db.String(20), nullable=False, default=CampaignStatus.DRAFT, index=True)
    last_error = db.Column(db.Text, nullable=False, default="")
    scheduled_at = db.Column(db.DateTime(timezone=True), index=True)
    # Repeating schedule (services/recurring.py): this newsletter is the template; each send is a dated copy.
    repeat = db.Column(db.String(10), nullable=False, default="", server_default="")  # "", daily, weekly, monthly
    repeat_start = db.Column(db.DateTime(timezone=True))       # first send; later dates are counted from it
    repeat_count = db.Column(db.Integer, nullable=False, default=0, server_default="0")
    repeat_until = db.Column(db.Date)                          # last day a copy may go out (optional)
    repeat_refresh = db.Column(db.Boolean, nullable=False, default=False, server_default=db.text("false"))
    repeat_parent_id = db.Column(db.Integer, db.ForeignKey("campaigns.id", ondelete="SET NULL"), index=True)
    # How it was built with "Use your data" (kind, filters, focus), so a repeating send can rebuild it with new numbers.
    data_source = db.Column(JSONType, nullable=True)
    started_at = db.Column(db.DateTime(timezone=True))
    finished_at = db.Column(db.DateTime(timezone=True))
    created_by_id = db.Column(db.Integer, db.ForeignKey("users.id", ondelete="SET NULL"))
    created_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utcnow)
    updated_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utcnow, onupdate=utcnow)

    created_by = db.relationship("User")
    deliveries = db.relationship(
        "Delivery", back_populates="campaign", cascade="all, delete-orphan", passive_deletes=True
    )

    @property
    def editable(self) -> bool:
        return self.status in CampaignStatus.EDITABLE

    @property
    def repeating(self) -> bool:
        return bool(self.repeat) and self.status == CampaignStatus.SCHEDULED

    @property
    def repeat_label(self) -> str:
        from .services.recurring import describe

        return describe(self.repeat, self.repeat_start or self.scheduled_at, self.repeat_until) if self.repeat else ""


class DeliveryStatus:
    QUEUED = "queued"
    SENDING = "sending"
    SENT = "sent"
    FAILED = "failed"


class Delivery(db.Model):
    """One email to one recipient for one campaign (the send queue)."""

    __tablename__ = "deliveries"
    __table_args__ = (
        db.UniqueConstraint("campaign_id", "email", name="uq_delivery_campaign_email"),
        db.Index("ix_deliveries_status_id", "status", "id"),
    )

    id = db.Column(db.Integer, primary_key=True)
    campaign_id = db.Column(
        db.Integer, db.ForeignKey("campaigns.id", ondelete="CASCADE"), nullable=False, index=True
    )
    recipient_id = db.Column(db.Integer, db.ForeignKey("recipients.id", ondelete="SET NULL"))
    email = db.Column(db.String(255), nullable=False)
    name = db.Column(db.String(255), nullable=False, default="")
    token = db.Column(db.String(64), unique=True, nullable=False, default=new_token)
    status = db.Column(db.String(20), nullable=False, default=DeliveryStatus.QUEUED)
    attempts = db.Column(db.Integer, nullable=False, default=0)
    error = db.Column(db.Text, nullable=False, default="")
    claimed_at = db.Column(db.DateTime(timezone=True))
    sent_at = db.Column(db.DateTime(timezone=True))
    opened_at = db.Column(db.DateTime(timezone=True))  # first open
    clicked_at = db.Column(db.DateTime(timezone=True))  # first click

    campaign = db.relationship("Campaign", back_populates="deliveries")


class Event(db.Model):
    """Raw open/click events captured by the tracking endpoints."""

    __tablename__ = "events"

    id = db.Column(db.Integer, primary_key=True)
    campaign_id = db.Column(
        db.Integer, db.ForeignKey("campaigns.id", ondelete="CASCADE"), nullable=False, index=True
    )
    delivery_id = db.Column(
        db.Integer, db.ForeignKey("deliveries.id", ondelete="CASCADE"), nullable=False, index=True
    )
    type = db.Column(db.String(10), nullable=False)  # "open" | "click"
    url = db.Column(db.Text)
    user_agent = db.Column(db.String(500), nullable=False, default="")
    created_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utcnow, index=True)

    campaign = db.relationship("Campaign")
    delivery = db.relationship("Delivery")


class Goal(db.Model):
    """An employee's goal for a performance cycle (e.g. FY2026/27), with progress and status."""

    __tablename__ = "goals"

    STATUSES = ("Completed", "On track", "At risk", "Behind", "Not started")

    id = db.Column(db.Integer, primary_key=True)
    recipient_id = db.Column(db.Integer, db.ForeignKey("recipients.id", ondelete="CASCADE"), nullable=False, index=True)
    cycle = db.Column(db.String(20), nullable=False, index=True)
    title = db.Column(db.String(200), nullable=False)
    category = db.Column(db.String(40), nullable=False, default="")
    weight = db.Column(db.Integer, nullable=False, default=0)        # % of the person's goals
    progress = db.Column(db.Integer, nullable=False, default=0)      # 0 to 100
    status = db.Column(db.String(20), nullable=False, default="Not started")
    due_date = db.Column(db.Date, nullable=True)
    completed_on = db.Column(db.Date, nullable=True)
    created_at = db.Column(db.DateTime(timezone=True), nullable=False, default=utcnow)

    recipient = db.relationship("Recipient", backref=db.backref("goals", cascade="all, delete-orphan", passive_deletes=True))

import csv
import io
import re
from datetime import date

from flask import Blueprint, Response, flash, jsonify, redirect, render_template, request, url_for
from sqlalchemy.orm import joinedload
from flask_login import login_required

from .. import db
from ..models import Recipient
from ..services.addresses import is_demo_address, sending_real_email
from ..services.employees import apply_row, export_header, export_row, profile_json, tenure
from ..security import admin_required, csv_safe, is_admin
from ..spaces import can, hidden_fields
from ..services.audience import normalize_audience, person_json
from ..services.sender import audience_query

bp = Blueprint("recipients", __name__, url_prefix="/recipients")
_EMAIL = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
PAGE_SIZE = 50


def departments() -> list[str]:
    rows = db.session.query(Recipient.department).filter(Recipient.department != "").distinct().all()
    return sorted(r[0] for r in rows)


def _status_filter(status: str):
    today = date.today()
    exited = db.and_(Recipient.date_of_exit.isnot(None), Recipient.date_of_exit <= today)
    resigned = db.and_(Recipient.date_of_resignation.isnot(None), Recipient.date_of_resignation <= today)
    return {
        "employed": db.not_(exited),
        "notice": db.and_(resigned, db.not_(exited)),
        "exited": exited,
        "paused": Recipient.active.is_(False),
    }.get(status)


def _filtered_query():
    q = request.args.get("q", "").strip()
    dept = request.args.get("department", "")
    bu = request.args.get("bu", "")
    status = request.args.get("status", "")
    query = Recipient.query
    if q:
        like = f"%{q}%"
        query = query.filter(db.or_(Recipient.email.ilike(like), Recipient.name.ilike(like),
                                    Recipient.employee_code.ilike(like), Recipient.designation.ilike(like)))
    if dept:
        query = query.filter(Recipient.department == dept)
    if bu:
        query = query.filter(Recipient.business_unit == bu)
    if status == "notice" and not can("hr"):
        status = ""  # who is leaving is Headcount & Attrition data
    cond = _status_filter(status)
    if cond is not None:
        query = query.filter(cond)
    return query, {"q": q, "department": dept, "bu": bu, "status": status if cond is not None else ""}


@bp.route("/")
@login_required
def index():
    query, filters = _filtered_query()
    q, dept = filters["q"], filters["department"]
    page = (query.options(joinedload(Recipient.manager)).order_by(Recipient.name, Recipient.email)
            .paginate(per_page=PAGE_SIZE, error_out=False))
    totals = {
        "all": Recipient.query.count(),
        "active": Recipient.query.filter_by(active=True).count(),
        "employed": Recipient.query.filter(_status_filter("employed")).count(),
        "notice": Recipient.query.filter(_status_filter("notice")).count() if can("hr") else 0,
        "exited": Recipient.query.filter(_status_filter("exited")).count(),
        "paused": Recipient.query.filter_by(active=False).count(),
        "profiles": Recipient.query.filter(Recipient.employee_code.isnot(None)).count(),
    }
    bus = sorted(b for (b,) in db.session.query(Recipient.business_unit).filter(Recipient.business_unit.isnot(None)).distinct())
    dept_counts = dict(
        db.session.query(Recipient.department, db.func.count(Recipient.id))
        .filter(Recipient.department != "")
        .group_by(Recipient.department)
        .all()
    )
    demo = {"active": 0, "paused": 0, "real": sending_real_email()}
    for email, active in Recipient.query.with_entities(Recipient.email, Recipient.active):
        if is_demo_address(email):
            demo["active" if active else "paused"] += 1
    return render_template(
        "recipients/index.html",
        demo=demo,
        filters=filters,
        bus=bus,
        tenure=tenure,
        page=page,
        q=q,
        dept=dept,
        departments=departments(),
        dept_counts=dept_counts,
        totals=totals,
        show_hr=can("hr"),
        can_manage=is_admin(),
    )


@bp.route("/demo", methods=["POST"])
@login_required
@admin_required
def demo_toggle():
    """Pause (or resume) every employee with a demo address. Reversible; history and stats are kept."""
    resume = request.form.get("action") == "resume"
    people = [r for r in Recipient.query.filter_by(active=not resume) if is_demo_address(r.email)
              and not (resume and r.employment_status == "Exited")]  # people who left stay paused
    for r in people:
        r.active = resume
    db.session.commit()
    n = len(people)
    flash(f"{'Resumed' if resume else 'Paused'} {n} demo employee{'' if n == 1 else 's'}.", "success")
    return redirect(url_for(".index"))


@bp.route("/add", methods=["POST"])
@login_required
@admin_required
def add():
    email = request.form.get("email", "").strip().lower()
    if not _EMAIL.match(email):
        flash("Enter a valid email address.", "error")
        return redirect(url_for(".index"))
    recipient = Recipient.query.filter_by(email=email).first() or Recipient(email=email)
    recipient.name = request.form.get("name", "").strip()[:255]
    recipient.department = request.form.get("department", "").strip()[:120]
    recipient.active = True
    db.session.add(recipient)
    db.session.commit()
    flash(f"Saved {email}.", "success")
    return redirect(url_for(".index"))


@bp.route("/import", methods=["POST"])
@login_required
@admin_required
def import_csv():
    upload = request.files.get("file")
    if not upload or not upload.filename:
        flash("Choose a CSV file to import.", "error")
        return redirect(url_for(".index"))
    try:
        text = upload.read().decode("utf-8-sig")
    except UnicodeDecodeError:
        flash("The file must be UTF-8 encoded CSV.", "error")
        return redirect(url_for(".index"))

    reader = csv.DictReader(io.StringIO(text))
    fields = {(f or "").strip().lower(): f for f in (reader.fieldnames or [])}
    if "email" not in fields:
        flash("The CSV needs a header row with at least an 'email' column. Export the list to see every supported column.", "error")
        return redirect(url_for(".index"))

    existing = {r.email: r for r in Recipient.query.all()}
    created = updated = skipped = 0
    rows, problems = [], []
    for line, row in enumerate(reader, start=2):
        email = (row.get(fields["email"]) or "").strip().lower()
        if not _EMAIL.match(email):
            skipped += 1
            continue
        recipient = existing.get(email)
        if recipient is None:
            recipient = Recipient(email=email)
            db.session.add(recipient)
            existing[email] = recipient
            created += 1
        else:
            updated += 1
        rows.append((line, recipient, row))
    # Second pass, once everyone in the file exists: profile columns (manager / HRBP are given by email).
    codes = {r.employee_code: r for r in existing.values() if r.employee_code}
    for line, recipient, row in rows:
        problems += [f"row {line}: {p}" for p in apply_row(recipient, row, fields, existing)]
        if recipient.employee_code and codes.get(recipient.employee_code, recipient) is not recipient:
            problems.append(f"row {line}: employee ID {recipient.employee_code} is already used")
            recipient.employee_code = None
        elif recipient.employee_code:
            codes[recipient.employee_code] = recipient
        # Newsletters go to people still employed; a past exit date pauses them.
        recipient.active = not (recipient.date_of_exit and recipient.date_of_exit <= date.today())
    db.session.commit()
    msg = f"Import finished: {created} added, {updated} updated, {skipped} skipped (invalid email)."
    if problems:
        msg += f" {len(problems)} value(s) were skipped, e.g. " + "; ".join(problems[:3]) + "."
    flash(msg, "success" if not problems else "info")
    return redirect(url_for(".index"))


@bp.route("/export.csv")
@login_required
def export_csv():
    """Every employee matching the current filters, with all profile columns (also a template for import)."""
    query, _filters = _filtered_query()
    people = query.options(joinedload(Recipient.manager), joinedload(Recipient.hrbp)).order_by(Recipient.name).all()
    out = io.StringIO()
    writer = csv.writer(out)
    hidden = hidden_fields()
    writer.writerow(export_header(hidden))
    for r in people:
        writer.writerow(export_row(r, hidden))
    return Response("\ufeff" + out.getvalue(), mimetype="text/csv",
                    headers={"Content-Disposition": f"attachment; filename=employees-{date.today():%Y-%m-%d}.csv"})


@bp.route("/<int:recipient_id>/profile")
@login_required
def profile(recipient_id):
    r = db.get_or_404(Recipient, recipient_id)
    reports = Recipient.query.filter(Recipient.manager_id == r.id).order_by(Recipient.name).all()
    data = profile_json(r, hidden_fields())
    if can("goals"):
        from ..models import Goal
        from ..services.workforce import _fy_label, _fy_start

        cycle = _fy_label(_fy_start(date.today()))
        goals = Goal.query.filter_by(recipient_id=r.id, cycle=cycle).order_by(Goal.due_date).all()
        data["goals"] = {"cycle": cycle, "items": [
            {"title": g.title, "progress": g.progress, "status": g.status, "due": f"{g.due_date:%d %b %Y}" if g.due_date else ""}
            for g in goals]}
    data["name"] = r.name or r.email
    data["email"] = r.email
    data["direct_reports"] = {"count": len(reports),
                              "names": [p.name for p in reports if p.employment_status != "Exited"][:12]}
    return jsonify(data)


@bp.route("/<int:recipient_id>/toggle", methods=["POST"])
@login_required
@admin_required
def toggle(recipient_id):
    recipient = db.get_or_404(Recipient, recipient_id)
    recipient.active = not recipient.active
    db.session.commit()
    return redirect(request.referrer or url_for(".index"))


@bp.route("/<int:recipient_id>/delete", methods=["POST"])
@login_required
@admin_required
def delete(recipient_id):
    recipient = db.get_or_404(Recipient, recipient_id)
    db.session.delete(recipient)
    db.session.commit()
    flash(f"Removed {recipient.email}.", "success")
    return redirect(request.referrer or url_for(".index"))


@bp.route("/count", methods=["GET", "POST"])
@login_required
def count():
    """Active recipients for an audience: POST {"audience": {...}} or GET ?department=..."""
    if request.method == "POST":
        audience = normalize_audience((request.get_json(silent=True) or {}).get("audience"))
    else:
        selected = [d for d in request.args.getlist("department") if d]
        audience = {"mode": "departments", "departments": selected} if selected else {"mode": "all"}
    return jsonify(count=audience_query(audience).count())


def _name_from_email(email: str) -> str:
    """priya.sharma@company.com → Priya Sharma (a starting point; it can be edited on the Employees page)."""
    local = email.split("@")[0]
    return " ".join(part.capitalize() for part in re.split(r"[._\-+]+", local) if part)[:255]


@bp.route("/quick-add", methods=["POST"])
@login_required
@admin_required
def quick_add():
    """Add employees by email from the newsletter's "Specific employees" picker; returns them so they get selected.

    Addresses already on the Employees page are returned as they are. Paused or exited people aren't switched back on
    from here (that's a deliberate choice on the Employees page).
    """
    data = request.get_json(silent=True) or {}
    raw = data.get("emails") if isinstance(data.get("emails"), list) else []
    emails, problems = [], []
    for value in raw[:50]:
        email = str(value).strip().strip(",;<>").lower()
        if not email:
            continue
        if len(email) > 255 or not _EMAIL.match(email):
            problems.append(f"{email} isn't a valid email address.")
        elif email not in emails:
            emails.append(email)
    people, added = [], 0
    for email in emails:
        r = Recipient.query.filter_by(email=email).first()
        if r and not r.active:
            why = "has left the company" if r.employment_status == "Exited" else "is paused on the Employees page"
            problems.append(f"{email} {why}, so they weren't added. Resume them on the Employees page to include them.")
            continue
        if not r:
            r = Recipient(email=email, name=_name_from_email(email), department="", active=True)
            db.session.add(r)
            added += 1
        people.append(r)
    db.session.commit()
    if sending_real_email() and any(is_demo_address(r.email) for r in people):
        problems.append("Demo addresses (like @example.com) are skipped while the app sends real email.")
    if not people:
        return jsonify(error=" ".join(problems) or "Type an email address to add.", problems=problems), 400
    return jsonify(people=[person_json(r) for r in people], added=added, problems=problems)


@bp.route("/people")
@login_required
def people():
    """Search active employees for the "Specific employees" picker."""
    q = request.args.get("q", "").strip()
    dept = request.args.get("department", "")
    try:
        limit = max(1, min(int(request.args.get("limit", 100)), 300))
    except ValueError:
        limit = 100
    query = Recipient.query.filter(Recipient.active.is_(True))
    if q:
        like = f"%{q}%"
        query = query.filter(db.or_(Recipient.name.ilike(like), Recipient.email.ilike(like)))
    if dept:
        query = query.filter(Recipient.department == dept)
    total = query.count()
    rows = query.order_by(Recipient.name, Recipient.email).limit(limit).all()
    return jsonify(people=[person_json(r) for r in rows], total=total, limit=limit)

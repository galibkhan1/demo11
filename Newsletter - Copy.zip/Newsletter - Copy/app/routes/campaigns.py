from collections import Counter, defaultdict
from datetime import date, datetime, timedelta, timezone

from flask import Blueprint, abort, current_app, flash, jsonify, redirect, render_template, request, url_for
from flask_login import current_user, login_required
from sqlalchemy import func

from .. import db
from ..models import Campaign, CampaignStatus, Delivery, DeliveryStatus, Event, Recipient, utcnow
from ..services import mailer, renderer
from ..services.addresses import clean_copies, is_demo_address, sending_real_email
from ..services.ai import AIError, generate_newsletter
from ..services.blocks import BLOCK_DEFAULTS, DEFAULT_THEME, FONTS, preflight_problems, sanitize_content
from ..services.metrics import campaign_metrics
from ..services.audience import audience_people, normalize_audience
from ..services.insights import best_time, snapshot, studio_data_text
from ..security import is_admin
from ..spaces import SPACES, can, current_space
from ..services.hr_storyboard import build_hr_storyboard
from ..services.storyboard import PERIODS, build_storyboard
from ..services.workforce import FILTER_KEYS as WF_FILTERS, PERIODS as WF_PERIODS, options as wf_options
from ..services.sender import audience_query
from .recipients import _EMAIL, departments

bp = Blueprint("campaigns", __name__, url_prefix="/campaigns")


def _get(campaign_id: int) -> Campaign:
    return db.get_or_404(Campaign, campaign_id)


def _require_editable(campaign: Campaign):
    if not campaign.editable:
        abort(409, description="This newsletter has already been sent and can no longer be edited.")


def _payload() -> dict:
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        abort(400, description="Expected a JSON body.")
    return data


def _clean_audience(raw) -> dict:
    return normalize_audience(raw)


def _campaign_json(c: Campaign) -> dict:
    return {
        "id": c.id,
        "name": c.name,
        "subject": c.subject,
        "preheader": c.preheader,
        "content": c.content,
        "audience": normalize_audience(c.audience),
        "audience_people": audience_people(c.audience),
        "ai_prompt": c.ai_prompt,
        "status": c.status,
        "editable": c.editable,
        "scheduled_at": c.scheduled_at.isoformat() if c.scheduled_at else None,
        "repeat": c.repeat or "",
        "repeat_until": c.repeat_until.isoformat() if c.repeat_until else None,
        "repeat_refresh": bool(c.repeat_refresh),
        "repeat_label": c.repeat_label,
        "from_data": bool(c.data_source),
        "cc": c.cc or [],
        "bcc": c.bcc or [],
        "copy_status": c.copy_status,
    }


@bp.errorhandler(400)
@bp.errorhandler(409)
def _json_errors(err):
    if request.is_json or request.accept_mimetypes.best == "application/json":
        return jsonify(error=err.description), err.code
    return err


@bp.route("/")
@login_required
def index():
    campaigns = Campaign.query.order_by(Campaign.updated_at.desc()).all()
    tab_counts = Counter(c.status for c in campaigns)
    return render_template(
        "campaigns/index.html", campaigns=campaigns, metrics=campaign_metrics(), tab_counts=tab_counts
    )


@bp.route("/new", methods=["POST"])
@login_required
def new():
    prompt = request.form.get("prompt", "").strip()[:5000]
    # Started from an Insights idea or recommendation: it can bring a name and an audience.
    audience = {"mode": "all"}
    ids = [i for i in request.form.get("employee_ids", "").split(",") if i.strip()]
    depts = request.form.getlist("departments")
    if ids:
        audience = normalize_audience({"mode": "employees", "employee_ids": ids})
    elif depts:
        audience = normalize_audience({"mode": "departments", "departments": depts})
    if audience["mode"] != "all" and not (audience.get("employee_ids") or audience.get("departments")):
        audience = {"mode": "all"}
    campaign = Campaign(
        name=request.form.get("name", "").strip()[:255] or "Untitled newsletter",
        content={"theme": dict(DEFAULT_THEME), "blocks": []},
        audience=audience,
        ai_prompt=prompt,
        created_by_id=current_user.id,
    )
    db.session.add(campaign)
    db.session.commit()
    kind = request.form.get("kind", "")
    if request.form.get("storyboard") and kind in SPACES and can(kind):
        # Newsletter from a space's data (Headcount & Attrition, DEI, Performance, Goals), scoped like its dashboard.
        period = request.form.get("period", "fytd")
        scope = {k: (request.form.get(k) or "").strip()[:120] or None for k in WF_FILTERS}
        return redirect(url_for(".edit", campaign_id=campaign.id, storyboard=1, kind=kind,
                                period=(period if period in WF_PERIODS else "fytd") if kind == "hr" else None, **scope,
                                focus=request.form.get("focus", "").strip()[:1000] or None))
    if request.form.get("storyboard"):
        # Started from "Newsletter from these numbers": the editor builds it from the studio's data right away.
        period = request.form.get("period", "30")
        return redirect(url_for(".edit", campaign_id=campaign.id, storyboard=1,
                                period=period if period in PERIODS else "30",
                                department=request.form.get("department") or None,
                                focus=request.form.get("focus", "").strip()[:1000] or None))
    # Started from the dashboard prompt box: the editor generates the first draft right away.
    return redirect(url_for(".edit", campaign_id=campaign.id, autogen=1 if prompt else None,
                            data=1 if prompt and request.form.get("use_data") else None))


def _hr_options():
    """Scope choices for the Headcount & attrition storyboard, or None when there are no employee profiles."""
    people = Recipient.query.filter(Recipient.date_of_joining.isnot(None)).all()
    return {**wf_options(people), "periods": [{"value": k, "label": v} for k, v in WF_PERIODS.items()]} if people else None


@bp.route("/<int:campaign_id>/edit")
@login_required
def edit(campaign_id):
    campaign = _get(campaign_id)
    return render_template(
        "campaigns/editor.html",
        campaign=campaign,
        campaign_json=_campaign_json(campaign),
        block_defaults=BLOCK_DEFAULTS,
        default_theme=DEFAULT_THEME,
        fonts=list(FONTS),
        departments=departments(),
        best_time=best_time(snapshot()),
        hr_options=_hr_options(),
        story_space=current_space(),
    )


@bp.route("/<int:campaign_id>/save", methods=["POST"])
@login_required
def save(campaign_id):
    campaign = _get(campaign_id)
    _require_editable(campaign)
    data = _payload()
    campaign.name = str(data.get("name") or "Untitled newsletter").strip()[:255]
    campaign.subject = str(data.get("subject") or "").strip()[:255]
    campaign.preheader = str(data.get("preheader") or "").strip()[:255]
    campaign.content = sanitize_content(data.get("content"))
    campaign.audience = _clean_audience(data.get("audience"))
    if "cc" in data or "bcc" in data:
        campaign.cc, campaign.bcc, _ = clean_copies(data.get("cc"), data.get("bcc"))
    if "ai_prompt" in data:
        campaign.ai_prompt = str(data.get("ai_prompt") or "")[:5000]
    db.session.commit()
    return jsonify(ok=True, content=campaign.content, updated_at=campaign.updated_at.isoformat())


@bp.route("/<int:campaign_id>/generate", methods=["POST"])
@login_required
def generate(campaign_id):
    campaign = _get(campaign_id)
    _require_editable(campaign)
    data = _payload()
    content = sanitize_content(data.get("content"))
    current = None
    if data.get("mode") == "revise":
        current = {"subject": data.get("subject", ""), "preheader": data.get("preheader", ""), "content": content}
    try:
        result = generate_newsletter(
            str(data.get("prompt", ""))[:5000],
            current=current,
            theme=content["theme"],
            studio_data=studio_data_text(space=current_space()) if data.get("use_data") else None,
        )
    except AIError as exc:
        return jsonify(error=str(exc)), 502
    campaign.ai_prompt = str(data.get("prompt", ""))[:5000]
    if data.get("mode") != "revise":
        campaign.data_source = None
    db.session.commit()
    return jsonify(result)


@bp.route("/<int:campaign_id>/storyboard", methods=["POST"])
@login_required
def storyboard(campaign_id):
    campaign = _get(campaign_id)
    _require_editable(campaign)
    data = _payload()
    kind = data.get("kind")
    if kind in SPACES and not can(kind):
        return jsonify(error="You don't have access to that space."), 403
    if kind in ("dei", "performance", "goals"):
        from ..services.space_newsletter import build_space_newsletter

        theme = sanitize_content(data.get("content") or campaign.content)["theme"]
        filters = {k: str(data.get(k) or "")[:120] for k in WF_FILTERS}
        focus = str(data.get("focus") or "")[:1000]
        try:
            result = build_space_newsletter(kind, filters=filters, focus=focus, theme=theme,
                                            use_ai=data.get("use_ai", True) is not False)
        except ValueError as exc:
            return jsonify(error=str(exc)), 400
        campaign.data_source = {"kind": kind, "filters": filters, "focus": focus}
        db.session.commit()
        return jsonify(result)
    if kind == "hr":
        period = str(data.get("period") or "fytd")
        if period not in WF_PERIODS:
            return jsonify(error="Unknown period."), 400
        theme = sanitize_content(data.get("content") or campaign.content)["theme"]
        filters = {k: str(data.get(k) or "")[:120] for k in WF_FILTERS}
        focus = str(data.get("focus") or "")[:1000]
        try:
            result = build_hr_storyboard(period=period, filters=filters, focus=focus, theme=theme,
                                         use_ai=data.get("use_ai", True) is not False)
        except ValueError as exc:
            return jsonify(error=str(exc)), 400
        campaign.data_source = {"kind": "hr", "period": period, "filters": filters, "focus": focus}
        db.session.commit()
        return jsonify(result)
    period = str(data.get("period") or "30")
    department = str(data.get("department") or "")
    if period not in PERIODS:
        return jsonify(error="Unknown period."), 400
    if department and department not in departments():
        return jsonify(error="Unknown department."), 400
    theme = sanitize_content(data.get("content") or campaign.content)["theme"]
    focus = str(data.get("focus") or "")[:1000]
    result = build_storyboard(period=period, department=department, focus=focus,
                              theme=theme, use_ai=data.get("use_ai", True) is not False)
    campaign.data_source = {"kind": "engagement", "period": period, "department": department, "focus": focus}
    db.session.commit()
    return jsonify(result)


@bp.route("/<int:campaign_id>/preview", methods=["POST"])
@login_required
def preview(campaign_id):
    _get(campaign_id)
    data = _payload()
    html = renderer.render_html(
        subject=str(data.get("subject", "")),
        preheader=str(data.get("preheader", "")),
        content=sanitize_content(data.get("content")),
        preview=True,
    )
    return jsonify(html=html)


@bp.route("/<int:campaign_id>/test", methods=["POST"])
@login_required
def send_test(campaign_id):
    campaign = _get(campaign_id)
    data = _payload()
    to = str(data.get("email", "")).strip().lower()
    if not _EMAIL.match(to):
        return jsonify(error="Enter a valid email address."), 400
    cc, bcc, invalid = clean_copies(data.get("cc"), data.get("bcc"))
    if invalid:
        return jsonify(error="These addresses aren't valid: " + ", ".join(invalid)), 400
    cc = [a for a in cc if a != to]
    bcc = [a for a in bcc if a != to]
    if sending_real_email():
        demo = [a for a in [to] + cc + bcc if is_demo_address(a)]
        if demo:
            return jsonify(error="These are demo addresses that can't receive real email: " + ", ".join(demo)), 400
    template = renderer.render_campaign_template(campaign, track=False)
    email = renderer.personalize(template, name=current_user.name or to.split("@")[0], email=to)
    try:
        with mailer.get_backend() as backend:
            backend.send(
                mailer.build_message(
                    to_email=to,
                    subject=f"[TEST] {email.subject}",
                    html=email.html,
                    text=email.text,
                    cc=cc or None,
                ),
                [to] + cc + bcc,
            )
    except Exception as exc:  # noqa: BLE001 — surface backend problems to the user
        current_app.logger.exception("Test send failed")
        return jsonify(error=f"Could not send: {exc}"), 502
    where = " (written to the outbox folder)" if current_app.config["MAIL_BACKEND"] == "file" else ""
    extra = []
    if cc:
        extra.append(f"Cc {len(cc)}")
    if bcc:
        extra.append(f"Bcc {len(bcc)}")
    extra_text = f" ({', '.join(extra)})" if extra else ""
    return jsonify(ok=True, message=f"Test email sent to {to}{extra_text}{where}.")


@bp.route("/<int:campaign_id>/schedule", methods=["POST"])
@login_required
def schedule(campaign_id):
    campaign = _get(campaign_id)
    _require_editable(campaign)
    data = _payload()

    problems = preflight_problems(campaign.subject, campaign.content or {})
    campaign.audience = _clean_audience(data.get("audience", campaign.audience))
    if campaign.audience.get("mode", "all") == "all" and not is_admin():
        problems.append("Only an admin can send to all employees. In To, choose departments or specific people, or ask an admin to send it.")
    if audience_query(campaign.audience).count() == 0:
        problems.append("No active recipients match the selected audience.")
    if "cc" in data or "bcc" in data:
        campaign.cc, campaign.bcc, invalid = clean_copies(data.get("cc"), data.get("bcc"))
        if invalid:
            problems.append("Fix these Cc/Bcc addresses: " + ", ".join(invalid))
    if sending_real_email():
        demo = [e for (e,) in audience_query(campaign.audience).with_entities(Recipient.email) if is_demo_address(e)]
        if demo:
            many = len(demo) != 1
            problems.append(
                f"{len(demo)} recipient{'s' if many else ''} {'have' if many else 'has'} a demo address such as {demo[0]}, "
                "which can't receive real email. In To, choose Specific employees and pick real people, "
                "or pause the demo employees on the Employees page."
            )
        demo_copies = [a for a in (campaign.cc or []) + (campaign.bcc or []) if is_demo_address(a)]
        if demo_copies:
            problems.append("Cc/Bcc has demo addresses that can't receive real email: " + ", ".join(demo_copies))

    from ..services.recurring import REPEATS

    repeat = str(data.get("repeat") or "")
    if repeat and repeat not in REPEATS:
        problems.append("Choose how often it repeats.")
    until = None
    if repeat and data.get("repeat_until"):
        try:
            until = date.fromisoformat(str(data["repeat_until"])[:10])
        except ValueError:
            problems.append("The end date is not a valid date.")
    send_at = utcnow()
    if data.get("send_at"):
        try:
            send_at = datetime.fromisoformat(str(data["send_at"]))
        except ValueError:
            problems.append("The send time is not a valid date.")
        else:
            if send_at.tzinfo is None:
                send_at = send_at.replace(tzinfo=timezone.utc)
            if send_at < utcnow() - timedelta(minutes=1):
                problems.append("The send time is in the past.")
    if until and until < send_at.astimezone().date():
        problems.append("The end date is before the first send.")
    if problems:
        db.session.rollback()
        return jsonify(error="Fix these before scheduling:", problems=problems), 400

    campaign.status = CampaignStatus.SCHEDULED
    campaign.scheduled_at = send_at
    campaign.last_error = ""
    campaign.repeat = repeat
    campaign.repeat_start = send_at if repeat else None
    campaign.repeat_count = 0
    campaign.repeat_until = until
    campaign.repeat_refresh = bool(repeat and data.get("refresh") and campaign.data_source)
    db.session.commit()
    return jsonify(ok=True, status=campaign.status, scheduled_at=send_at.isoformat(), repeat=repeat,
                   repeat_label=campaign.repeat_label)


@bp.route("/<int:campaign_id>/unschedule", methods=["POST"])
@login_required
def unschedule(campaign_id):
    campaign = _get(campaign_id)
    if campaign.status == CampaignStatus.SCHEDULED:
        repeating = bool(campaign.repeat)
        campaign.status = CampaignStatus.DRAFT
        campaign.scheduled_at = None
        campaign.repeat = ""
        db.session.commit()
        flash("The repeating schedule is stopped. Newsletters it already sent stay in your list; this one is a draft again."
              if repeating else "Sending cancelled. The newsletter is a draft again.", "success")
    return redirect(request.referrer or url_for(".edit", campaign_id=campaign.id))


@bp.route("/<int:campaign_id>/duplicate", methods=["POST"])
@login_required
def duplicate(campaign_id):
    source = _get(campaign_id)
    copy = Campaign(
        name=f"{source.name} (copy)"[:255],
        subject=source.subject,
        preheader=source.preheader,
        content=sanitize_content(source.content),
        audience=source.audience,
        cc=list(source.cc or []),
        bcc=list(source.bcc or []),
        ai_prompt=source.ai_prompt,
        data_source=source.data_source,
        created_by_id=current_user.id,
    )
    db.session.add(copy)
    db.session.commit()
    return redirect(url_for(".edit", campaign_id=copy.id))


@bp.route("/<int:campaign_id>/delete", methods=["POST"])
@login_required
def delete(campaign_id):
    campaign = _get(campaign_id)
    if not is_admin() and campaign.created_by_id != current_user.id:
        flash("You can only delete newsletters you created. Ask an admin to delete this one.", "error")
        return redirect(url_for(".index"))
    if campaign.status == CampaignStatus.SENDING:
        flash("A newsletter can't be deleted while it is sending.", "error")
        return redirect(url_for(".index"))
    db.session.delete(campaign)
    db.session.commit()
    flash(f"Deleted “{campaign.name}”.", "success")
    return redirect(url_for(".index"))


@bp.route("/<int:campaign_id>/stats")
@login_required
def stats(campaign_id):
    campaign = _get(campaign_id)
    status_counts = dict(
        db.session.query(Delivery.status, func.count(Delivery.id))
        .filter(Delivery.campaign_id == campaign.id)
        .group_by(Delivery.status)
        .all()
    )
    delivered = status_counts.get(DeliveryStatus.SENT, 0)
    opened, clicked = (
        db.session.query(func.count(Delivery.opened_at), func.count(Delivery.clicked_at))
        .filter(Delivery.campaign_id == campaign.id, Delivery.status == DeliveryStatus.SENT)
        .one()
    )
    summary = {
        "total": sum(status_counts.values()),
        "delivered": delivered,
        "failed": status_counts.get(DeliveryStatus.FAILED, 0),
        "pending": status_counts.get(DeliveryStatus.QUEUED, 0) + status_counts.get(DeliveryStatus.SENDING, 0),
        "opened": opened,
        "clicked": clicked,
        "open_rate": opened / delivered if delivered else None,
        "click_rate": clicked / delivered if delivered else None,
        "click_to_open": clicked / opened if opened else None,
    }

    # Hourly activity for the first 72 hours after sending started.
    timeline = []
    if campaign.started_at:
        start = campaign.started_at.replace(minute=0, second=0, microsecond=0)
        if start.tzinfo is None:
            start = start.replace(tzinfo=timezone.utc)
        rows = (
            db.session.query(Event.type, Event.created_at)
            .filter(Event.campaign_id == campaign.id, Event.created_at < start + timedelta(hours=72))
            .all()
        )
        buckets = defaultdict(Counter)
        for kind, created in rows:
            if created.tzinfo is None:
                created = created.replace(tzinfo=timezone.utc)
            hour = int((created - start).total_seconds() // 3600)
            buckets[max(hour, 0)][kind] += 1
        last = max(buckets) if buckets else 0
        hours = min(72, max(last + 1, 12))
        timeline = [
            {"t": (start + timedelta(hours=h)).isoformat(), "open": buckets[h]["open"], "click": buckets[h]["click"]}
            for h in range(hours)
        ]

    links = (
        db.session.query(Event.url, func.count(Event.id), func.count(func.distinct(Event.delivery_id)))
        .filter(Event.campaign_id == campaign.id, Event.type == "click")
        .group_by(Event.url)
        .order_by(func.count(Event.id).desc())
        .limit(20)
        .all()
    )

    dept_rows = (
        db.session.query(
            Recipient.department,
            func.count(Delivery.id),
            func.count(Delivery.opened_at),
            func.count(Delivery.clicked_at),
        )
        .join(Recipient, Recipient.id == Delivery.recipient_id)
        .filter(Delivery.campaign_id == campaign.id, Delivery.status == DeliveryStatus.SENT)
        .group_by(Recipient.department)
        .order_by(func.count(Delivery.id).desc())
        .all()
    )
    by_department = [
        {"name": d or "(none)", "sent": s, "open_rate": o / s if s else 0, "click_rate": c / s if s else 0}
        for d, s, o, c in dept_rows
    ]
    by_department.sort(key=lambda r: r["open_rate"], reverse=True)

    show = request.args.get("show", "all")
    filters = {
        "opened": Delivery.opened_at.isnot(None),
        "clicked": Delivery.clicked_at.isnot(None),
        "unopened": db.and_(Delivery.opened_at.is_(None), Delivery.status == DeliveryStatus.SENT),
        "failed": Delivery.status == DeliveryStatus.FAILED,
    }
    recipients_q = Delivery.query.filter_by(campaign_id=campaign.id)
    show_counts = {"all": recipients_q.count()}
    for key, cond in filters.items():
        show_counts[key] = recipients_q.filter(cond).count()
    if show in filters:
        recipients_q = recipients_q.filter(filters[show])
    else:
        show = "all"
    page = recipients_q.order_by(Delivery.opened_at.desc().nullslast(), Delivery.email).paginate(
        per_page=50, error_out=False
    )
    return render_template(
        "campaigns/stats.html",
        campaign=campaign,
        summary=summary,
        timeline=timeline,
        links=links,
        by_department=by_department,
        page=page,
        show=show,
        show_counts=show_counts,
    )

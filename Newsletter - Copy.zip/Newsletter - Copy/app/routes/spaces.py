"""'Choose your space': the page everyone lands on after signing in, and the space switcher."""

from urllib.parse import urlsplit

from flask import Blueprint, flash, redirect, render_template, request, url_for
from flask_login import current_user, login_required

from ..spaces import SPACES, can, current_space, set_space, user_spaces

bp = Blueprint("spaces", __name__, url_prefix="/spaces")


def _safe_next(target: str) -> str:
    if not target or not target.startswith("/") or target.startswith("//") or urlsplit(target).netloc:
        return ""
    return "" if target.startswith(("/spaces", "/login", "/logout")) else target


@bp.route("/")
@login_required
def choose():
    mine = user_spaces(current_user)
    cards = [{"key": k, **SPACES[k]} for k in mine]  # no numbers here: they show once a space is opened
    return render_template("spaces.html", cards=cards, current=current_space(),
                           next_url=_safe_next(request.args.get("next", "")))


@bp.route("/select", methods=["POST"])
@login_required
def select():
    key = request.form.get("space", "")
    if key not in SPACES or not can(key):
        flash("You don't have access to that space. Ask an admin.", "error")
        return redirect(url_for(".choose"))
    set_space(key)
    return redirect(_safe_next(request.form.get("next", "")) or url_for("dashboard.index"))

import csv
import io
from datetime import date

from flask import Blueprint, Response, jsonify, redirect, render_template, request, url_for
from flask_login import login_required

from ..services.workforce import FILTER_KEYS, workforce_kpis
from ..spaces import current_space

bp = Blueprint("dashboard", __name__)


@bp.route("/")
@login_required
def index():
    """The dashboard of the space the user works in (newsletter performance lives on the Insights page)."""
    space = current_space()
    if not space:
        return redirect(url_for("spaces.choose"))
    if space == "hr":
        return render_template("dashboard.html", workforce=workforce_kpis("fytd"))
    from ..services.space_reports import space_report

    return render_template("space_dashboard.html", report=space_report(space))


@bp.route("/workforce")
@login_required
def workforce():
    """KPI cards, charts and tables for the Headcount & Attrition dashboard filters (JSON)."""
    if current_space() != "hr":
        return jsonify(error="Open the Headcount & Attrition space to see these numbers."), 403
    filters = {k: request.args.get(k, "")[:120] for k in FILTER_KEYS}
    return jsonify(workforce_kpis(request.args.get("period", "fytd"), filters))


@bp.route("/space-data")
@login_required
def space_data():
    """KPI groups and panels for the DEI, Performance or Goals dashboard filters (JSON)."""
    from ..services.space_reports import space_report

    space = current_space()
    if space not in ("dei", "performance", "goals"):
        return jsonify(error="Open the DEI, Performance or Goals space to see these numbers."), 403
    filters = {k: request.args.get(k, "")[:120] for k in FILTER_KEYS}
    return jsonify(space_report(space, filters))


TABLE_ROWS = 10


def _employees(filters: dict) -> tuple[list, str]:
    """People employed today who match the dashboard filters, by name (people without a profile count as employed)."""
    from ..models import Recipient
    from ..services.workforce import select_people

    people, scope, _leader = select_people(filters, Recipient.query.all())
    today = date.today()

    def employed(r):
        if r.date_of_joining and r.date_of_joining > today:
            return False
        return not (r.date_of_exit and r.date_of_exit <= today)

    staff = sorted((r for r in people if employed(r)), key=lambda r: (r.name or r.email).lower())
    return staff, scope


@bp.route("/employees")
@login_required
def employees_table():
    """First rows of the dashboard's Employees table (JSON), for the same filters as the dashboard."""
    from ..spaces import hidden_fields, visible_status

    filters = {k: request.args.get(k, "")[:120] for k in FILTER_KEYS}
    staff, scope = _employees(filters)
    hidden = hidden_fields()
    rows = [{
        "name": r.name or r.email.split("@")[0], "email": r.email, "code": r.employee_code or "",
        "designation": r.designation or "", "department": r.department or "", "bu": r.business_unit or "",
        "location": r.location or "", "manager": (r.manager.name or r.manager.email) if r.manager else "",
        "joined": r.date_of_joining.strftime("%d %b %Y") if r.date_of_joining else "",
        "status": visible_status(r, hidden), "paused": not r.active,
    } for r in staff[:TABLE_ROWS]]
    return jsonify(total=len(staff), rows=rows, scope=scope)


@bp.route("/employees.csv")
@login_required
def employees_csv():
    """Every employee matching the dashboard filters, with the profile columns this user may see."""
    from ..services.employees import export_header, export_row
    from ..spaces import hidden_fields

    filters = {k: request.args.get(k, "")[:120] for k in FILTER_KEYS}
    staff, _scope = _employees(filters)
    hidden = hidden_fields()
    out = io.StringIO()
    writer = csv.writer(out)
    writer.writerow(export_header(hidden))
    for r in staff:
        writer.writerow(export_row(r, hidden))
    return Response("\ufeff" + out.getvalue(), mimetype="text/csv",
                    headers={"Content-Disposition": f"attachment; filename=employees-{date.today():%Y-%m-%d}.csv"})

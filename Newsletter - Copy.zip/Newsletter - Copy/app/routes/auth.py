from urllib.parse import urlsplit

from flask import Blueprint, flash, redirect, render_template, request, session, url_for
from flask_login import current_user, login_required, login_user, logout_user

from ..models import User
from ..security import login_throttle
from ..spaces import clear_space

bp = Blueprint("auth", __name__)


@bp.route("/login", methods=["GET", "POST"])
def login():
    if current_user.is_authenticated:
        return redirect(url_for("dashboard.index"))
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()[:255]
        ip = request.remote_addr or "?"
        wait = login_throttle.blocked_for(email, ip)
        if wait:
            flash(f"Too many failed sign-in attempts. Try again in {max(1, round(wait / 60))} minute"
                  f"{'s' if round(wait / 60) != 1 else ''}.", "error")
            return render_template("login.html"), 429
        user = User.query.filter_by(email=email).first()
        if user and user.check_password(request.form.get("password", "")):
            login_throttle.succeeded(email, ip)
            session.clear()  # fresh session on sign-in (nothing carried over from before)
            login_user(user, remember=bool(request.form.get("remember")))
            clear_space()
            if user.must_change_password:
                flash("Welcome! Please choose your own password to continue.", "info")
                return redirect(url_for("settings.index") + "#security")
            target = request.args.get("next", "")
            # Only follow same-site relative redirects.
            if not target.startswith("/") or target.startswith("//") or urlsplit(target).netloc:
                target = ""
            # Everyone lands on "Choose your space" first, then continues to where they were going.
            return redirect(url_for("spaces.choose", next=target or None))
        login_throttle.failed(email, ip)
        flash("Incorrect email or password.", "error")
    return render_template("login.html")


@bp.route("/logout", methods=["POST"])
@login_required
def logout():
    logout_user()
    clear_space()
    return redirect(url_for("auth.login"))

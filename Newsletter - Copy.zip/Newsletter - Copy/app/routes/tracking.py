"""Public endpoints hit from inside delivered emails (no login)."""

import base64
import html
import json

from flask import Blueprint, Response, abort, redirect, request

from .. import db
from ..models import Campaign, Delivery, Event, utcnow
from ..services.renderer import unsign_url, unsign_url_legacy

bp = Blueprint("tracking", __name__, url_prefix="/t")

_PIXEL = base64.b64decode("R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7")


def _record(delivery: Delivery, kind: str, url: str | None = None) -> None:
    now = utcnow()
    if delivery.opened_at is None:
        delivery.opened_at = now  # a click implies the email was opened (images may be blocked)
    if kind == "click" and delivery.clicked_at is None:
        delivery.clicked_at = now
    db.session.add(
        Event(
            campaign_id=delivery.campaign_id,
            delivery_id=delivery.id,
            type=kind,
            url=url,
            user_agent=(request.headers.get("User-Agent") or "")[:500],
        )
    )
    db.session.commit()


@bp.route("/o/<token>.gif")
def open_pixel(token):
    delivery = Delivery.query.filter_by(token=token).first()
    if delivery is not None:
        _record(delivery, "open")
    resp = Response(_PIXEL, mimetype="image/gif")
    resp.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
    return resp


@bp.route("/c/<token>")
def click(token):
    signed = request.args.get("u", "")
    url = unsign_url(signed)
    delivery = Delivery.query.filter_by(token=token).first()
    if url is None:
        # Emails sent before the signing key changed: only follow links that really are in that newsletter.
        url = unsign_url_legacy(signed)
        campaign = db.session.get(Campaign, delivery.campaign_id) if delivery else None
        text = json.dumps(campaign.content, ensure_ascii=False) if campaign else ""
        if url is None or not (url in text or html.escape(url) in text or url.replace("/", "\\/") in text):
            abort(400)
    if delivery is not None:
        _record(delivery, "click", url)
    return redirect(url, code=302)

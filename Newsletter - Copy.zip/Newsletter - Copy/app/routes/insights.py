from flask import Blueprint, jsonify, render_template, request
from flask_login import login_required

from ..models import Campaign, CampaignStatus, Recipient
from ..services import insights
from ..services.metrics import campaign_metrics, department_engagement
from ..services.prompts import suggest_prompts
from ..services.ai import AIError, suggest_topics
from ..services.blocks import sanitize_content
from .recipients import departments
from ..spaces import SPACES, current_space

bp = Blueprint("insights", __name__, url_prefix="/insights")


@bp.route("/")
@login_required
def index():
    snap = insights.snapshot()
    return render_template(
        "insights.html",
        **newsletter_overview(),
        snap=snap,
        recs=insights.recommendations(snap),
        best_time=insights.best_time(snap),
        by_hour=insights.opens_by_hour(snap),
        facts=insights.studio_facts(snap, current_space()),
        fact_groups=([SPACES[current_space()]["name"] if current_space() != "hr" else "Workforce"] if current_space() else [])
        + ["People", "Newsletters", "Engagement"],
        prompt_ideas=suggest_prompts("30", "", space=current_space()),
    )


def newsletter_overview() -> dict:
    """Newsletter performance tiles, engagement trend, up next, recent newsletters (moved here from the dashboard)."""
    sent = Campaign.query.filter_by(status=CampaignStatus.SENT).order_by(Campaign.started_at.asc()).all()
    sent_ids = [c.id for c in sent]
    metrics = campaign_metrics(sent_ids)
    delivered = sum(m["sent"] for m in metrics.values())
    opened = sum(m["opened"] for m in metrics.values())
    clicked = sum(m["clicked"] for m in metrics.values())
    last = metrics.get(sent_ids[-1]) if sent_ids else None
    stats = {
        "recipients": Recipient.query.filter_by(active=True).count(),
        "departments": Recipient.query.with_entities(Recipient.department).filter(Recipient.department != "").distinct().count(),
        "sent_campaigns": len(sent_ids),
        "delivered": delivered,
        "open_rate": opened / delivered if delivered else None,
        "click_rate": clicked / delivered if delivered else None,
        "last_open_rate": last["open_rate"] if last else None,
    }
    trend = [
        {"t": c.started_at.isoformat(), "label": c.name,
         "open": round((metrics.get(c.id, {}).get("open_rate") or 0) * 100, 1),
         "click": round((metrics.get(c.id, {}).get("click_rate") or 0) * 100, 1)}
        for c in sent[-10:] if c.started_at
    ]
    upcoming = (Campaign.query.filter(Campaign.status.in_([CampaignStatus.SCHEDULED, CampaignStatus.SENDING]))
                .order_by(Campaign.scheduled_at).limit(3).all())
    recent = Campaign.query.order_by(Campaign.updated_at.desc()).limit(6).all()
    return {
        "stats": stats,
        "trend": trend,
        "upcoming": upcoming,
        "recent": recent,
        "recent_metrics": campaign_metrics([c.id for c in recent]),
        "engaged_departments": department_engagement(sent_ids)[:6],
    }


@bp.route("/review", methods=["POST"])
@login_required
def review():
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        return jsonify(error="Expected a JSON body."), 400
    result = insights.review_draft(
        str(data.get("subject") or "")[:255],
        str(data.get("preheader") or "")[:255],
        sanitize_content(data.get("content")),
        data.get("audience"),
    )
    return jsonify(result)


@bp.route("/prompts")
@login_required
def prompts():
    period = request.args.get("period", "30")
    department = request.args.get("department", "")
    if department and department not in departments():
        department = ""
    return jsonify(suggest_prompts(period, department, include_hr=True, space=current_space()))


@bp.route("/facts")
@login_required
def facts():
    return jsonify(facts=insights.studio_facts(space=current_space()))


@bp.route("/ideas", methods=["POST"])
@login_required
def ideas():
    try:
        result = suggest_topics(insights.ideas_context(space=current_space()), departments())
    except AIError as exc:
        return jsonify(error=str(exc)), 502
    return jsonify(ideas=result)

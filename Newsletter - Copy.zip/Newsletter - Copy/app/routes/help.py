"""The help assistant: the chat in the corner of every page (static/js/help.js)."""

import json
import math

from flask import Blueprint, Response, current_app, jsonify, request, stream_with_context, url_for
from flask_login import current_user, login_required

from ..security import help_limit
from ..services import help_bot

bp = Blueprint("help", __name__, url_prefix="/help")


def _page() -> str:
    ep = request.endpoint or ""
    if ep == "campaigns.edit":
        return "editor"
    if ep == "campaigns.stats":
        return "stats"
    return {"spaces": "spaces", "dashboard": "dashboard", "campaigns": "newsletters", "insights": "insights",
            "recipients": "employees", "settings": "settings"}.get(ep.split(".")[0], "other")


def help_config():
    """What the chat widget needs, or None where it shouldn't appear (signed out, or choosing a new password first)."""
    if not current_user.is_authenticated or getattr(current_user, "must_change_password", False):
        return None
    from ..spaces import current_space, user_spaces

    page = _page()
    return {
        "page": page,
        "user": current_user.id,
        "first": (current_user.name or "").split(" ")[0],
        "ai": help_bot.ai_enabled(),
        "editor": page == "editor",
        # New newsletters need a space first (see _choose_space_first), unless the person has no spaces at all.
        "canStart": bool(current_space()) or not user_spaces(current_user),
        "suggestions": help_bot.suggestions(page, current_space()),
        "urls": {"chat": url_for("help.chat"), "new": url_for("campaigns.new")},
    }


@bp.route("/chat", methods=["POST"])
@login_required
def chat():
    data = request.get_json(silent=True) or {}
    try:
        messages = help_bot.clean_messages(data.get("messages"))
    except ValueError as exc:
        return jsonify(error=str(exc)), 400
    if not help_bot.ai_enabled():
        return jsonify(error="The help assistant needs the AI key. Ask an admin to add ANTHROPIC_API_KEY to .env and restart."), 503
    wait = help_limit.hit(f"user:{current_user.id}")
    if wait:
        return jsonify(error=f"That's a lot of questions in a short time. Try again in {math.ceil(wait / 60)} minute(s)."), 429

    from ..spaces import SPACES, current_space, user_spaces

    page = str(data.get("page") or "")
    key = current_space()
    cfg = current_app.config
    system = help_bot.system_blocks(
        company=cfg["COMPANY_NAME"], role=current_user.role,
        spaces=[SPACES[k]["name"] for k in user_spaces(current_user)],
        space=SPACES[key]["name"] if key else "", page=page if page in help_bot.PAGES else "other")
    model, effort = cfg["AI_MODEL"], cfg.get("HELP_EFFORT", "low")

    def events():
        for event in help_bot.stream_answer(messages, system, model=model, effort=effort):
            yield json.dumps(event) + "\n"

    resp = Response(stream_with_context(events()), mimetype="application/x-ndjson")
    resp.headers["Cache-Control"] = "no-store"
    resp.headers["X-Accel-Buffering"] = "no"  # let proxies pass each piece on as it's written
    return resp

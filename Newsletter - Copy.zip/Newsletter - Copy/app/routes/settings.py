import re

from flask import Blueprint, flash, jsonify, redirect, render_template, request, url_for
from flask_login import current_user, login_required, login_user

from .. import db
from ..models import User
from ..security import admin_required
from ..spaces import ROLES, SPACES, clean_spaces
from ..themes import THEMES

bp = Blueprint("settings", __name__, url_prefix="/settings")


@bp.route("/")
@login_required
def index():
    users = User.query.order_by(User.name, User.email).all() if current_user.role == "admin" else []
    return render_template("settings.html", users=users, roles=ROLES)


def _admins_left(excluding_id: int) -> int:
    return User.query.filter(User.role == "admin", User.id != excluding_id).count()


@bp.route("/users", methods=["POST"])
@login_required
@admin_required
def add_user():
    """Add a studio login with its role and the spaces it may open."""
    email = request.form.get("email", "").strip().lower()
    name = request.form.get("name", "").strip()[:255]
    password = request.form.get("password", "")
    role = request.form.get("role", "member")
    if not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", email):
        flash("Enter a valid email address.", "error")
    elif User.query.filter_by(email=email).first():
        flash(f"{email} already has a login. Change their access in the list below.", "error")
    elif len(password) < 8:
        flash("The temporary password must be at least 8 characters.", "error")
    elif role not in ROLES:
        flash("Choose a role.", "error")
    else:
        user = User(email=email, name=name or email.split("@")[0], role=role, must_change_password=True,
                    spaces=clean_spaces(request.form.getlist("spaces")) if role == "member" else "")
        user.set_password(password)
        db.session.add(user)
        db.session.commit()
        flash(f"{user.name} can now sign in. Share the temporary password with them privately; they'll choose their own when they first sign in.", "success")
    return redirect(url_for(".index") + "#users")


@bp.route("/users/<int:user_id>", methods=["POST"])
@login_required
@admin_required
def update_user(user_id):
    user = db.get_or_404(User, user_id)
    role = request.form.get("role", user.role)
    if role not in ROLES:
        flash("Choose a role.", "error")
    elif role != "admin" and user.role == "admin" and not _admins_left(user.id):
        flash("There must be at least one admin.", "error")
    else:
        user.role = role
        user.spaces = clean_spaces(request.form.getlist("spaces")) if role == "member" else ""
        db.session.commit()
        if role == "member" and not user.spaces:
            flash(f"{user.name} can't open any space now; they can still write newsletters from a prompt.", "info")
        else:
            flash(f"Access updated for {user.name}.", "success")
    return redirect(url_for(".index") + "#users")


@bp.route("/users/<int:user_id>/delete", methods=["POST"])
@login_required
@admin_required
def delete_user(user_id):
    user = db.get_or_404(User, user_id)
    if user.id == current_user.id:
        flash("You can't remove your own login.", "error")
    elif user.role == "admin" and not _admins_left(user.id):
        flash("There must be at least one admin.", "error")
    else:
        db.session.delete(user)
        db.session.commit()
        flash(f"Removed {user.email}.", "success")
    return redirect(url_for(".index") + "#users")


@bp.route("/theme", methods=["POST"])
@login_required
def theme():
    data = request.get_json(silent=True) or {}
    key = data.get("theme")
    if key not in THEMES:
        return jsonify(error="Unknown theme."), 400
    current_user.theme = key
    db.session.commit()
    return jsonify(ok=True, theme=key, name=THEMES[key]["name"])


@bp.route("/profile", methods=["POST"])
@login_required
def profile():
    name = request.form.get("name", "").strip()[:255]
    if not name:
        flash("Your name can't be empty.", "error")
    else:
        current_user.name = name
        db.session.commit()
        flash("Profile updated.", "success")
    return redirect(url_for(".index"))


@bp.route("/password", methods=["POST"])
@login_required
def password():
    current = request.form.get("current", "")
    new = request.form.get("new", "")
    if not current_user.check_password(current):
        flash("Your current password is incorrect.", "error")
    elif len(new) < 8:
        flash("The new password must be at least 8 characters.", "error")
    elif new != request.form.get("confirm", ""):
        flash("The new passwords don't match.", "error")
    elif new == current:
        flash("Choose a password that's different from the current one.", "error")
    else:
        user = current_user._get_current_object()
        user.set_password(new)
        user.must_change_password = False
        user.session_version = (user.session_version or 0) + 1  # signs out every other browser
        db.session.commit()
        login_user(user)  # stay signed in here with the new session
        flash("Password changed. Any other signed-in browsers have been signed out.", "success")
    return redirect(url_for(".index"))

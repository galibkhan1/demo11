"""First-login guided tour: which parts each person has seen, skipping it, and taking it again.

The tour has four parts, each shown the first time someone opens that page: the space chooser, the dashboard,
the newsletters list and the editor. Progress is kept on the user, so it follows them to any browser.
"""

from flask import Blueprint, jsonify, redirect, request, url_for
from flask_login import current_user, login_required

from .. import db

bp = Blueprint("tour", __name__, url_prefix="/tour")

CHAPTERS = ("spaces", "dashboard", "newsletters", "editor")
DONE = "done"


def _seen(user) -> list[str]:
    state = getattr(user, "tour", "") or ""
    if state == DONE:
        return list(CHAPTERS)
    return [c for c in CHAPTERS if c in state.split(",")]


def tour_config(chapter: str):
    """What the page needs to show its part of the tour, or None when this person has already seen it."""
    if chapter not in CHAPTERS or not current_user.is_authenticated or getattr(current_user, "must_change_password", False):
        return None
    if (current_user.tour or "") == DONE:
        return None
    seen = _seen(current_user)
    if chapter in seen:
        return None
    from ..spaces import SPACES, current_space

    key = current_space()
    return {
        "chapter": chapter,
        "fresh": not seen,  # the very first part shown starts with the welcome
        "remaining": [c for c in CHAPTERS if c not in seen and c != chapter],
        "total": len(CHAPTERS),
        "first": (current_user.name or "").split(" ")[0],
        "space": SPACES[key]["name"] if key else "",
        "urls": {"progress": url_for("tour.progress"), "skip": url_for("tour.skip"),
                 "newsletters": url_for("campaigns.index")},
    }


@bp.route("/progress", methods=["POST"])
@login_required
def progress():
    data = request.get_json(silent=True) or {}
    chapter = str(data.get("chapter") or "")
    if chapter not in CHAPTERS:
        return jsonify(error="Unknown part of the tour."), 400
    if (current_user.tour or "") != DONE:
        seen = set(_seen(current_user)) | {chapter}
        current_user.tour = DONE if seen >= set(CHAPTERS) else ",".join(c for c in CHAPTERS if c in seen)
        db.session.commit()
    return jsonify(ok=True, done=current_user.tour == DONE)


@bp.route("/skip", methods=["POST"])
@login_required
def skip():
    current_user.tour = DONE
    db.session.commit()
    return jsonify(ok=True, done=True)


@bp.route("/restart", methods=["POST"])
@login_required
def restart():
    """Take the tour again from the start (the ? button in the sidebar)."""
    current_user.tour = ""
    db.session.commit()
    return redirect(url_for("spaces.choose"))

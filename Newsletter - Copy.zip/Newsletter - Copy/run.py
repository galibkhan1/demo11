"""Development entry point: `python run.py` serves the studio and runs the sending worker."""

import logging
import os

from app import create_app
from app.services.sender import start_background_worker

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")

app = create_app()
_cfg = app.config
if _cfg["MAIL_BACKEND"] == "smtp":
    logging.getLogger("newsletter").info("Mail: sending real email through %s:%s", _cfg["SMTP_HOST"], _cfg["SMTP_PORT"])
else:
    logging.getLogger("newsletter").info("Mail: saving emails to the %s folder (MAIL_BACKEND=file)", _cfg["OUTBOX_DIR"])

if __name__ == "__main__":
    host = os.environ.get("HOST", "127.0.0.1")
    debug = os.environ.get("FLASK_DEBUG", "0") == "1"
    if debug and host not in ("127.0.0.1", "localhost", "::1"):
        # The debugger can run code: never offer it to other machines.
        logging.getLogger("newsletter").warning("FLASK_DEBUG ignored: debug mode only runs when HOST is 127.0.0.1.")
        debug = False
    # With the debug reloader, only the child process (WERKZEUG_RUN_MAIN) should run the worker.
    if app.config["EMBEDDED_WORKER"] and (not debug or os.environ.get("WERKZEUG_RUN_MAIN") == "true"):
        start_background_worker(app)
    app.run(host=host, port=int(os.environ.get("PORT", "5000")), debug=debug)

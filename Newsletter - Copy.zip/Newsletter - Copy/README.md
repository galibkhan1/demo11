# Newsletter Studio

An in-house tool for writing, sending and measuring internal employee newsletters.

- **Spaces:** after signing in, everyone lands on **Choose your space**. A space is one kind of people data: **Headcount & Attrition**, **DEI**, **Performance** or **Goals**. The cards show no numbers; the numbers appear once you open a space. Inside a space, the dashboard, **Use your data** newsletters, the recommended prompts, the studio numbers and the data sent to the AI (**Include studio data**) cover only that space. The sidebar shows the current space; click it to switch. Writing newsletters from a prompt, the newsletter list, Insights and Employees work in every space.
- **Users & access (admins):** in **Settings → Users & access**, admins add logins (name, email, temporary password) and choose for each person **Admin** (every space, manages access) or **Member** (only the spaces ticked). Members only see their spaces on the chooser and can't open or build newsletters from other spaces. Employee profile fields that belong to a space are hidden from people who can't open it: exit type, reason and regrettable (Headcount & Attrition), performance rating (Performance), date of birth (DEI) and goals (Goals), in the profile dialog and the CSV export. Members without any space can still write newsletters from a prompt. There is always at least one admin, and admins can't remove themselves. Existing logins became admins when spaces were added.
- **AI writer:** describe the newsletter in plain language and Claude drafts it as editable blocks. You can then ask for revisions ("make it shorter", "add a key dates section").
- **Drag-and-drop editor:** header, heading, text, image, button, two-column, stats, divider, spacer and footer blocks. Edit text directly on the email, choose brand colors and fonts, preview on desktop and mobile, and undo changes.
- **Scheduling and queued sending:** send now or at a set time, to everyone or to selected departments. A background worker sends at a set rate per minute and retries failures.
- **Repeating newsletters:** in **Send or schedule**, choose **Repeat**, then the first send (date and time), **Every day / Every week / Every month** and, optionally, **Ends on**. The dialog sums it up ("Every month on the 1st at 09:00, starting 01 Dec 2026, until 31 Mar 2027"); monthly on the 29th to 31st uses the month's last day when it's shorter, and dates follow this computer's local time. The newsletter becomes the template: each send is saved as its own dated newsletter ("Monthly people update · 01 Dec 2026") with its own opens and clicks, and changes you save to the template go into the next sends. For a newsletter built with **Use your data**, tick **Rebuild with the latest numbers before each send** to send fresh numbers and a new summary every time (text changed by hand is replaced; if the rebuild fails, the saved version is sent). Sends missed while the app wasn't running aren't sent in a burst: one catch-up, then the next date. The editor banner, the newsletter card and Insights → Up next show the schedule and the next send; **Stop repeating** ends it (copies already sent stay). Repeating sends need the app (its built-in worker) to be running.
- **Analytics:** open and click rates, hourly activity, top links, engagement by department, and status per recipient.
- **Numbers in newsletters:** the **Stats** block shows 1 to 4 key figures as big numbers. The AI writer puts the figures from your prompt into a Stats block automatically. Tick **Include studio data** to let it also use the studio's own numbers: workforce totals for the financial year to date (headcount, joiners, exits, attrition, voluntary and regrettable attrition, serving notice, each against last year), attrition by department and business unit, top exit reasons, recipients per department, newsletters sent, and open and click rates. Only these totals are sent, never names or addresses. **Insert studio numbers** in the Blocks tab adds them without AI.
- **Recommendations:** the **Insights** page compares your sent newsletters and says what works: the best day and time to send, how fast people open, subject-line patterns (names, numbers, length), departments that open less, employees who haven't opened recently, and button placement and length. Each recommendation shows its evidence and whether it's a strong or an early signal. Some come with a one-click draft, such as a targeted update for a low-engagement department. The send dialog suggests the best time.
- **Draft check:** the editor's **Tips** tab scores the current draft against your past results (subject, preview text, leftover [placeholders], length, buttons, key figures, alt text, audience) and offers fixes: jump to the block, or a ready AI instruction.
- **Two ways to make a newsletter:** the editor's **AI writer** tab has two choices at the top. **Write a prompt** (the default): describe the newsletter and click **Generate**. **Use your data**: no prompt needed; pick the numbers (headcount & attrition, or newsletter engagement), the period and the team, and click **Build newsletter**. Both make an ordinary newsletter you can edit, revise with a prompt, test and send.
- **Newsletter from your data (engagement):** built from the studio's own numbers, laid out like an analytics brief: a banner with the period and audience, an executive summary, headline KPI cards with ▲/▼ change against the previous period, a key-metrics grid, open rate by newsletter (bars), who opened (share bar), engagement by department and most-clicked links (tables), what to try next, and a footer with the definitions. Build it in AI writer → **Use your data** (choose the period, audience and an optional focus) or with **Newsletter from these numbers** on the Insights page. With AI on, Claude writes the summary from the computed numbers only; without AI, a standard summary is used. AI revisions ("make it shorter") never change the charts, tables or KPI cards. Charts are built from email-safe tables, so they show in Outlook and Gmail, and the cards stack two per row on phones.
- **Recommended prompts under the AI box:** right below **Describe your newsletter**, a row of ready-made prompts built from your data: a people update with attrition by team, a welcome for this month's new joiners that already lists each of them (name, role, team, office, joining date and manager, from their profiles; only fun facts are left for you to add, and you see every name in the box before anything goes to the AI), an update for the business unit with the highest attrition, a retention note for managers, and ideas from your newsletter engagement. Below them are starters for common newsletters (all-hands recap, policy change, event invitation, results with numbers, security reminder). Click one to fill the box (data prompts also tick **Include studio data**), replace the [brackets] with your facts, then click **Generate**. Each prompt follows the same shape: who it's for, what to cover, the facts, the tone and the length.
- **Suggested prompts from your data:** the studio works out prompts from the latest numbers, with no AI call. There are focus questions for a newsletter built from your data ("Why does Engineering read least?", "The 9 we're not reaching") and newsletter briefs for the AI writer ("Update for Engineering", "More on the Q3 report"), with [brackets] for the facts you add. They appear as chips in the editor (under **Use your data** they follow its period and audience), on the dashboard and on the Insights page, where each one starts a draft in one click. They never name individual employees.
- **AI topic ideas:** on the Insights page, Claude reads the engagement summary and suggests what to send next, each with the data behind it. **Create draft** turns an idea into a newsletter.
- **Personalization:** `{{first_name}}`, `{{name}}` and `{{email}}` work in the subject and body.
- **To / Cc / Bcc:** To, Cc, Bcc, Subject and Preview sit in the editor's **AI writer** tab, just above **Refine the current draft** (under the data card when you use **Use your data**), so the email preview gets the full height. **To** is the audience: all active employees, chosen departments, or specific employees picked by name. The picker has search, a department filter and "Select all shown". To include someone who isn't on the Employees page yet, type (or paste) their email address in the search box and press Enter, or click **Add …**: they're added to Employees (name taken from the address, editable later) and selected. Several addresses separated by commas or spaces can be added at once. Paused or exited people aren't switched back on from here. Each employee still gets their own personalized, tracked email. **Cc** addresses appear on every employee's email, and each one receives a single copy. **Bcc** addresses are never shown and also receive a single copy. If a Cc/Bcc address belongs to an employee in the audience, that person gets only their personal email. The copy isn't tracked, so it doesn't affect the stats. The **Send test** dialog also accepts Cc and Bcc.
- **Employee profiles:** besides name, email and department, each employee can have an employee ID, gender, designation, grade, business unit, location, employment type, work mode, cost centre, manager, HR business partner, date of joining, date of resignation, date of exit, exit type and reason, regrettable exit, performance rating, date of birth and phone. The Employees page filters by status (employed, serving notice, exited, newsletters paused), department and business unit, searches by name, email, ID or designation, and shows the full profile with direct reports. **Import CSV** accepts any of these columns (manager and HRBP as email addresses) and **Export CSV** downloads them. Anyone with a past exit date is paused automatically, so leavers get no newsletters.
- **Headcount & Attrition dashboard:** only workforce numbers. The filter bar stays visible while you scroll and filters by period (financial year to date, April to March; last 12 or 6 months; last 90 or 30 days), leader, business unit, department, location, gender, grade band and employment type. Filters that are set are highlighted, your choices are remembered, and everything below updates on one page:
  - **12 KPI cards in three groups**, each with ▲/▼ against the same period last year (green better, red worse). People: headcount, joiners, exits, retention rate (people employed at the start of the period who are still here at the end). Attrition (annualised): overall, voluntary, involuntary, regrettable. Quality & pipeline: early exits within 6 months, women in workforce, average tenure, serving notice.
  - **Charts:** headcount trend (line, last 12 months), joiners vs exits per month (columns), gender and employment-type split (donuts with legend tables), headcount and attrition by business unit, why people left, tenure bands and location (bar lists).
  - **Tables:** by department (sortable: headcount, joiners, exits, attrition, voluntary, regrettable, women), people serving notice (soonest last day first) and recent exits with reasons.
  - **Employees** (at the bottom of every space's dashboard): the first 10 people employed today who match the filters, sorted by name, with how many match in total. **Download CSV** downloads all of them, with the profile columns you may see. **Manage employees** opens the Employees page (import, add, pause, full profiles); the sidebar no longer has an Employees link.
  - Click any number to open the Employees page filtered to those people. Attrition = exits ÷ average headcount (13 evenly spaced days), × 365 ÷ days in the period. Hover a number for its definition.
- **Headcount & Attrition newsletter (from your data):** in the editor's AI writer tab, choose **Use your data → Headcount & attrition** (the default), pick a period and an organisation (whole company, a business unit, a department or **a leader's org**, meaning everyone who reports up to them) and optionally a gender, add a focus and click **Build newsletter**. It lays out the dashboard's numbers like an HR brief: headline attrition and headcount with change against last year, eight key metrics, attrition by type, gender diversity, attrition by department (and by business unit for the whole company), why people left, a dashboard link and a footer with the definitions. Claude writes only the executive summary, from those numbers. No individual employee is named, apart from the leader whose org it covers. **Suggested prompts** are worked out from the data, for example 'Attrition in <leader>'s org', 'Why Data Science attrition is 36.7%', regrettable exits, early exits, gender diversity, attrition vs last year and people serving notice. They appear in the AI writer under **Use your data**. The dashboard also has a **Leader** filter.
- **Newsletter insights:** four tabs. **Overview** (tiles, engagement by newsletter, up next, recent newsletters, most engaged departments), **Recommendations** (when employees read, best time to send, and the recommendations), **Ideas & prompts** (AI topic ideas and suggested prompts) and **Studio numbers** (every figure the AI and the Stats block can use, workforce numbers included).
- **DEI dashboard:** women in workforce, women in leadership (G10+) and women managers (G8), non-binary employees, the share of women among this year's joiners and leavers, female and male attrition, median age, under 30 and 50 and over, each against a year ago; gender split, women by level, department and location, joiners and leavers by gender, age groups, and a sortable table by department.
- **Performance dashboard:** average rating, high performers (4 to 5), meeting expectations (3), low performers (1 to 2), high- and low-performer attrition, high performers serving notice and leavers' average rating; the rating distribution, rating bands, average rating by department, level and tenure, leavers by rating, and a table by department.
- **Goals dashboard:** goals, average progress, completed, on track, at risk, behind, overdue, not started, employees with goals, goals per person and goals due this quarter for the current cycle (financial year); goal status, progress by department and category, completion by quarter due, a table by department, and **Goals that need attention** (behind and at-risk goals with the employee's name, on the dashboard only, never in a newsletter or sent to the AI). Each person's goals also show in their profile.
- **Every space:** the same filters (leader, business unit, department, location, gender, grade band, employment type), remembered per space. To turn a space's numbers into a newsletter, use **AI writer → Use your data** in the editor: it builds a ready-made newsletter (KPI cards, bars, tables and a short AI summary) for the team you pick. The AI only writes the summary, from aggregates; no employee is named.
- **Demo goals:** `flask --app run seed-goals` gives every employed demo employee 2 to 4 goals for this financial year, fitting their department, with quarterly due dates and progress that follows the calendar and their rating. Real employees are never touched, and running it again adds nothing.
- **Demo HR data:** `flask --app run seed-employees` creates about 600 demo profiles (all `@example.com`): a CEO, business-unit heads, department heads, managers and individual contributors with HR business partners, joiners over the years, about 100 exits in the last two years (voluntary and involuntary, some regrettable, some early) and people serving notice. Use `--total 800` for more. Real employees are never changed, and running it again adds nothing.
- **Layout:** a dark navy sidebar (the current space, then Dashboard, Newsletters and Account) and a light, compact workspace. A top bar shows where you are and has a quick employee search: press **Ctrl+K** (or **/**) anywhere, type a name, email, ID or designation and press Enter. Newsletter insights is split into tabs, the Employees list shows one compact row per person (click a name for the full profile), and every page works on a phone.
- **App themes:** 8 themes for the whole studio (Indigo, Ocean, Emerald, Sunset, Rose, Slate, plus the dark themes Midnight and Aurora). Each one tints the sidebar and the accent colour. Each admin chooses their own in **Settings & themes** or from the palette button in the sidebar. Settings also lets you change your display name and password.

Stack: Flask, PostgreSQL (SQLAlchemy), plain HTML, CSS and JavaScript, and the Anthropic Python SDK.

## Setup

```powershell
cd C:\Users\admin\Downloads\Newsletter
python -m venv .venv                     # skip if .venv already exists
.venv\Scripts\pip install -r requirements.txt
copy .env.example .env                   # then edit .env (see below)
```

Create the database. Use the port of the PostgreSQL server you want: this machine has v17 and v18 installed, on 5432 and 5433.

```powershell
& "C:\Program Files\PostgreSQL\18\bin\createdb.exe" -U postgres -p 5432 newsletter
```

In `.env`, set at least:

| Setting | What it is |
|---|---|
| `DATABASE_URL` | `postgresql://postgres:YOUR_PASSWORD@localhost:5432/newsletter` |
| `SECRET_KEY` | A long random string. It signs sessions and tracked links. |
| `ANTHROPIC_API_KEY` | Your Claude API key, from console.anthropic.com. |
| `COMPANY_NAME` | Used in the AI's instructions and the page titles. |

Create the tables and your login:

```powershell
.venv\Scripts\flask --app run init-db
.venv\Scripts\flask --app run create-user you@yourcompany.com --name "Your Name"
```

Run it:

```powershell
.venv\Scripts\python run.py
```

Open http://localhost:5000, sign in, and import employees from **Employees**. `sample_employees.csv` shows the format: `email,name,department`.

## Sending email

`MAIL_BACKEND=file` is the default. Nothing is sent; every email is saved as an `.eml` file in `outbox/`, which Outlook opens directly. Use this mode to check rendering before going live.

When you choose a provider, set `MAIL_BACKEND=smtp` and the `SMTP_*` values:

| Provider | Host | Port | Notes |
|---|---|---|---|
| Microsoft 365 | `smtp.office365.com` | 587 | The account needs SMTP AUTH enabled. |
| Google Workspace | `smtp.gmail.com` / `smtp-relay.gmail.com` | 587 | Use an app password or a relay. |
| Amazon SES | `email-smtp.<region>.amazonaws.com` | 587 | Use SES SMTP credentials and a verified domain. |
| Postmark / SendGrid / Mailgun | (from the provider) | 587 | |

To add an HTTP-API provider instead, add a backend class in `app/services/mailer.py` with a `send()` method and register it in `get_backend()`.

`PUBLIC_BASE_URL` must be an address employees' mail clients can reach, such as `https://newsletter.intranet.yourcompany.com`. Open tracking and click tracking depend on it.

## Running in production

**On an Ubuntu or Debian server, use `deploy.sh`.** Run `sudo bash deploy.sh` for the first install and again for every update. The script:

- installs Python, nginx and the app's packages
- runs the app with gunicorn and the sender as two systemd services, both under a dedicated `newsletter` user
- creates `/opt/newsletter/.env` once, with a random `SECRET_KEY`, and never overwrites it
- keeps the database in `/var/lib/newsletter`, and backs it up before every update
- puts nginx in front, with optional HTTPS through Let's Encrypt (set `DOMAIN` and `HTTPS_EMAIL`)
- checks that the app answers, and rolls back a failed update from GitLab

It sets `BEHIND_PROXY=1`, so the sign-in lockout counts each visitor separately behind nginx. Leave that setting at 0 when people reach the app directly.

Doing it by hand instead:

- Run the web app under a WSGI server: on Windows, `pip install waitress` and then `waitress-serve --port=5000 run:app`; on Linux, `gunicorn run:app`. Set `EMBEDDED_WORKER=false`.
- Run the sender as its own process: `flask --app run worker`. The worker claims rows with `SELECT … FOR UPDATE SKIP LOCKED`, so several workers can run without sending anything twice.
- Put it behind HTTPS, and keep `.env` out of version control (it is already listed in `.gitignore`).

## Security

- **Secret key.** The app uses `SECRET_KEY` from `.env` only if it is at least 32 characters long and isn't a known placeholder. Otherwise it creates a random key in `instance/secret_key`, which is git-ignored, and logs a warning. Changing the key signs everyone out.
- **Debug off by default.** `python run.py` listens on `127.0.0.1` with debug off. `FLASK_DEBUG=1` turns debug on, but only on localhost.
- **Admins and members.** New users are members. Only admins can:
  - add, import, pause or delete employees, or quick-add an address in the editor
  - manage users and access
  - send to all employees

  Members can delete only the newsletters they created. Use `flask --app run create-user` to create the first admin.
- **Passwords.**
  - Someone added under *Settings → Users & access* must choose their own password when they first sign in.
  - Changing a password signs out that user's other browsers.
  - After 5 wrong passwords, that email is locked for 15 minutes (`LOGIN_MAX_ATTEMPTS`, `LOGIN_LOCK_MINUTES`). One address is locked after 20 failures. The counter is kept in memory, so it resets when the app restarts.
- **Cookies.** Cookies are HttpOnly and SameSite=Lax, and they are marked Secure when `PUBLIC_BASE_URL` is https. The remember-me cookie lasts 14 days (`REMEMBER_DAYS`); a signed-in session lasts 12 hours.
- **Headers.** Every page sends Content-Security-Policy, X-Frame-Options DENY, nosniff, Referrer-Policy, Permissions-Policy and Cross-Origin-Opener-Policy. Signed-in pages aren't cached.
- **HR leaving data.** Resignation and exit dates, and the "Serving notice" status, are shown only to people with the HR space. Everyone else sees such employees as Active, in the app and in CSV downloads.
- **CSV downloads.** Cells that begin with `= + - @` are prefixed with `'`, so spreadsheet apps can't run them as formulas. Importing the file again removes the prefix.
- **Tracking links.** A click link redirects only to a URL that appears in that newsletter. Links in emails sent before the key change still work.
- **Data at rest.** `temp.db`, `outbox/` and `backups/` hold employee data unencrypted. Keep them on an encrypted disk (BitLocker) and delete old backups when you no longer need them.

## How the AI works

`app/services/ai.py` sends your prompt to Claude (`claude-opus-5-5` by default; change it with `AI_MODEL`) and uses structured outputs, so the reply always matches the newsletter block schema. The instructions tell the model to use only the facts you supply. Anything it can't know, such as a date or a name, appears as a bracketed placeholder like `[date]`. The **Send / schedule** check blocks sending while a button has no link or an image has no URL. Revisions send the current draft along with your instruction. If the model declines a request, the API retries it on a fallback model (`fallbacks="default"`).

With **Include studio data** ticked, the request also carries the studio's totals from `app/services/insights.py` (`studio_data_text`), and the model may use those figures too. Topic ideas send `ideas_context`: the same totals plus each sent newsletter's subject, audience, open and click rate and most-clicked links. No employee names or email addresses are sent. The recommendations and draft checks are calculated locally and need no AI.

### Help assistant

Every signed-in page has a chat button in the bottom-right corner. It answers how-to questions about the studio. When someone asks for a prompt, it writes one they can use straight away: **Use this prompt** fills the AI writer box, and **Start a newsletter with it** opens a new newsletter with the prompt already in it.

- **Its knowledge** is the guide in `app/services/help_bot.py` (`GUIDE`). Update the guide when the interface changes. It is sent as a cached system block.
- **What Claude receives:** the conversation, plus the person's role, their spaces, the current space and the current page. No employee data or newsletters are sent.
- **Where the conversation is kept:** only in that browser tab, and it is cleared on sign-out.
- **Settings:**
  - `HELP_EFFORT` (default `low`): how much effort the model puts into answers; low keeps them quick.
  - `HELP_MAX_QUESTIONS` and `HELP_WINDOW_MINUTES` (default 30 questions per 10 minutes per person): the cap that keeps costs predictable.

## Project layout

```
app/
  models.py              users (role, spaces), recipients, goals, campaigns, deliveries (the send queue), events
  spaces.py              the spaces, who may open them, profile fields per space
  routes/                auth, spaces (chooser), dashboard, campaigns (editor API + stats), insights, recipients, settings (users & access), tour (first-login guide), help (chat assistant), tracking
  services/blocks.py     block schema, sanitizing (nh3), preflight checks, plain-text version
  services/renderer.py   email-safe HTML rendering + tracking link rewriting
  services/ai.py         Claude generation
  services/help_bot.py   help assistant: the studio guide it answers from, streaming answers
  services/mailer.py     file / SMTP backends
  services/sender.py     scheduler + rate-limited queue worker
  services/insights.py   recommendations, draft checks, best send time, studio numbers
  services/storyboard.py newsletter from engagement data: period metrics, comparison, data blocks
  services/prompts.py    prompt suggestions worked out from the data
  services/employees.py  employee profile fields, CSV import/export helpers
  services/workforce.py  workforce KPIs (headcount, attrition…) for the Headcount & Attrition dashboard
  services/space_reports.py  DEI, Performance and Goals numbers (KPI groups, charts, tables)
  services/space_newsletter.py  newsletter built from a DEI, Performance or Goals report
  seed_employees.py      demo HR data (org chart, joiners, exits)
  seed_goals.py          demo goals for this financial year
  templates/email/newsletter.html   the table-based email template
  static/js/editor.js    drag-and-drop editor
  static/js/tour.js      first-login guided tour (steps and their text are at the top)
  static/js/help.js      the help chat in the corner
```

## Notes

- **Guided tour.** A new user's first sign-in starts a short tour in four parts:
  1. the space chooser
  2. the dashboard
  3. the newsletters list
  4. the editor

  Each part shows once, the first time the user opens that page. **Skip tour** or Esc ends it. Progress is saved on the account, so it doesn't come back in another browser. Anyone can replay it from **Take the tour** in the sidebar or on the space chooser. People who already used the studio before the tour was added don't get it automatically.

- Opens are counted when the email's images load. Many Outlook setups block images by default, so open rates read low. Clicks are reliable, and a click also counts as an open.
- Tables are created with `flask init-db` (SQLAlchemy `create_all`). If the schema changes later, add Flask-Migrate (Alembic) for migrations.

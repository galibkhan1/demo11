"""Check that the SMTP settings work, one step at a time.

Uses the same SMTP_* settings as Newsletter Studio (from the project's env file), so a pass here means the
studio can send with MAIL_BACKEND=smtp. Each step is reported separately, so a failure points at its cause:
host name, network or firewall, TLS, login, or the sender address.

    .venv\\Scripts\\python smtptest.py                          check connection and login only (sends nothing)
    .venv\\Scripts\\python smtptest.py --to you@company.com     also send one test email
    .venv\\Scripts\\python smtptest.py --host smtp.office365.com --port 587 --user you@company.com --ask-password
    .venv\\Scripts\\python smtptest.py --ses-password                  Amazon SES: turn an IAM secret access key into
                                                                     the SMTP password (nothing is sent anywhere)

Command-line options override the env file. The password is never printed.
"""

import argparse
import base64
import getpass
import hashlib
import hmac
import os
import re
import smtplib
import socket
import ssl
import sys
import time
from datetime import datetime
from email.message import EmailMessage
from email.utils import formataddr, make_msgid
from pathlib import Path

ENV_FILE = Path(__file__).resolve().with_name(".env")


def env_bool(name: str, default: bool) -> bool:
    value = os.environ.get(name)
    return default if value is None else value.strip().lower() in {"1", "true", "yes", "on"}


def ok(msg: str) -> None:
    print(f"  [ OK ] {msg}")


def info(msg: str) -> None:
    print(f"         {msg}")


def fail(msg: str, hint: str = "") -> None:
    print(f"  [FAIL] {msg}")
    for line in hint.strip().splitlines():
        print(f"         > {line.strip()}")
    print("\nSMTP test FAILED.")
    sys.exit(1)


def smtp_error_text(exc: smtplib.SMTPResponseException) -> str:
    detail = exc.smtp_error.decode(errors="replace") if isinstance(exc.smtp_error, bytes) else str(exc.smtp_error)
    return f"{exc.smtp_code} {detail}".strip()


_SES_HOST = re.compile(r"^email-smtp(?:-fips)?\.([a-z]{2}(?:-[a-z]+)+-\d)\.amazonaws\.com$", re.I)


def ses_region(host: str) -> str | None:
    """'ap-south-1' for email-smtp.ap-south-1.amazonaws.com, else None."""
    m = _SES_HOST.match(host or "")
    return m.group(1).lower() if m else None


def ses_smtp_password(secret_access_key: str, region: str) -> str:
    """AWS's documented conversion of an IAM secret access key into an SES SMTP password for one region."""
    def sign(key: bytes, msg: str) -> bytes:
        return hmac.new(key, msg.encode("utf-8"), hashlib.sha256).digest()

    signature = sign(("AWS4" + secret_access_key).encode("utf-8"), "11111111")
    for part in (region, "ses", "aws4_request", "SendRawEmail"):
        signature = sign(signature, part)
    return base64.b64encode(bytes([0x04]) + signature).decode("utf-8")


def ses_hint(text: str, region: str | None) -> str:
    """Advice for Amazon SES rejections (sandbox, unverified identities, quotas)."""
    t = text.lower()
    where = f" in {region}" if region else ""
    if "not verified" in t or "identities failed" in t:
        return f"""Amazon SES: an address isn't verified{where}.
        The From address (or its whole domain) must be a verified identity in SES > Identities, in the same region as SMTP_HOST.
        While the account is in the SES sandbox, every recipient must be verified too.
        To email all employees, request production access: SES console > Account dashboard > Request production access."""
    if "daily message quota" in t:
        return "Amazon SES: the 24-hour sending quota is used up (200 a day in the sandbox). Wait, or request a higher quota."
    if "maximum sending rate" in t or "throttl" in t:
        return "Amazon SES: sending too fast. Lower SEND_RATE_PER_MINUTE (sandbox allows 1 email per second = 60 a minute)."
    if "sending paused" in t or "account is paused" in t:
        return "Amazon SES: sending is paused for this account or region. Check the SES console's Account dashboard."
    return ""


def auth_hint(_code: int, text: str, host: str, user: str = "") -> str:
    t = text.lower()
    region = ses_region(host)
    if region or "amazonaws" in host or user.upper().startswith("AKIA"):
        return f"""Amazon SES: the username is the SMTP username (starts with AKIA) and the password is the SMTP password,
        which is NOT the IAM secret access key.
        If you created the IAM user's access key yourself, convert the secret key: run  smtptest.py --ses-password
        Credentials only work in the region they were made for{f" (this server is {region})" if region else ""}.
        The IAM user also needs the ses:SendRawEmail permission."""
    if "5.7.139" in t or "smtp auth" in t or "smtpclientauthentication" in t or "5.7.57" in t:
        return """Microsoft 365 has SMTP AUTH turned off for this mailbox or the whole tenant.
        An admin must enable "Authenticated SMTP" for the mailbox (Microsoft 365 admin center > Users > Mail),
        and Security Defaults must allow it."""
    if "gmail" in host or "google" in host or "gmail" in t or "google" in t or "application-specific password" in t:
        return """Google rejects normal passwords for SMTP. Turn on 2-Step Verification and create an App password
        (Google Account > Security > App passwords), then use that 16-character password."""
    if "amazonaws" in host:
        return "Use SES SMTP credentials (SES console > SMTP settings), not your AWS access keys."
    return "Check SMTP_USERNAME and SMTP_PASSWORD. Many providers want the full email address as the username."


def main() -> None:
    parser = argparse.ArgumentParser(description="Test SMTP settings step by step.")
    parser.add_argument("--host", help="SMTP server (default: SMTP_HOST)")
    parser.add_argument("--port", type=int, help="port (default: SMTP_PORT, usually 587)")
    parser.add_argument("--user", help="login name (default: SMTP_USERNAME)")
    parser.add_argument("--security", choices=["starttls", "ssl", "none"],
                        help="starttls (port 587), ssl (port 465) or none (default: from SMTP_USE_TLS / SMTP_USE_SSL)")
    parser.add_argument("--from", dest="sender", help="sender address for the test email (default: MAIL_FROM)")
    parser.add_argument("--to", help="send one test email to this address (without it, nothing is sent)")
    parser.add_argument("--timeout", type=int, help="seconds to wait for the server (default: SMTP_TIMEOUT or 30)")
    parser.add_argument("--ask-password", action="store_true", help="type the password instead of reading SMTP_PASSWORD")
    parser.add_argument("--no-env", action="store_true", help="ignore the env file; use only command-line options")
    parser.add_argument("--ses-password", action="store_true",
                        help="Amazon SES: convert an IAM secret access key into the SMTP password, then exit")
    parser.add_argument("--region", help="AWS region for --ses-password (default: taken from SMTP_HOST)")
    args = parser.parse_args()

    for stream in (sys.stdout, sys.stderr):  # never crash on characters the Windows console can't show
        try:
            stream.reconfigure(errors="replace")
        except (AttributeError, ValueError):
            pass
    print("Newsletter Studio SMTP test\n")
    if not args.no_env:
        try:
            from dotenv import load_dotenv
        except ImportError:
            print("  (python-dotenv isn't installed, so only command-line options are used)")
        else:
            if ENV_FILE.exists():
                load_dotenv(ENV_FILE)

    def env_int(name: str, default: int) -> int:
        raw = (os.environ.get(name) or "").strip()
        if not raw:
            return default
        if not raw.isdigit():
            fail(f"{name} must be a plain number, but it is '{raw}'.",
                 f"Keep only the number on that line, e.g. {name}={default}, with no notes after it.")
        return int(raw)

    host = (args.host or os.environ.get("SMTP_HOST", "")).strip()
    if any(c.isspace() for c in host):
        fail(f"SMTP_HOST has extra text after the server name: '{host}'.",
             f"Keep only the server name on that line: SMTP_HOST={host.split()[0]}")
    port = args.port or env_int("SMTP_PORT", 587)
    user = (args.user if args.user is not None else os.environ.get("SMTP_USERNAME", "")).strip()
    timeout = args.timeout or env_int("SMTP_TIMEOUT", 30)
    if any(c.isspace() for c in user):
        fail("SMTP_USERNAME has spaces or extra text in it.", "Keep only the username (it starts with AKIA for Amazon SES).")
    env_int("SEND_RATE_PER_MINUTE", 120)  # the app won't start if this isn't a number
    security = args.security or (
        "ssl" if env_bool("SMTP_USE_SSL", False) or port == 465
        else "starttls" if env_bool("SMTP_USE_TLS", True) else "none")
    sender = (args.sender or os.environ.get("MAIL_FROM", "")).strip() or user
    sender_name = os.environ.get("MAIL_FROM_NAME", "Newsletter Studio")

    region = ses_region(host)

    if args.ses_password:
        region = (args.region or region or input("AWS region of your SES setup (e.g. ap-south-1): ")).strip().lower()
        if not re.fullmatch(r"[a-z]{2}(-[a-z]+)+-\d", region):
            fail(f"'{region}' doesn't look like an AWS region.", "Use the code shown in the SES console, e.g. ap-south-1 or us-east-1.")
        print("Amazon SES SMTP password from an IAM secret access key")
        info("The key is used only on this computer to calculate the password; it isn't stored or sent.")
        secret = getpass.getpass("  IAM secret access key (typing is hidden): ").strip()
        if len(secret) < 30:
            fail("That doesn't look like a secret access key (they are 40 characters).")
        print(f"\n  SMTP password for {region}:\n\n    {ses_smtp_password(secret, region)}\n")
        info("Put it in SMTP_PASSWORD. SMTP_USERNAME is the access key ID of the same IAM user (starts with AKIA).")
        info(f"SMTP_HOST must be email-smtp.{region}.amazonaws.com for this password to work.")
        return

    password = "" if args.ask_password else os.environ.get("SMTP_PASSWORD", "")
    if user and not password:
        if sys.stdin.isatty():
            password = getpass.getpass(f"  Password for {user}: ")
        else:
            fail("A username is set but no password.", "Set SMTP_PASSWORD, or run with --ask-password in a terminal.")

    print("Settings")
    info(f"Server:    {host or '(not set)'}:{port}" + (f"  (Amazon SES, region {region})" if region else ""))
    info(f"Security:  {security}")
    info(f"Login:     {user or '(none, no login)'}" + (f"  password: set ({len(password)} characters)" if user else ""))
    info(f"Sender:    {sender or '(not set)'}")
    info(f"Test mail: {args.to or 'not sending (add --to you@company.com to send one)'}\n")

    if not host:
        fail("SMTP_HOST is empty.", "Set SMTP_HOST in the env file, or pass --host smtp.yourprovider.com")
    if region and user and not user.upper().startswith("AKIA"):
        info("Note: Amazon SES SMTP usernames start with AKIA. Check SMTP_USERNAME (it isn't your email address).\n")
    if security == "ssl" and port == 587:
        info("Note: port 587 normally uses STARTTLS, not SSL. Try --security starttls if this fails.\n")
    if security == "starttls" and port == 465:
        info("Note: port 465 normally uses SSL. Try --security ssl if this fails.\n")

    print("Steps")
    # 1. DNS
    try:
        addrs = sorted({a[4][0] for a in socket.getaddrinfo(host, port, type=socket.SOCK_STREAM)})
    except socket.gaierror as exc:
        fail(f"Can't find the server '{host}' ({exc.strerror}).",
             "Check the spelling of SMTP_HOST and that this computer is online.")
    ok(f"Found {host}: {', '.join(addrs[:3])}")

    # 2. Connect (and implicit TLS for port 465)
    context = ssl.create_default_context()
    started = time.monotonic()
    try:
        if security == "ssl":
            conn = smtplib.SMTP_SSL(host, port, timeout=timeout, context=context)
        else:
            conn = smtplib.SMTP(host, port, timeout=timeout)
    except (socket.timeout, TimeoutError):
        fail(f"No answer from {host}:{port} within {timeout} seconds.",
             """A firewall, antivirus or the network is probably blocking this port.
             Port 25 is often blocked by ISPs; most providers use 587 (STARTTLS) or 465 (SSL).""" + (
             "\nAmazon SES also listens on 2587 (STARTTLS) and 2465 (SSL) if 587 and 465 are blocked." if region else ""))
    except ConnectionRefusedError:
        fail(f"{host} refused the connection on port {port}.", "The server isn't accepting mail on this port. Check SMTP_PORT.")
    except ssl.SSLError as exc:
        fail(f"TLS failed while connecting: {exc.reason or exc}.",
             "This port probably expects STARTTLS (usually port 587): use --security starttls (SMTP_USE_SSL=false, SMTP_USE_TLS=true).")
    except smtplib.SMTPConnectError as exc:
        fail(f"The server answered but refused the session: {smtp_error_text(exc)}")
    except OSError as exc:
        fail(f"Couldn't connect to {host}:{port}: {exc}.", "Check the host, port and network.")
    ok(f"Connected to {host}:{port} in {time.monotonic() - started:.1f} s")

    try:
        # 3. EHLO
        code, _ = conn.ehlo()
        if code != 250:
            fail(f"The server rejected EHLO (code {code}).")
        features = conn.esmtp_features
        ok("Server greeting accepted. Supports: " + (", ".join(sorted(k.upper() for k in features)) or "basic SMTP only"))

        # 4. STARTTLS
        if security == "starttls":
            if not conn.has_extn("starttls"):
                fail("The server doesn't offer STARTTLS on this port.",
                     "Try --security ssl --port 465, or --security none only for a trusted internal relay.")
            try:
                conn.starttls(context=context)
                conn.ehlo()
            except ssl.SSLCertVerificationError as exc:
                fail(f"The server's certificate isn't trusted: {exc.verify_message}.",
                     "Use the provider's official host name (the one on its certificate), not an IP address or alias.")
            except ssl.SSLError as exc:
                fail(f"STARTTLS failed: {exc.reason or exc}.")
        if security in ("starttls", "ssl"):
            sock = conn.sock
            cert = sock.getpeercert() if hasattr(sock, "getpeercert") else None
            issuer = dict(x[0] for x in cert.get("issuer", ())).get("organizationName", "?") if cert else "?"
            expires = cert.get("notAfter", "?") if cert else "?"
            ok(f"Encrypted with {sock.version()}; certificate from {issuer}, valid until {expires}")
        else:
            info("Not encrypted (security=none). Use this only for a trusted internal relay.")

        # 5. Login
        if user:
            methods = " ".join(features.get("auth", "").upper().split())
            if not conn.has_extn("auth"):
                fail("The server doesn't offer login (AUTH) here.",
                     "Most servers only offer AUTH after STARTTLS. Check --security, or leave SMTP_USERNAME empty for an IP-allowed relay.")
            try:
                conn.login(user, password)
            except smtplib.SMTPAuthenticationError as exc:
                text = smtp_error_text(exc)
                fail(f"Login rejected: {text}", auth_hint(exc.smtp_code, text, host, user))
            except smtplib.SMTPNotSupportedError:
                fail("The server doesn't support any login method this script knows.", f"Server offers: {methods or 'none'}")
            ok(f"Logged in as {user} (server offers {methods or 'AUTH'})")
        else:
            info("No username set, so no login. That works only for relays that allow this computer's IP address.")

        # 6. Optional test email
        if args.to:
            if not sender:
                fail("No sender address.", "Set MAIL_FROM in the env file, or pass --from you@company.com")
            msg = EmailMessage()
            msg["Subject"] = "SMTP test from Newsletter Studio"
            msg["From"] = formataddr((sender_name, sender))
            msg["To"] = args.to
            msg["Message-ID"] = make_msgid(domain=sender.split("@")[-1] or None)
            when = datetime.now().astimezone().strftime("%d %b %Y, %H:%M %Z")
            msg.set_content(f"This is a test email from Newsletter Studio.\n\nSent {when} through {host}:{port} ({security}).\n"
                            "If you can read this, the SMTP settings work.\n")
            msg.add_alternative(
                f"<p>This is a test email from <strong>Newsletter Studio</strong>.</p>"
                f"<p>Sent {when} through <code>{host}:{port}</code> ({security}).</p>"
                f"<p>If you can read this, the SMTP settings work.</p>", subtype="html")
            try:
                refused = conn.send_message(msg, from_addr=sender, to_addrs=[args.to])
            except smtplib.SMTPSenderRefused as exc:
                text = smtp_error_text(exc)
                fail(f"The server refused the sender {sender}: {text}", ses_hint(text, region) or
                     """The From address must be one the account may send as: usually the login mailbox itself,
                     a shared mailbox it has "Send As" rights to, or (Amazon SES) a verified address or domain.""")
            except smtplib.SMTPRecipientsRefused as exc:
                reasons = "; ".join(f"{r}: {c} {m.decode(errors='replace')}" for r, (c, m) in exc.recipients.items())
                fail(f"The server refused the recipient: {reasons}", ses_hint(reasons, region))
            except smtplib.SMTPDataError as exc:
                text = smtp_error_text(exc)
                fail(f"The server refused the message: {text}", ses_hint(text, region))
            if refused:
                fail(f"Some recipients were refused: {refused}")
            ok(f"Test email accepted for {args.to}. Check that inbox (and the junk folder).")
    except smtplib.SMTPServerDisconnected as exc:
        fail(f"The server closed the connection unexpectedly: {exc}.",
             "This often means the wrong security mode for the port (587 = starttls, 465 = ssl).")
    except (socket.timeout, TimeoutError):
        fail(f"The server stopped answering (timeout after {timeout} seconds).")
    finally:
        try:
            conn.quit()
        except Exception:  # noqa: BLE001 — closing is best effort
            pass

    print("\nSMTP test PASSED." + ("" if args.to else " Nothing was sent; add --to you@company.com to send a test email."))
    if region:
        print(f"\nAmazon SES ({region}) notes:")
        info("MAIL_FROM (or its domain) must be a verified identity in this region.")
        info("In the SES sandbox you can only send to verified addresses, 200 a day, 1 per second.")
        info("Request production access before sending to all employees, and keep SEND_RATE_PER_MINUTE at or below")
        info("your SES maximum send rate x 60 (sandbox: 60).")
    print("To send newsletters this way, set MAIL_BACKEND=smtp in the env file and restart the app.")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nCancelled.")
        sys.exit(130)

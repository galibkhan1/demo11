"""Quick check that your Claude API key works.

Run from the project folder:  .venv\\Scripts\\python test.py
The key is read from ANTHROPIC_API_KEY in .env (never put it in this file).
"""
import os
import sys

from dotenv import load_dotenv

load_dotenv()  # loads .env from the current folder

if not os.environ.get("ANTHROPIC_API_KEY"):
    sys.exit("ANTHROPIC_API_KEY is empty. Add it to .env first.")

import anthropic  # noqa: E402  (imported after the check because it is slow to load)

client = anthropic.Anthropic()  # picks up ANTHROPIC_API_KEY automatically

try:
    message = client.messages.create(
        model="claude-opus-5-5",
        max_tokens=1024,
        messages=[{"role": "user", "content": "Hello, world"}],
    )
except anthropic.AuthenticationError:
    sys.exit("The API key was rejected. Create a new one at https://console.anthropic.com/settings/keys")
except anthropic.APIError as e:
    sys.exit(f"API error: {e}")

print("".join(block.text for block in message.content if block.type == "text"))
